<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Preserve the imported EVA Office IndexedDB data layer for local documents; importing the app must not migrate users' files to a remote service.
- Keep the template TanStack Start runtime and import screens under src/routes; the uploaded runtime configuration targets a different deployment.
- Preserve the uploaded app's TypeScript optional/index access settings while retaining strict mode so its existing editor modules remain compatible.
- Serve uploaded fonts through Lovable Assets pointers and the font stylesheet to preserve the imported typography without storing binaries.
- Serve dictionary data as static JSON in public/dictionary fetched at runtime and prefetched from the root; bundling 11MB JSON as modules made opening slow.
