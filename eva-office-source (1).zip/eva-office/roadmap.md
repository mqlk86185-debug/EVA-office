# Run uploaded EVA Office
- [x] Import the uploaded office screens and preserve the restored six-item bottom navigation.
- [x] Verify home, updates, dictionary and editor navigation in the preview.
- [ ] Verify viewing, upload authorization and publishing.
- [ ] Deliver a complete source ZIP without secrets or generated dependencies.
- [x] Templates: customize button on every template, saved designs section with delete, tested in preview.
