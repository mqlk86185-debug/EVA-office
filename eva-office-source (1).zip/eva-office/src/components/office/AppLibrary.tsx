"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@/components/office/Link";
import { useRouter } from "@/lib/office/nav";
import { toast } from "sonner";
import { ChevronRight, FileText, Plus, Search, Star, Upload, Loader2 } from "lucide-react";
import { AppMark } from "./AppMark";
import { BottomNav } from "./BottomNav";
import { FileCard } from "./FileCard";
import { ThemeToggle } from "./ThemeToggle";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { createFile, listFiles, shareUrl, updateFile, uploadPdf } from "@/lib/office/client";
import { APP_META, fileHref, type AppType, type OfficeFile } from "@/lib/office/types";
import { TemplateGallery } from "@/components/office/eva/TemplateGallery";
import type { TemplateDef } from "@/lib/office/templates/build";
import { DOCUMENT_TEMPLATES } from "@/lib/office/templates/documents";
import { PRO_TEMPLATES } from "@/lib/office/templates/pro";
import { GOLD_STATIONERY } from "@/lib/office/templates/gold";
import { IMPORT_ACCEPT, importDocument, importedPayload } from "@/lib/office/import-document";

export interface CreateOption {
  label: string;
  doc_type: string;
  title: string;
}

/** Shared library screen for EVA / PDF / GILOX. */
export function AppLibrary({
  app,
  description,
  createOptions,
  allowUpload = false,
}: {
  app: AppType;
  description: string;
  createOptions: CreateOption[];
  allowUpload?: boolean;
}) {
  const router = useRouter();
  const meta = APP_META[app];
  const [files, setFiles] = useState<OfficeFile[] | null>(null);
  const [search, setSearch] = useState("");
  const [onlyFavorites, setOnlyFavorites] = useState(false);
  const [busy, setBusy] = useState(false);
  const [templatesOpen, setTemplatesOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const importRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      const data = await listFiles({ app, limit: 200 });
      setFiles(data);
      console.log(`[${meta.name}] loaded ${data.length} files`);
    } catch (err) {
      console.error(`[${meta.name}] load failed:`, err);
      toast.error("تعذّر تحميل الملفات");
      setFiles([]);
    }
  }, [app, meta.name]);

  useEffect(() => {
    void load();
  }, [load]);

  const visible = useMemo(() => {
    let list = files ?? [];
    if (onlyFavorites) list = list.filter((f) => f.is_favorite === "yes");
    const term = search.trim().toLowerCase();
    if (term) list = list.filter((f) => f.title.toLowerCase().includes(term));
    return list;
  }, [files, search, onlyFavorites]);

  const create = async (option: CreateOption) => {
    setBusy(true);
    try {
      const file = await createFile({ title: option.title, doc_type: option.doc_type });
      router.push(fileHref(file));
    } catch (err) {
      console.error(`[${meta.name}] create failed:`, err);
      toast.error("تعذّر إنشاء الملف", { description: (err as Error).message });
    } finally {
      setBusy(false);
    }
  };

  const createTemplate = async (template: TemplateDef) => {
    setBusy(true);
    try {
      const payload = template.build();
      const file = await createFile(payload);
      setTemplatesOpen(false);
      router.push(fileHref(file));
    } catch (err) {
      console.error(`[${meta.name}] template creation failed:`, err);
      toast.error("تعذّر إنشاء القالب", { description: (err as Error).message });
    } finally {
      setBusy(false);
    }
  };

  const handleUpload = async (list: FileList | null) => {
    const file = list?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const created = await uploadPdf(file);
      toast.success("تم رفع الملف");
      router.push(fileHref(created));
    } catch (err) {
      console.error(`[${meta.name}] upload failed:`, err);
      toast.error("فشل رفع الملف", { description: (err as Error).message });
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  /** Converts an uploaded DOCX / PDF / TXT / MD / HTML file into a new editable EVA document. */
  const handleImport = async (list: FileList | null) => {
    const file = list?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const imported = await importDocument(file);
      const created = await createFile(importedPayload(imported));
      toast.success("تم تحويل المستند إلى EVA");
      router.push(fileHref(created));
    } catch (err) {
      console.error(`[${meta.name}] import failed:`, err);
      toast.error("تعذّر تحويل المستند", { description: (err as Error).message });
    } finally {
      setBusy(false);
      if (importRef.current) importRef.current.value = "";
    }
  };

  const toggleFavorite = async (file: OfficeFile) => {
    const next = file.is_favorite === "yes" ? "no" : "yes";
    setFiles((prev) => prev?.map((f) => (f._id === file._id ? { ...f, is_favorite: next } : f)) ?? null);
    try {
      await updateFile(file._id, { is_favorite: next });
    } catch (err) {
      console.error("[AppLibrary] favorite failed:", err);
      toast.error("تعذّر تحديث المفضلة");
      void load();
    }
  };

  const trash = async (file: OfficeFile) => {
    setFiles((prev) => prev?.filter((f) => f._id !== file._id) ?? null);
    try {
      await updateFile(file._id, { is_trashed: "yes" });
      toast.success("تم النقل إلى سلة المحذوفات");
    } catch (err) {
      console.error("[AppLibrary] trash failed:", err);
      toast.error("تعذّر نقل الملف");
      void load();
    }
  };

  const share = async (file: OfficeFile) => {
    try {
      const how = await shareUrl(file.title, fileHref(file));
      toast.success(how === "copied" ? "تم نسخ الرابط" : "تمت المشاركة");
    } catch (err) {
      console.error("[AppLibrary] share failed:", err);
      toast.error("تعذّرت المشاركة");
    }
  };

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-4xl flex-col px-4 pt-4">
      <header className="flex items-center gap-2">
        <Link
          href="/"
          aria-label="رجوع"
          className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
        >
          <ChevronRight className="h-5 w-5" />
        </Link>
        <span
          className="flex h-10 w-10 items-center justify-center rounded-xl"
          style={{ background: `color-mix(in oklab, ${meta.color} 14%, transparent)`, color: meta.color }}
        >
          <AppMark app={app} className="h-6 w-6" />
        </span>
        <div className="min-w-0 flex-1">
          <h1 className="font-display text-lg font-semibold leading-tight tracking-tight">{meta.name}</h1>
          <p className="truncate text-xs text-muted-foreground">{meta.tagline}</p>
        </div>
        <ThemeToggle />
      </header>

      <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{description}</p>

      <div className="mt-4 flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={`ابحث في ملفات ${meta.name}`}
            className="h-11 pr-9"
          />
        </div>
        <button
          type="button"
          onClick={() => setOnlyFavorites((v) => !v)}
          aria-pressed={onlyFavorites}
          aria-label="المفضلة فقط"
          className={`inline-flex h-11 w-11 items-center justify-center rounded-xl border transition-colors ${
            onlyFavorites ? "border-amber-400/50 bg-amber-400/15 text-amber-500" : "border-border bg-card hover:bg-accent"
          }`}
        >
          <Star className={`h-4.5 w-4.5 ${onlyFavorites ? "fill-amber-400" : ""}`} />
        </button>
      </div>

      <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto pb-1">
        {app === "eva" && (
          <button type="button" disabled={busy} onClick={() => setTemplatesOpen(true)} className="inline-flex shrink-0 items-center gap-1.5 rounded-xl bg-eva px-3.5 py-2 text-sm font-medium text-primary-foreground transition-transform active:scale-[.98] disabled:opacity-60">
            <FileText className="h-4 w-4" /> {DOCUMENT_TEMPLATES.length + PRO_TEMPLATES.length + GOLD_STATIONERY.length} قالب جاهز
          </button>
        )}
        {app === "eva" && (
          <>
            <button type="button" disabled={busy} onClick={() => importRef.current?.click()} className="inline-flex shrink-0 items-center gap-1.5 rounded-xl border border-border bg-card px-3.5 py-2 text-sm font-medium transition-colors hover:bg-accent disabled:opacity-60">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
              رفع مستند وتحويله إلى EVA
            </button>
            <input ref={importRef} type="file" accept={IMPORT_ACCEPT} className="hidden" onChange={(e) => void handleImport(e.target.files)} />
          </>
        )}
        {createOptions.map((option) => (
          <button
            key={option.doc_type + option.label}
            type="button"
            disabled={busy}
            onClick={() => create(option)}
            className="inline-flex shrink-0 items-center gap-1.5 rounded-xl px-3.5 py-2 text-sm font-medium text-background transition-transform active:scale-[.98] disabled:opacity-60"
            style={{ background: meta.color }}
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            {option.label}
          </button>
        ))}
        {allowUpload && (
          <>
            <button
              type="button"
              disabled={busy}
              onClick={() => inputRef.current?.click()}
              className="inline-flex shrink-0 items-center gap-1.5 rounded-xl border border-border bg-card px-3.5 py-2 text-sm font-medium transition-colors hover:bg-accent disabled:opacity-60"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
              رفع ملف PDF
            </button>
            <input
              ref={inputRef}
              type="file"
              accept="application/pdf,.pdf"
              className="hidden"
              onChange={(e) => void handleUpload(e.target.files)}
            />
          </>
        )}
      </div>

      <section className="mt-5 flex-1">
        {files === null ? (
          <div className="space-y-2">
            {[0, 1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-[68px] rounded-2xl" />
            ))}
          </div>
        ) : visible.length === 0 ? (
          <div className="rounded-3xl border border-dashed border-border p-10 text-center">
            <p className="font-medium">لا توجد ملفات هنا بعد</p>
            <p className="mt-1 text-sm text-muted-foreground">
              {allowUpload ? "ارفع أول ملف PDF للبدء." : "أنشئ أول ملف للبدء."}
            </p>
          </div>
        ) : (
          <div className="grid gap-2 sm:grid-cols-2">
            {visible.map((file) => (
              <FileCard
                key={file._id}
                file={file}
                onToggleFavorite={toggleFavorite}
                onTrash={trash}
                onShare={share}
              />
            ))}
          </div>
        )}
      </section>

      <BottomNav />
      {app === "eva" && <TemplateGallery open={templatesOpen} onOpenChange={setTemplatesOpen} onChoose={(template) => void createTemplate(template)} busy={busy} />}
    </div>
  );
}
