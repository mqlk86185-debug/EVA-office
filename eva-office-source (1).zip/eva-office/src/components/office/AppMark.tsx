import type { AppType } from "@/lib/office/types";

/**
 * Geometric glyphs for the three EVA Office apps.
 * Drawn as SVG so they stay crisp at any size and follow currentColor.
 */
export function AppMark({ app, className = "w-8 h-8" }: { app: AppType; className?: string }) {
  if (app === "eva") {
    return (
      <svg viewBox="0 0 32 32" className={className} fill="none" aria-hidden="true">
        <path d="M7 4h13l5 5v19H7z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
        <path d="M20 4v5h5" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
        <path d="M11 15h10M11 19h10M11 23h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }
  if (app === "pdf") {
    return (
      <svg viewBox="0 0 32 32" className={className} fill="none" aria-hidden="true">
        <rect x="5" y="4" width="18" height="24" rx="2.5" stroke="currentColor" strokeWidth="2" />
        <path d="M27 9v17a2.5 2.5 0 0 1-2.5 2.5H10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity=".45" />
        <path d="M10 11h8M10 16h8M10 21h5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }
  if (app === "novel") {
    return (
      <svg viewBox="0 0 32 32" className={className} fill="none" aria-hidden="true">
        <path
          d="M6 6.5A2.5 2.5 0 0 1 8.5 4H25v21H8.5A2.5 2.5 0 0 0 6 27.5z"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinejoin="round"
        />
        <path d="M6 27.5A2.5 2.5 0 0 1 8.5 25H25v3H8.5" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" opacity=".5" />
        <path d="M11 11h9M11 15.5h9M11 20h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 32 32" className={className} fill="none" aria-hidden="true">
      <rect x="4" y="5" width="24" height="22" rx="2.5" stroke="currentColor" strokeWidth="2" />
      <path d="M4 12h24M4 19.5h24M12 12v15M20 12v15" stroke="currentColor" strokeWidth="2" />
      <path d="M4 12V7.5A2.5 2.5 0 0 1 6.5 5h19A2.5 2.5 0 0 1 28 7.5V12" fill="currentColor" opacity=".18" />
    </svg>
  );
}

export function OfficeWordmark({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2 ${className}`}>
      <span className="relative inline-flex h-9 w-9 items-center justify-center rounded-xl bg-foreground text-background">
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" aria-hidden="true">
          <path d="M4 6h16M4 12h10M4 18h13" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
          <circle cx="19" cy="12" r="2.2" fill="currentColor" />
        </svg>
      </span>
      <span className="font-display text-lg font-semibold tracking-tight">
        EVA <span className="text-muted-foreground font-normal">Office</span>
      </span>
    </span>
  );
}
