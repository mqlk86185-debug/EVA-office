"use client";

import { Link } from "@/components/office/Link";
import { usePathname } from "@/lib/office/nav";
import { Home, Folder, Bell, Settings, BookOpen, LayoutTemplate } from "lucide-react";

const ITEMS = [
  { href: "/", label: "الرئيسية", icon: Home },
  { href: "/files", label: "الملفات", icon: Folder },
  { href: "/dictionary", label: "القاموس", icon: BookOpen },
  { href: "/templates", label: "القوالب", icon: LayoutTemplate },
  { href: "/updates", label: "التحديثات", icon: Bell },
  { href: "/settings", label: "الإعدادات", icon: Settings },
];

/** Touch-first bottom navigation, hidden on large screens. */
export function BottomNav() {
  const pathname = usePathname();
  return (
    <nav className="no-print sticky bottom-0 z-40 mt-8 border-t border-border bg-background/85 backdrop-blur-xl md:hidden">
      <ul className="grid grid-cols-6">
        {ITEMS.map((item) => {
          const active = pathname === item.href.split("?")[0];
          const Icon = item.icon;
          return (
            <li key={item.href}>
              <Link
                href={item.href}
                className={`flex flex-col items-center gap-1 py-2.5 text-[11px] transition-colors ${
                  active ? "text-primary" : "text-muted-foreground"
                }`}
              >
                <Icon className="h-5 w-5" strokeWidth={active ? 2.4 : 1.8} />
                {item.label}
              </Link>
            </li>
          );
        })}
      </ul>
      <div className="h-[env(safe-area-inset-bottom)]" />
    </nav>
  );
}
