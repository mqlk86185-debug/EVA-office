"use client";

/**
 * Compact colour palette: a row of preset swatches plus a free colour picker,
 * so a colour is one tap away without giving up full control.
 */
export function ColorSwatches({
  label,
  colors,
  value,
  onChange,
  allowCustom = true,
}: {
  label: string;
  colors: string[];
  value?: string;
  onChange: (color: string) => void;
  allowCustom?: boolean;
}) {
  return (
    <div className="flex shrink-0 items-center gap-1 rounded-xl bg-muted/60 p-1" role="group" aria-label={label}>
      <span className="px-1 text-[10px] text-muted-foreground">{label}</span>
      {colors.map((c) => (
        <button
          key={c}
          type="button"
          title={c === "transparent" ? "بدون لون" : c}
          aria-label={`${label} ${c}`}
          aria-pressed={value === c}
          onMouseDown={(e) => e.preventDefault()}
          onClick={() => onChange(c)}
          className={`h-6 w-6 shrink-0 rounded-md border transition-transform hover:scale-110 ${
            value === c ? "border-primary ring-2 ring-primary/40" : "border-border"
          }`}
          style={
            c === "transparent"
              ? {
                  backgroundImage:
                    "linear-gradient(45deg,#e5e7eb 25%,transparent 25%,transparent 75%,#e5e7eb 75%),linear-gradient(45deg,#e5e7eb 25%,transparent 25%,transparent 75%,#e5e7eb 75%)",
                  backgroundSize: "8px 8px",
                  backgroundPosition: "0 0,4px 4px",
                }
              : { background: c }
          }
        />
      ))}
      {allowCustom && (
        <label
          title={`${label} — لون مخصص`}
          className="relative inline-flex h-6 w-6 shrink-0 cursor-pointer items-center justify-center rounded-md border border-dashed border-border text-[10px]"
        >
          +
          <input
            type="color"
            aria-label={`${label} مخصص`}
            value={value && value !== "transparent" ? value : "#111827"}
            onChange={(e) => onChange(e.target.value)}
            className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
          />
        </label>
      )}
    </div>
  );
}
