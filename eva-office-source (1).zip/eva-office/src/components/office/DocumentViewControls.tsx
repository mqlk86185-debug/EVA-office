import { ZoomIn, ZoomOut } from "lucide-react";
import { Button } from "@/components/ui/button";

export function DocumentViewControls({ zoom, minimum, maximum, changeZoom, resetZoom }: {
  zoom: number; minimum: number; maximum: number;
  changeZoom: (delta: number) => void; resetZoom: () => void;
}) {
  return (
    <div className="document-view-controls" aria-label="أدوات عرض المستند">
      <Button variant="ghost" size="icon" aria-label="تصغير الصفحة" title="تصغير الصفحة" disabled={zoom <= minimum + 0.001} onClick={() => changeZoom(-0.1)}><ZoomOut /></Button>
      <Button variant="ghost" size="sm" aria-label="ملاءمة عرض الشاشة" title="ملاءمة عرض الشاشة" onClick={resetZoom} className="document-zoom-value">{Math.round(zoom * 100)}٪</Button>
      <Button variant="ghost" size="icon" aria-label="تكبير الصفحة" title="تكبير الصفحة" disabled={zoom >= maximum - 0.001} onClick={() => changeZoom(0.1)}><ZoomIn /></Button>
    </div>
  );
}
