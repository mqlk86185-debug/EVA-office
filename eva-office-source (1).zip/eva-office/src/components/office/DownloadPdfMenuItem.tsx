"use client";

/**
 * عنصر قائمة لتنزيل المستند الحالي كملف PDF مباشرة، بدون فتح المعاينة.
 */

import { useState } from "react";
import { Download, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { DropdownMenuItem } from "@/components/ui/dropdown-menu";
import { downloadPdfNow } from "@/lib/office/quick-export";
import type { PageSetup } from "@/lib/office/types";

export function DownloadPdfMenuItem({
  fileId,
  getHtml,
  setup,
  title,
}: {
  fileId: string;
  getHtml: () => string;
  setup: PageSetup;
  title: string;
}) {
  const [busy, setBusy] = useState(false);

  const handleDownload = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const pages = await downloadPdfNow(fileId, getHtml(), setup, title);
      toast.success(`تم تنزيل ملف PDF (${pages} صفحة)`);
    } catch (err) {
      console.error("[DownloadPdfMenuItem] failed:", err);
      toast.error("فشل تنزيل ملف PDF", { description: (err as Error).message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <DropdownMenuItem
      disabled={busy}
      onSelect={(event) => {
        event.preventDefault();
        void handleDownload();
      }}
    >
      {busy ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <Download className="h-4 w-4" />
      )}
      تنزيل PDF
    </DropdownMenuItem>
  );
}
