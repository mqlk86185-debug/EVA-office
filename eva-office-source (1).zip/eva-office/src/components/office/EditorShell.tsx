"use client";

import { Link } from "@/components/office/Link";
import { ChevronRight, Check, Loader2, Star } from "lucide-react";
import type { ReactNode } from "react";
import { useToolbarsHidden } from "@/lib/office/toolbars-hidden";
import { ToolbarsToggleButton } from "@/components/office/ToolbarsToggleButton";

export type SaveState = "idle" | "saving" | "saved" | "error";

/** Shared chrome for every EVA Office editor: back, live title, save state, actions. */
export function EditorShell({
  backHref,
  title,
  onTitleChange,
  saveState,
  favorite,
  onToggleFavorite,
  actions,
  toolbar,
  children,
  accent = "var(--eva)",
}: {
  backHref: string;
  title: string;
  onTitleChange: (title: string) => void;
  saveState: SaveState;
  favorite?: boolean;
  onToggleFavorite?: () => void;
  actions?: ReactNode;
  toolbar?: ReactNode;
  children: ReactNode;
  accent?: string;
}) {
  const tools = useToolbarsHidden();
  return (
    <div className="flex min-h-screen flex-col" style={{ ["--app-accent" as string]: accent }}>
      <header className="no-print sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur-xl">
        <div className="flex items-center gap-1 px-2 py-2">
          <Link
            href={backHref}
            aria-label="رجوع"
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          >
            <ChevronRight className="h-5 w-5" />
          </Link>

          <input
            value={title}
            onChange={(e) => onTitleChange(e.target.value)}
            placeholder="بدون عنوان"
            aria-label="عنوان الملف"
            className="min-w-0 flex-1 truncate rounded-lg bg-transparent px-2 py-1.5 font-display text-[15px] font-medium outline-none focus:bg-accent/60"
          />

          <span className="shrink-0 px-1 text-muted-foreground" aria-live="polite">
            {saveState === "saving" && <Loader2 className="h-4 w-4 animate-spin" />}
            {saveState === "saved" && <Check className="h-4 w-4 text-emerald-500" />}
            {saveState === "error" && <span className="text-xs text-destructive">لم يُحفظ</span>}
          </span>

          {onToggleFavorite && (
            <button
              type="button"
              onClick={onToggleFavorite}
              aria-label="المفضلة"
              className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-accent"
            >
              <Star className={`h-4.5 w-4.5 ${favorite ? "fill-amber-400 text-amber-400" : ""}`} />
            </button>
          )}

          {actions}
          {toolbar && <ToolbarsToggleButton hidden={tools.hidden} onToggle={tools.toggle} />}
        </div>
        {toolbar && <div hidden={tools.hidden}>{toolbar}</div>}
      </header>

      <div className="flex-1">{children}</div>
    </div>
  );
}
