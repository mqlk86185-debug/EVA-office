"use client";

/**
 * زر تصدير أي عنصر في الصفحة إلى PDF.
 *
 * لماذا لا يحدث خطأ `window is not defined`؟
 * - الملف لا يستورد jspdf أو html2canvas-pro في أعلى الملف إطلاقًا.
 * - الاستيراد يتم ديناميكيًا (`await import(...)`) داخل معالج الضغط فقط،
 *   أي بعد أن يعمل التطبيق في المتصفح، فلا يصل الكود إلى خادم SSR.
 *
 * الاستخدام:
 *   <div id="my-report"> ... المحتوى العربي ... </div>
 *   <ExportPdfButton targetId="my-report" fileName="تقرير" />
 */

import { useState } from "react";
import { Loader2, FileDown } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";

type Props = {
  /** نفس قيمة الـ id الموجودة على العنصر المراد تصديره. */
  targetId: string;
  /** اسم الملف بدون الامتداد. */
  fileName?: string;
  /** حجم الورقة. */
  format?: "a4" | "letter";
  orientation?: "portrait" | "landscape";
  label?: string;
  className?: string;
};

export function ExportPdfButton({
  targetId,
  fileName = "document",
  format = "a4",
  orientation = "portrait",
  label = "تصدير PDF",
  className,
}: Props) {
  const [busy, setBusy] = useState(false);

  const handleExport = async () => {
    const node = document.getElementById(targetId);
    if (!node) {
      toast.error("لم يتم العثور على المحتوى المطلوب تصديره");
      return;
    }

    setBusy(true);
    try {
      // 1) تحميل المكتبتين داخل المتصفح فقط.
      const [{ default: html2canvas }, { jsPDF }] = await Promise.all([
        import("html2canvas-pro"),
        import("jspdf"),
      ]);

      // 2) انتظار الخطوط والصور حتى لا تظهر الحروف العربية مشوّهة أو ناقصة.
      await (document as Document & { fonts?: FontFaceSet }).fonts?.ready;
      await new Promise<void>((r) => requestAnimationFrame(() => r()));

      // 3) تحويل العنصر إلى صورة. html2canvas-pro يدعم ألوان oklch
      //    المستخدمة في نظام التصميم، بعكس html2canvas الأصلي.
      const canvas = await html2canvas(node, {
        scale: window.innerWidth < 768 ? 1.5 : 2,
        backgroundColor: "#ffffff",
        useCORS: true,
        logging: false,
      });

      if (!canvas.width || !canvas.height) throw new Error("empty canvas");

      // 4) تركيب الصورة داخل صفحات PDF مع تقسيم المحتوى الطويل.
      const pdf = new jsPDF({ orientation, unit: "mm", format, compress: true });
      const pageW = pdf.internal.pageSize.getWidth();
      const pageH = pdf.internal.pageSize.getHeight();
      const imgH = (canvas.height * pageW) / canvas.width;
      const image = canvas.toDataURL("image/jpeg", 0.95);

      let remaining = imgH;
      let offset = 0;
      while (remaining > 0) {
        if (offset > 0) pdf.addPage(format, orientation);
        pdf.addImage(image, "JPEG", 0, -offset, pageW, imgH, undefined, "FAST");
        remaining -= pageH;
        offset += pageH;
      }

      const { saveBlob } = await import("@/lib/office/client");
      await saveBlob(pdf.output("blob"), `${fileName}.pdf`);
      toast.success("تم تصدير الملف");
    } catch (err) {
      console.error("[export-pdf] failed:", err);
      toast.error("تعذّر تصدير الملف");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Button onClick={handleExport} disabled={busy} className={className}>
      {busy ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : <FileDown className="ml-2 h-4 w-4" />}
      {label}
    </Button>
  );
}

export default ExportPdfButton;
