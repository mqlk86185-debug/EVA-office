"use client";

import { Link } from "@/components/office/Link";
import { Star, MoreVertical, Trash2, Share2, RotateCcw, XCircle } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { AppMark } from "./AppMark";
import {
  APP_META,
  DOC_TYPE_LABELS,
  fileHref,
  formatRelativeArabic,
  type OfficeFile,
} from "@/lib/office/types";

export function FileCard({
  file,
  onToggleFavorite,
  onTrash,
  onRestore,
  onDeleteForever,
  onShare,
  compact = false,
}: {
  file: OfficeFile;
  onToggleFavorite?: (file: OfficeFile) => void;
  onTrash?: (file: OfficeFile) => void;
  onRestore?: (file: OfficeFile) => void;
  onDeleteForever?: (file: OfficeFile) => void;
  onShare?: (file: OfficeFile) => void;
  compact?: boolean;
}) {
  const meta = APP_META[file.app_type] ?? APP_META.eva;
  const isFav = file.is_favorite === "yes";

  return (
    <div
      className={`group relative flex items-center gap-3 rounded-2xl border border-border bg-card p-3 transition-all hover:border-foreground/20 hover:shadow-[0_10px_30px_-18px_rgba(16,18,35,.55)] ${
        compact ? "" : "sm:p-4"
      }`}
    >
      <Link href={fileHref(file)} className="flex min-w-0 flex-1 items-center gap-3">
        <span
          className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl"
          style={{
            background: `color-mix(in oklab, ${meta.color} 14%, transparent)`,
            color: meta.color,
          }}
        >
          <AppMark app={file.app_type} className="h-6 w-6" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-1.5">
            <span className="truncate font-medium">{file.title}</span>
            {isFav && <Star className="h-3.5 w-3.5 shrink-0 fill-amber-400 text-amber-400" />}
          </span>
          <span className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground">
            <span
              className="rounded-md px-1.5 py-0.5 text-[10px] font-medium"
              style={{
                background: `color-mix(in oklab, ${meta.color} 12%, transparent)`,
                color: meta.color,
              }}
            >
              {DOC_TYPE_LABELS[file.doc_type]}
            </span>
            <span className="truncate">{formatRelativeArabic(file.updatedAt)}</span>
            {file.page_count ? <span>· {file.page_count} صفحة</span> : null}
          </span>
        </span>
      </Link>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            type="button"
            aria-label="خيارات الملف"
            className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          >
            <MoreVertical className="h-4.5 w-4.5" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="min-w-44">
          {onToggleFavorite && (
            <DropdownMenuItem onClick={() => onToggleFavorite(file)}>
              <Star className={`h-4 w-4 ${isFav ? "fill-amber-400 text-amber-400" : ""}`} />
              {isFav ? "إزالة من المفضلة" : "إضافة للمفضلة"}
            </DropdownMenuItem>
          )}
          {onShare && (
            <DropdownMenuItem onClick={() => onShare(file)}>
              <Share2 className="h-4 w-4" />
              مشاركة
            </DropdownMenuItem>
          )}
          {onRestore && (
            <DropdownMenuItem onClick={() => onRestore(file)}>
              <RotateCcw className="h-4 w-4" />
              استعادة
            </DropdownMenuItem>
          )}
          {onTrash && (
            <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => onTrash(file)}>
              <Trash2 className="h-4 w-4" />
              نقل إلى سلة المحذوفات
            </DropdownMenuItem>
          )}
          {onDeleteForever && (
            <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => onDeleteForever(file)}>
              <XCircle className="h-4 w-4" />
              حذف نهائي
            </DropdownMenuItem>
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
