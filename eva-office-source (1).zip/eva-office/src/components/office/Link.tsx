import { forwardRef, type AnchorHTMLAttributes, type MouseEvent } from "react";
import { useAppNavigate } from "@/lib/office/nav";

type LinkProps = AnchorHTMLAttributes<HTMLAnchorElement> & { href: string };

/**
 * Anchor that navigates inside the app without a full reload, accepting plain
 * hrefs with query strings (e.g. `/files?view=trash`).
 */
export const Link = forwardRef<HTMLAnchorElement, LinkProps>(function Link(
  { href, onClick, ...rest },
  ref,
) {
  const navigate = useAppNavigate();

  const handleClick = (event: MouseEvent<HTMLAnchorElement>) => {
    onClick?.(event);
    if (
      event.defaultPrevented ||
      event.button !== 0 ||
      event.metaKey ||
      event.ctrlKey ||
      event.shiftKey ||
      event.altKey ||
      rest.target === "_blank" ||
      /^([a-z]+:)?\/\//i.test(href)
    ) {
      return;
    }
    event.preventDefault();
    navigate(href);
  };

  return <a ref={ref} href={href} onClick={handleClick} {...rest} />;
});

export default Link;
