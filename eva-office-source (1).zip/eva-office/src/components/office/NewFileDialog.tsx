"use client";

import { useRef, useState } from "react";
import { useRouter } from "@/lib/office/nav";
import { toast } from "sonner";
import { FileText, ListChecks, Table2, Upload, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { createFile, uploadPdf } from "@/lib/office/client";
import { fileHref } from "@/lib/office/types";

const CHOICES = [
  {
    key: "document",
    title: "مستند EVA",
    desc: "كتابة وتنسيق مستند كامل",
    icon: FileText,
    color: "var(--eva)",
  },
  {
    key: "exam",
    title: "اختبار / أسئلة",
    desc: "أسئلة مرقّمة تلقائيًا ودرجات",
    icon: ListChecks,
    color: "#f59e0b",
  },
  {
    key: "spreadsheet",
    title: "جدول GILOX",
    desc: "بيانات ومعادلات ورسوم بيانية",
    icon: Table2,
    color: "var(--gilox)",
  },
] as const;

/** Creates a new EVA / GILOX file, or uploads a PDF into the PDF app. */
export function NewFileDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const create = async (docType: string, title: string) => {
    setBusy(docType);
    try {
      const file = await createFile({ title, doc_type: docType });
      console.log("[NewFileDialog] created", file._id, docType);
      onOpenChange(false);
      router.push(fileHref(file));
    } catch (err) {
      console.error("[NewFileDialog] create failed:", err);
      toast.error("تعذّر إنشاء الملف", { description: (err as Error).message });
    } finally {
      setBusy(null);
    }
  };

  const handleUpload = async (fileList: FileList | null) => {
    const file = fileList?.[0];
    if (!file) return;
    if (!/\.pdf$/i.test(file.name)) {
      toast.error("يُرجى اختيار ملف PDF");
      return;
    }
    setBusy("pdf");
    try {
      const created = await uploadPdf(file);
      console.log("[NewFileDialog] uploaded pdf", created._id);
      toast.success("تم رفع الملف");
      onOpenChange(false);
      router.push(fileHref(created));
    } catch (err) {
      console.error("[NewFileDialog] upload failed:", err);
      toast.error("فشل رفع الملف", { description: (err as Error).message });
    } finally {
      setBusy(null);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader className="text-right">
          <DialogTitle className="font-display">ملف جديد</DialogTitle>
        </DialogHeader>

        <div className="space-y-2">
          {CHOICES.map((choice) => {
            const Icon = choice.icon;
            return (
              <button
                key={choice.key}
                type="button"
                disabled={busy !== null}
                onClick={() => create(choice.key, choice.title)}
                className="flex w-full items-center gap-3 rounded-2xl border border-border p-3 text-right transition-all hover:border-foreground/25 hover:bg-accent/50 disabled:opacity-60"
              >
                <span
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
                  style={{
                    background: `color-mix(in oklab, ${choice.color} 15%, transparent)`,
                    color: choice.color,
                  }}
                >
                  {busy === choice.key ? (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  ) : (
                    <Icon className="h-5 w-5" />
                  )}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block font-medium">{choice.title}</span>
                  <span className="block text-xs text-muted-foreground">{choice.desc}</span>
                </span>
              </button>
            );
          })}

          <button
            type="button"
            disabled={busy !== null}
            onClick={() => inputRef.current?.click()}
            className="flex w-full items-center gap-3 rounded-2xl border border-dashed border-border p-3 text-right transition-all hover:border-foreground/25 hover:bg-accent/50 disabled:opacity-60"
          >
            <span
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
              style={{
                background: "color-mix(in oklab, var(--pdfapp) 15%, transparent)",
                color: "var(--pdfapp)",
              }}
            >
              {busy === "pdf" ? <Loader2 className="h-5 w-5 animate-spin" /> : <Upload className="h-5 w-5" />}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block font-medium">فتح ملف PDF</span>
              <span className="block text-xs text-muted-foreground">ارفع ملفًا لقراءته وإدارته</span>
            </span>
          </button>
          <input
            ref={inputRef}
            type="file"
            accept="application/pdf,.pdf"
            className="hidden"
            onChange={(e) => handleUpload(e.target.files)}
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}
