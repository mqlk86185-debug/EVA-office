"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { documentCss, contentBoxMm } from "@/lib/office/render";
import { pageHeightMm, pageWidthMm, type PageSetup } from "@/lib/office/types";
import { MM_TO_PX } from "@/lib/office/render";

const SCOPE = ".eva-print-scope";

/**
 * Renders already-paginated HTML chunks as real, scaled paper sheets.
 * Identical markup + CSS to the exported PDF, so the preview is faithful.
 */
export function PagePreview({
  pages,
  setup,
  title,
  className = "",
}: {
  pages: string[];
  setup: PageSetup;
  title: string;
  className?: string;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);
  const css = useMemo(() => documentCss(setup, false, SCOPE), [setup]);
  const pageW = pageWidthMm(setup) * MM_TO_PX;
  const pageH = pageHeightMm(setup) * MM_TO_PX;
  const box = contentBoxMm(setup);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const update = () => {
      const available = el.clientWidth - 8;
      setScale(Math.min(1, Math.max(1, available) / pageW));
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, [pageW]);

  const total = Math.max(pages.length, 1);

  return (
    <div ref={wrapRef} className={`w-full ${className}`}>
      <style dangerouslySetInnerHTML={{ __html: css }} />
      <div
        className="eva-print-scope mx-auto"
        dir="ltr"
        style={{ width: pageW * scale }}
      >
        {(pages.length ? pages : [""]).map((inner, i) => (
          <div
            key={i}
            style={{
              width: pageW * scale,
              height: pageH * scale,
              marginBottom: 18 * scale,
              overflow: "hidden",
            }}
          >
            <div
              style={{
                transform: `scale(${scale})`,
                transformOrigin: "top left",
                width: pageW,
                direction: "rtl",
              }}
            >
              <div className="page">
                <div className="page-frame" aria-hidden="true">
                  <span />
                  <span />
                  <span />
                  <span />
                </div>
                {box.hasHeader && (
                  <div className="page-header">
                    <span>{setup.header}</span>
                    <span>{title}</span>
                  </div>
                )}
                <div className="page-content" dangerouslySetInnerHTML={{ __html: inner }} />
                {box.hasFooter && (
                  <div className="page-footer">
                    <span>{setup.footer}</span>
                    <span>{setup.show_page_numbers ? `صفحة ${i + 1} من ${total}` : ""}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
