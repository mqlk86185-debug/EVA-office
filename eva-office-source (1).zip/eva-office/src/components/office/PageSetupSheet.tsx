"use client";

import { useEffect, useRef, type CSSProperties } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import {
  CUSTOM_PAGE_MAX,
  CUSTOM_PAGE_MIN,
  PAGE_BORDER_STYLES,
  PAGE_DIMENSIONS,
  type PageBorderStyle,
  type PageSetup,
  type PageSize,
} from "@/lib/office/types";

const SIZES: PageSize[] = ["a4", "a5", "letter", "custom"];

const BORDER_COLORS = ["#334155", "#111827", "#4f46e5", "#0ea5e9", "#059669", "#d97706", "#dc2626", "#9333ea"];

/** Miniature of each page-border style — mirrors `pageFrameCss` in render.ts. */
function BorderThumb({ variant, color }: { variant: PageBorderStyle; color: string }) {
  const box: CSSProperties = { position: "absolute", inset: 4 };
  const corner = (
    pos: CSSProperties,
    a: "borderTop" | "borderBottom",
    b: "borderRight" | "borderLeft"
  ): CSSProperties => ({
    position: "absolute",
    width: 11,
    height: 11,
    [a]: `2.5px solid ${color}`,
    [b]: `2.5px solid ${color}`,
    ...pos,
  });

  switch (variant) {
    case "none":
      return <span style={{ ...box, border: "1px dashed #cbd5e1", borderRadius: 2 }} />;
    case "solid":
      return <span style={{ ...box, border: `1.5px solid ${color}` }} />;
    case "thick":
      return <span style={{ ...box, border: `4px solid ${color}` }} />;
    case "dashed":
      return <span style={{ ...box, border: `1.5px dashed ${color}` }} />;
    case "dotted":
      return <span style={{ ...box, border: `2px dotted ${color}` }} />;
    case "rounded":
      return <span style={{ ...box, border: `1.5px solid ${color}`, borderRadius: 8 }} />;
    case "double":
      return (
        <span style={{ ...box, border: `1.2px solid ${color}` }}>
          <span style={{ position: "absolute", inset: 2, border: `1.2px solid ${color}` }} />
        </span>
      );
    case "classic":
      return (
        <span style={{ ...box, border: `3px solid ${color}` }}>
          <span style={{ position: "absolute", inset: 3, border: `1px solid ${color}` }} />
        </span>
      );
    case "shadow":
      // Same offset copy as `pageFrameCss`, kept inside the tile so it is not clipped.
      return (
        <span style={{ position: "absolute", inset: 0 }}>
          <span
            style={{
              position: "absolute",
              top: 7,
              left: 7,
              right: 2,
              bottom: 2,
              border: `1.5px solid ${color}`,
              opacity: 0.4,
            }}
          />
          <span
            style={{
              position: "absolute",
              top: 3,
              left: 3,
              right: 6,
              bottom: 6,
              background: "#fff",
              border: `1.5px solid ${color}`,
            }}
          />
        </span>
      );
    case "corners":
      return (
        <span style={box}>
          <span style={corner({ top: 0, right: 0 }, "borderTop", "borderRight")} />
          <span style={corner({ top: 0, left: 0 }, "borderTop", "borderLeft")} />
          <span style={corner({ bottom: 0, right: 0 }, "borderBottom", "borderRight")} />
          <span style={corner({ bottom: 0, left: 0 }, "borderBottom", "borderLeft")} />
        </span>
      );
    default:
      return null;
  }
}

/** Page size / orientation / margins / header / footer controls. */
export function PageSetupSheet({
  open,
  onOpenChange,
  setup,
  onChange,
  focus = null,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  setup: PageSetup;
  onChange: (setup: PageSetup) => void;
  /** Scrolls straight to a section when the sheet opens. */
  focus?: "border" | null;
}) {
  const patch = (part: Partial<PageSetup>) => onChange({ ...setup, ...part });
  const borderRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open || focus !== "border") return;
    const t = setTimeout(() => borderRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 220);
    return () => clearTimeout(t);
  }, [open, focus]);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="max-h-[88vh] overflow-y-auto rounded-t-3xl thin-scroll">
        <SheetHeader>
          <SheetTitle className="font-display">إعداد الصفحة</SheetTitle>
        </SheetHeader>

        <div className="space-y-6 px-4 pb-8">
          <div className="space-y-2">
            <Label>حجم الصفحة</Label>
            <div className="grid grid-cols-4 gap-2">
              {SIZES.map((size) => (
                <button
                  key={size}
                  type="button"
                  onClick={() =>
                    patch(
                      size === "custom"
                        ? {
                            size,
                            custom_w: setup.custom_w ?? 210,
                            custom_h: setup.custom_h ?? 297,
                          }
                        : { size }
                    )
                  }
                  className={`rounded-xl border px-2 py-2.5 text-sm transition-all ${
                    setup.size === size
                      ? "border-primary bg-primary/10 font-semibold text-primary"
                      : "border-border hover:bg-accent"
                  }`}
                >
                  {PAGE_DIMENSIONS[size].label}
                  <span className="block text-[10px] text-muted-foreground">
                    {size === "custom"
                      ? `${setup.custom_w ?? 210}×${setup.custom_h ?? 297} مم`
                      : `${PAGE_DIMENSIONS[size].w}×${PAGE_DIMENSIONS[size].h} مم`}
                  </span>
                </button>
              ))}
            </div>

            {setup.size === "custom" && (
              <div className="grid grid-cols-2 gap-3 rounded-xl border border-border p-3">
                <div className="space-y-1.5">
                  <Label htmlFor="ps-cw" className="text-xs">
                    العرض (مم)
                  </Label>
                  <Input
                    id="ps-cw"
                    type="number"
                    inputMode="numeric"
                    min={CUSTOM_PAGE_MIN}
                    max={CUSTOM_PAGE_MAX}
                    value={setup.custom_w ?? 210}
                    onChange={(e) => patch({ custom_w: Number(e.target.value) })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="ps-ch" className="text-xs">
                    الارتفاع (مم)
                  </Label>
                  <Input
                    id="ps-ch"
                    type="number"
                    inputMode="numeric"
                    min={CUSTOM_PAGE_MIN}
                    max={CUSTOM_PAGE_MAX}
                    value={setup.custom_h ?? 297}
                    onChange={(e) => patch({ custom_h: Number(e.target.value) })}
                  />
                </div>
                <p className="col-span-2 text-[11px] text-muted-foreground">
                  من {CUSTOM_PAGE_MIN} إلى {CUSTOM_PAGE_MAX} مم لكل بُعد.
                </p>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>اتجاه الصفحة</Label>
            <div className="grid grid-cols-2 gap-2">
              {(["portrait", "landscape"] as const).map((o) => (
                <button
                  key={o}
                  type="button"
                  onClick={() => patch({ orientation: o })}
                  className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-sm transition-all ${
                    setup.orientation === o
                      ? "border-primary bg-primary/10 font-semibold text-primary"
                      : "border-border hover:bg-accent"
                  }`}
                >
                  <span
                    className="inline-block rounded-[3px] border-2 border-current"
                    style={
                      o === "portrait"
                        ? { width: 13, height: 18 }
                        : { width: 18, height: 13 }
                    }
                  />
                  {o === "portrait" ? "عمودي" : "أفقي"}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label>هوامش الصفحة</Label>
              <span className="text-sm font-medium tabular-nums text-muted-foreground">
                {setup.margin} مم
              </span>
            </div>
            <Slider
              min={5}
              max={40}
              step={1}
              value={[setup.margin]}
              onValueChange={([v]) => patch({ margin: v })}
            />
          </div>

          <div className="space-y-3">
            <Label>لون الصفحة</Label>
            <div className="flex flex-wrap items-center gap-2">
              {["#ffffff", "#fdf6e3", "#fef3c7", "#fce7f3", "#e0f2fe", "#dcfce7", "#ede9fe", "#f1f5f9", "#1e293b"].map((c) => (
                <button
                  key={c}
                  type="button"
                  aria-label={`لون الصفحة ${c}`}
                  onClick={() => patch({ page_color: c })}
                  className={`h-8 w-8 rounded-full border-2 transition-transform ${
                    (setup.page_color || "#ffffff") === c ? "scale-110 border-foreground" : "border-border hover:scale-105"
                  }`}
                  style={{ background: c }}
                />
              ))}
              <label className="relative inline-flex h-8 w-8 cursor-pointer items-center justify-center overflow-hidden rounded-full border border-dashed border-border text-xs text-muted-foreground">
                <input
                  type="color"
                  value={setup.page_color || "#ffffff"}
                  onChange={(e) => patch({ page_color: e.target.value })}
                  className="absolute inset-0 cursor-pointer opacity-0"
                />
                +
              </label>
            </div>
          </div>

          <div ref={borderRef} className="scroll-mt-4 space-y-3">
            <div className="flex items-center justify-between">
              <Label>إطار الصفحة</Label>
              <span className="text-xs text-muted-foreground">يظهر في المستند والمعاينة وملف PDF</span>
            </div>
            <div className="grid grid-cols-5 gap-2">
              {PAGE_BORDER_STYLES.map((b) => (
                <button
                  key={b.key}
                  type="button"
                  onClick={() => patch({ border_style: b.key })}
                  aria-pressed={setup.border_style === b.key}
                  className={`rounded-xl border p-1.5 text-center transition-all ${
                    setup.border_style === b.key
                      ? "border-primary bg-primary/10 ring-1 ring-primary"
                      : "border-border hover:bg-accent"
                  }`}
                >
                  <span className="relative block h-14 w-full overflow-hidden rounded-[3px] bg-white shadow-inner">
                    <BorderThumb variant={b.key} color={setup.border_color || "#334155"} />
                  </span>
                  <span
                    className={`mt-1 block text-[10px] leading-tight ${
                      setup.border_style === b.key ? "font-semibold text-primary" : "text-muted-foreground"
                    }`}
                  >
                    {b.label}
                  </span>
                </button>
              ))}
            </div>

            {setup.border_style !== "none" && (
              <div className="space-y-4 rounded-xl border border-border p-3">
                <div className="space-y-2">
                  <Label className="text-xs">لون الإطار</Label>
                  <div className="flex flex-wrap items-center gap-2">
                    {BORDER_COLORS.map((c) => (
                      <button
                        key={c}
                        type="button"
                        aria-label={`لون ${c}`}
                        onClick={() => patch({ border_color: c })}
                        className={`h-7 w-7 rounded-full border-2 transition-transform ${
                          setup.border_color === c
                            ? "scale-110 border-foreground"
                            : "border-transparent hover:scale-105"
                        }`}
                        style={{ background: c }}
                      />
                    ))}
                    <label className="relative inline-flex h-7 w-7 cursor-pointer items-center justify-center overflow-hidden rounded-full border border-dashed border-border text-[10px] text-muted-foreground">
                      <input
                        type="color"
                        value={setup.border_color || "#334155"}
                        onChange={(e) => patch({ border_color: e.target.value })}
                        className="absolute inset-0 cursor-pointer opacity-0"
                      />
                      +
                    </label>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs">سُمك الخط</Label>
                    <span className="text-xs font-medium tabular-nums text-muted-foreground">
                      {setup.border_width} بكسل
                    </span>
                  </div>
                  <Slider
                    min={1}
                    max={8}
                    step={1}
                    value={[setup.border_width]}
                    onValueChange={([v]) => patch({ border_width: v })}
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs">المسافة من حافة الصفحة</Label>
                    <span className="text-xs font-medium tabular-nums text-muted-foreground">
                      {setup.border_gap} مم
                    </span>
                  </div>
                  <Slider
                    min={0}
                    max={Math.max(4, setup.margin)}
                    step={1}
                    value={[Math.min(setup.border_gap, Math.max(4, setup.margin))]}
                    onValueChange={([v]) => patch({ border_gap: v })}
                  />
                </div>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="ps-header">رأس الصفحة</Label>
            <Input
              id="ps-header"
              value={setup.header}
              placeholder="نص يظهر أعلى كل صفحة"
              onChange={(e) => patch({ header: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="ps-footer">تذييل الصفحة</Label>
            <Input
              id="ps-footer"
              value={setup.footer}
              placeholder="نص يظهر أسفل كل صفحة"
              onChange={(e) => patch({ footer: e.target.value })}
            />
          </div>

          <div className="flex items-center justify-between rounded-xl border border-border p-3">
            <div>
              <Label htmlFor="ps-nums">أرقام الصفحات</Label>
              <p className="text-xs text-muted-foreground">إظهار «صفحة ١ من ن» في التذييل</p>
            </div>
            <Switch
              id="ps-nums"
              checked={setup.show_page_numbers}
              onCheckedChange={(v) => patch({ show_page_numbers: v })}
            />
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
