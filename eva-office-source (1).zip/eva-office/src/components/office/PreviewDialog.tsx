"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Download, Loader2, FileText, Printer, Image as ImageIcon } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { PagePreview } from "./PagePreview";
import { paginateHtml } from "@/lib/office/paginate";
import { exportPdf, exportPng } from "@/lib/office/client";
import type { PageSetup } from "@/lib/office/types";
import { printPages } from "@/lib/office/print";

/**
 * Document preview + PDF export.
 * The very same paginated chunks shown here are what the server turns into PDF,
 * so the export is a faithful copy of the preview.
 */
export function PreviewDialog({
  open,
  onOpenChange,
  getHtml,
  setup,
  title,
  fileId,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  getHtml: () => string;
  setup: PageSetup;
  title: string;
  fileId: string;
}) {
  const [pages, setPages] = useState<string[]>([]);
  const [building, setBuilding] = useState(false);
  const [exporting, setExporting] = useState<"pdf" | "png" | null>(null);
  const buildVersion = useRef(0);

  const build = useCallback(async () => {
    const version = ++buildVersion.current;
    setBuilding(true);
    try {
      const html = getHtml();
      const result = await paginateHtml(html, setup);
      if (version !== buildVersion.current) return;
      setPages(result);
      console.log("[PreviewDialog] built", result.length, "pages");
    } catch (err) {
      if (version !== buildVersion.current) return;
      console.error("[PreviewDialog] pagination failed:", err);
      toast.error("تعذّر إنشاء المعاينة");
      setPages([getHtml()]);
    } finally {
      if (version === buildVersion.current) setBuilding(false);
    }
  }, [getHtml, setup]);

  useEffect(() => {
    if (open) void build();
    return () => { buildVersion.current++; };
  }, [open, build]);

  const handleExport = async (format: "pdf" | "png") => {
    if (!pages.length || exporting) return;
    setExporting(format);
    try {
      const result =
        format === "pdf"
          ? await exportPdf(fileId, pages, setup, title)
          : await exportPng(fileId, pages, setup, title);
      toast.success(
        format === "pdf"
          ? `تم حفظ ملف PDF (${result.pages} صفحة)`
          : `تم حفظ ${result.pages} صورة PNG`
      );
    } catch (err) {
      console.error("[PreviewDialog] export failed:", err);
      toast.error(format === "pdf" ? "فشل تصدير PDF" : "فشل تصدير الصور", {
        description: (err as Error).message,
      });
    } finally {
      setExporting(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="flex h-[92vh] w-[calc(100vw-1.5rem)] max-w-4xl flex-col gap-0 overflow-hidden p-0 sm:w-[calc(100vw-4rem)]"
      >
        <DialogHeader className="border-b border-border px-4 py-3 text-right">
          <DialogTitle className="flex items-center gap-2 font-display text-base">
            <FileText className="h-4.5 w-4.5" />
            معاينة المستند
            {pages.length > 0 && (
              <span className="text-xs font-normal text-muted-foreground">
                {pages.length} صفحة
              </span>
            )}
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto bg-muted/50 p-3 thin-scroll">
          {building ? (
            <div className="flex h-full items-center justify-center gap-2 text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin" />
              جارٍ ترتيب الصفحات…
            </div>
          ) : (
            <PagePreview pages={pages} setup={setup} title={title} />
          )}
        </div>

        <div className="flex items-center gap-2 border-t border-border bg-background px-4 py-3">
          <Button
            onClick={() => void handleExport("pdf")}
            disabled={!!exporting || building || !pages.length}
            className="flex-1"
          >
            {exporting === "pdf" ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Download className="h-4 w-4" />
            )}
            تصدير PDF
          </Button>
          <Button
            variant="outline"
            onClick={() => void handleExport("png")}
            disabled={!!exporting || building || !pages.length}
            className="flex-1"
          >
            {exporting === "png" ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <ImageIcon className="h-4 w-4" />
            )}
            تصدير صور PNG
          </Button>
          <Button
            variant="outline"
            onClick={() => void printPages(pages, setup, title).catch(() => toast.error("تعذّر فتح الطباعة؛ يمكنك تصدير PDF"))}
            disabled={building || !!exporting || !pages.length}
            aria-label="طباعة"
          >
            <Printer className="h-4 w-4" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
