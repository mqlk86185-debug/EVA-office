import { useEffect, useMemo, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { TEXT_FONTS } from "@/lib/office/text-style";
import type { PageBorderStyle } from "@/lib/office/types";
import type { StationerySpec } from "@/lib/office/templates/stationery";
import { applyDesign, templateColors, type StationeryDesign } from "@/lib/office/templates/stationery-custom";
import { StationeryPreview } from "./StationeryPreview";

const BORDERS: { value: PageBorderStyle; label: string }[] = [
  { value: "none", label: "بدون" },
  { value: "solid", label: "متصل" },
  { value: "double", label: "مزدوج" },
  { value: "dashed", label: "متقطع" },
  { value: "dotted", label: "منقط" },
];

const selectCls = "h-9 w-full rounded-md border border-input bg-background px-2 text-sm text-foreground";

export function StationeryCustomizer({ spec, name, onClose, onSave }: {
  spec: StationerySpec | null;
  name: string;
  onClose: () => void;
  onSave: (spec: StationerySpec, name: string) => void;
}) {
  const original = useMemo(() => (spec ? templateColors(spec.html) : []), [spec]);
  const [design, setDesign] = useState<StationeryDesign>({ colors: {}, font: "", border_style: "none", border_color: "#334155", border_width: 2 });
  const [newName, setNewName] = useState("");

  useEffect(() => {
    if (!spec) return;
    setDesign({
      colors: {}, font: "",
      border_style: (spec.setup?.border_style as PageBorderStyle) ?? "none",
      border_color: spec.setup?.border_color ?? spec.accent,
      border_width: spec.setup?.border_width ?? 2,
    });
    setNewName(`${name} (مخصص)`);
  }, [spec, name]);

  if (!spec) return null;
  const result = applyDesign(spec, design);
  const set = (patch: Partial<StationeryDesign>) => setDesign((d) => ({ ...d, ...patch }));

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent dir="rtl" className="max-h-[92dvh] w-[calc(100vw-1rem)] max-w-3xl overflow-y-auto p-4">
        <DialogHeader className="pr-7 text-right"><DialogTitle className="font-display">تخصيص القالب</DialogTitle></DialogHeader>
        <div className="grid gap-5 sm:grid-cols-[220px_1fr]">
          <div className="mx-auto w-44 sm:w-full">
            <StationeryPreview spec={result} />
          </div>
          <div className="space-y-5">
            <section className="space-y-2">
              <Label>الألوان</Label>
              <div className="flex flex-wrap gap-2">
                {original.map((c) => (
                  <label key={c} className="relative size-10 cursor-pointer overflow-hidden rounded-md border border-border" style={{ background: design.colors[c] ?? c }} aria-label={`تغيير اللون ${c}`}>
                    <input type="color" value={design.colors[c] ?? c} onChange={(e) => set({ colors: { ...design.colors, [c]: e.target.value } })} className="absolute inset-0 cursor-pointer opacity-0" />
                  </label>
                ))}
                {Object.keys(design.colors).length > 0 && <Button size="sm" variant="ghost" onClick={() => set({ colors: {} })}>إعادة الألوان</Button>}
              </div>
            </section>
            <section className="space-y-2">
              <Label htmlFor="st-font">الخط</Label>
              <select id="st-font" value={design.font} onChange={(e) => set({ font: e.target.value })} className={selectCls}>
                <option value="">الخط الافتراضي</option>
                {TEXT_FONTS.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
              </select>
            </section>
            <section className="space-y-3">
              <Label>حدود الصفحة</Label>
              <div className="grid grid-cols-[1fr_auto] gap-2">
                <select aria-label="نوع الحد" value={design.border_style} onChange={(e) => set({ border_style: e.target.value as PageBorderStyle })} className={selectCls}>
                  {BORDERS.map((b) => <option key={b.value} value={b.value}>{b.label}</option>)}
                </select>
                <label className="relative size-9 cursor-pointer overflow-hidden rounded-md border border-border" style={{ background: design.border_color }} aria-label="لون الحد">
                  <input type="color" value={design.border_color} onChange={(e) => set({ border_color: e.target.value })} className="absolute inset-0 cursor-pointer opacity-0" />
                </label>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-muted-foreground">السماكة</span>
                <Slider min={1} max={8} step={1} value={[design.border_width]} onValueChange={([v]) => set({ border_width: v ?? 2 })} disabled={design.border_style === "none"} />
                <span className="w-6 text-sm">{design.border_width}</span>
              </div>
            </section>
            <section className="space-y-2">
              <Label htmlFor="st-name">اسم القالب الجديد</Label>
              <Input id="st-name" value={newName} maxLength={60} onChange={(e) => setNewName(e.target.value)} />
            </section>
            <div className="flex gap-2">
              <Button className="flex-1" disabled={!newName.trim()} onClick={() => onSave(result, newName.trim())}>حفظ كقالب جديد</Button>
              <Button variant="outline" onClick={onClose}>إلغاء</Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
