import { useLayoutEffect, useRef, useState } from "react";
import type { StationerySpec } from "@/lib/office/templates/stationery";

/** Scaled A4 thumbnail of a stationery template, including its page border. */
export function StationeryPreview({ spec }: { spec: StationerySpec }) {
  const ref = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(0.2);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const update = () => setScale(el.clientWidth / 794);
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const s = spec.setup;
  const border = s?.border_style && s.border_style !== "none" ? `${s.border_width ?? 2}px ${s.border_style} ${s.border_color ?? "#334155"}` : undefined;
  return (
    <div ref={ref} className="relative aspect-[210/297] w-full overflow-hidden rounded-md border border-border shadow-sm" style={{ backgroundColor: "#fff" }}>
      <div dir="rtl" className="pointer-events-none absolute right-0 top-0 origin-top-right"
        style={{ width: 794, height: 1123, transform: `scale(${scale})`, padding: 30, backgroundColor: "#fff" }}>
        {border && <div className="absolute" style={{ inset: 14, border }} />}
        <div dangerouslySetInnerHTML={{ __html: spec.html }} />
      </div>
    </div>
  );
}
