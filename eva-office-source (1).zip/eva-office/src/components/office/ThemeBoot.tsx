"use client";

import { useEffect } from "react";

/**
 * Applies the persisted EVA Office theme (light/dark) as early as possible.
 * Kept tiny on purpose: the whole suite reads `document.documentElement.classList`.
 */
export function ThemeBoot() {
  useEffect(() => {
    try {
      const saved = localStorage.getItem("eva-office-theme");
      if (saved === "dark") document.documentElement.classList.add("dark");
      else document.documentElement.classList.remove("dark");
    } catch (err) {
      console.error("[ThemeBoot] failed to read stored theme:", err);
    }
  }, []);
  return null;
}

export function setOfficeTheme(theme: "light" | "dark") {
  try {
    localStorage.setItem("eva-office-theme", theme);
  } catch (err) {
    console.error("[setOfficeTheme] failed to persist theme:", err);
  }
  document.documentElement.classList.toggle("dark", theme === "dark");
}

export function getOfficeTheme(): "light" | "dark" {
  if (typeof document === "undefined") return "light";
  return document.documentElement.classList.contains("dark") ? "dark" : "light";
}
