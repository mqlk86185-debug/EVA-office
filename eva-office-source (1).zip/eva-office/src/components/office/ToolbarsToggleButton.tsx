import { Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";

export function ToolbarsToggleButton({ hidden, onToggle }: { hidden: boolean; onToggle: () => void }) {
  const label = hidden ? "إظهار الأدوات" : "إخفاء الأدوات";
  return (
    <Button
      type="button"
      variant={hidden ? "secondary" : "ghost"}
      size="icon"
      aria-label={label}
      title={label}
      aria-pressed={hidden}
      onClick={onToggle}
      className="shrink-0"
    >
      {hidden ? <Eye /> : <EyeOff />}
    </Button>
  );
}
