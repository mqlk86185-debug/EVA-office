"use client";

import { useState, type RefObject } from "react";
import {
  Bold, Italic, Underline, Type, Baseline, Highlighter, AlignRight, AlignCenter,
  AlignLeft, AlignJustify, List, ListOrdered, Minus, Image as ImageIcon, Table2,
  Square, TextCursorInput, FileDown, Settings2, Search, Undo2, Redo2, Copy,
  Scissors, ClipboardPaste, Rows3, Columns3, Merge, Split, Grid2x2X, Trash2,
  IndentIncrease, IndentDecrease, SeparatorHorizontal, MousePointerSquareDashed, Eraser,
  Frame, SlidersHorizontal, Strikethrough, Superscript, Subscript, ChevronUp, ChevronDown,
} from "lucide-react";
import { toast } from "sonner";
import { TBtn, TColor, TGroup, TSelect, ToolRow } from "./ToolPrimitives";
import * as ed from "@/lib/office/editor-commands";
import { useToolbarVisibility } from "@/lib/office/toolbar-visibility";
import { ToolbarSettingsSheet } from "./ToolbarSettingsSheet";
import { TOOL_DEFS } from "./tool-defs";

const TABS = [
  { key: "text", label: "نص" },
  { key: "para", label: "فقرة" },
  { key: "insert", label: "إدراج" },
  { key: "table", label: "جدول" },
  { key: "page", label: "صفحة" },
] as const;

type TabKey = (typeof TABS)[number]["key"];

const FONTS = [
  { value: "IBM Plex Sans Arabic", label: "IBM Plex عربي" },
  { value: "Readex Pro", label: "ريدكس" },
  { value: "Amiri", label: "أميري" },
  { value: "Cairo", label: "القاهرة" },
  { value: "Tahoma", label: "Tahoma" },
  { value: "Georgia", label: "Georgia" },
  { value: "Courier New", label: "Courier" },
];

const SIZES = [10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 40, 48];
const LINE_HEIGHTS = [1, 1.15, 1.5, 1.75, 2, 2.5, 3];
const PARA_SPACING = [0, 4, 8, 12, 18, 24, 32];

export function DocToolbar({
  editorRef,
  sync,
  selectedCells,
  cellSelectMode,
  setCellSelectMode,
  onOpenSetup,
  onOpenPageBorder,
  onPreview,
  onFind,
  freeTextMode,
  onToggleFreeText,
  toolsMenuOpen,
  setToolsMenuOpen,
}: {
  editorRef: RefObject<HTMLDivElement | null>;
  sync: () => void;
  selectedCells: HTMLTableCellElement[];
  cellSelectMode: boolean;
  setCellSelectMode: (v: boolean) => void;
  onOpenSetup: () => void;
  onOpenPageBorder: () => void;
  onPreview: () => void;
  onFind: () => void;
  freeTextMode: boolean;
  onToggleFreeText: () => void;
  toolsMenuOpen: boolean;
  setToolsMenuOpen: (open: boolean) => void;
}) {
  const [tab, setTab] = useState<TabKey>("text");
  const [textColor, setTextColor] = useState("#111827");
  const [highlight, setHighlight] = useState("#fde047");
  const [shapeColor, setShapeColor] = useState("#6366f1");
  const [dividerColor, setDividerColor] = useState("#111827");
  const [dividerThickness, setDividerThickness] = useState(2);
  const [dividerWidth, setDividerWidth] = useState(100);
  const [frameColor, setFrameColor] = useState("#6366f1");
  const [frameThickness, setFrameThickness] = useState(2);
  const [frameStyle, setFrameStyle] = useState<(typeof ed.FRAME_STYLES)[number]["key"]>("solid");
  const [uploading, setUploading] = useState(false);
  const { isVisible, toggle: toggleTool, showAll: showAllTools, hiddenCount } = useToolbarVisibility();

  const editor = () => editorRef.current;

  const run = (fn: () => void) => {
    const el = editor();
    if (!el) return;
    ed.focusEditor(el);
    fn();
    sync();
  };

  const primaryCell = selectedCells[0] ?? null;

  const handleImageFile = async (file: File | undefined) => {
    if (!file) return;
    setUploading(true);
    try {
      if (!file.type.startsWith("image/")) throw new Error("اختر ملف صورة صالحاً");
      const bitmap = await createImageBitmap(file);
      const ratio = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(bitmap.width * ratio));
      canvas.height = Math.max(1, Math.round(bitmap.height * ratio));
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("تعذّر تجهيز الصورة");
      ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      bitmap.close();
      const url = canvas.toDataURL(file.type === "image/png" ? "image/png" : "image/jpeg", 0.84);
      run(() => { const el = editor(); if (el) ed.insertImage(el, url); });
      toast.success("تمت إضافة الصورة");
    } catch (err) {
      console.error("[DocToolbar] image upload failed:", err);
      toast.error("تعذّر رفع الصورة", { description: (err as Error).message });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="border-t border-border bg-background/95">
      <div className="no-scrollbar flex items-center gap-1 overflow-x-auto px-2 py-1.5">
        {TABS.map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            className={`shrink-0 rounded-lg px-2.5 py-1.5 text-xs font-medium transition-colors sm:px-3 sm:text-[13px] ${
              tab === t.key ? "bg-foreground text-background" : "text-muted-foreground hover:bg-accent"
            }`}
          >
            {t.label}
          </button>
        ))}
        <div className="flex shrink-0 items-center gap-1">
          <TBtn label="تراجع" onClick={() => run(() => ed.exec("undo"))}>
            <Undo2 className="h-4 w-4" />
          </TBtn>
          <TBtn label="إعادة" onClick={() => run(() => ed.exec("redo"))}>
            <Redo2 className="h-4 w-4" />
          </TBtn>
        </div>
      </div>

      {tab === "text" && (
        <ToolRow>
          {isVisible("text-font-family") && (
            <TSelect
              label="نوع الخط"
              value=""
              width="w-36"
              options={[{ value: "", label: "نوع الخط" }, ...FONTS]}
              onChange={(v) => v && run(() => ed.setFontFamily(v))}
            />
          )}
          {isVisible("text-font-size") && (
            <TGroup label="حجم الخط">
              <TSelect
                label="حجم الخط"
                value=""
                width="w-24"
                options={[
                  { value: "", label: "الحجم" },
                  ...SIZES.map((s) => ({ value: String(s), label: `${s}` })),
                ]}
                onChange={(v) => v && run(() => ed.setFontSize(editor()!, Number(v)))}
              />
              <TBtn label="تكبير الخط" onClick={() => run(() => ed.stepFontSize(editor()!, 1))}>
                <ChevronUp className="h-4 w-4" />
              </TBtn>
              <TBtn label="تصغير الخط" onClick={() => run(() => ed.stepFontSize(editor()!, -1))}>
                <ChevronDown className="h-4 w-4" />
              </TBtn>
            </TGroup>
          )}
          {isVisible("text-bold-italic-underline") && (
            <TGroup>
              <TBtn label="عريض" onClick={() => run(() => ed.exec("bold"))}>
                <Bold className="h-4 w-4" />
              </TBtn>
              <TBtn label="مائل" onClick={() => run(() => ed.exec("italic"))}>
                <Italic className="h-4 w-4" />
              </TBtn>
              <TBtn label="تحته خط" onClick={() => run(() => ed.exec("underline"))}>
                <Underline className="h-4 w-4" />
              </TBtn>
            </TGroup>
          )}
          {isVisible("text-strike-sup-sub") && (
            <TGroup>
              <TBtn label="يتوسطه خط" onClick={() => run(() => ed.exec("strikeThrough"))}>
                <Strikethrough className="h-4 w-4" />
              </TBtn>
              <TBtn label="أُس علوي" onClick={() => run(() => ed.exec("superscript"))}>
                <Superscript className="h-4 w-4" />
              </TBtn>
              <TBtn label="أُس سفلي" onClick={() => run(() => ed.exec("subscript"))}>
                <Subscript className="h-4 w-4" />
              </TBtn>
            </TGroup>
          )}
          {isVisible("text-color") && (
            <TColor
              label="لون النص"
              value={textColor}
              icon={<Baseline className="h-3.5 w-3.5" />}
              onChange={(v) => {
                setTextColor(v);
                run(() => ed.exec("foreColor", v));
              }}
            />
          )}
          {isVisible("text-effect") && (
            <TSelect
              label="تأثيرات الخط"
              value=""
              width="w-36"
              options={[{ value: "", label: "✨ تأثير الخط" }, ...ed.TEXT_EFFECTS.map((e) => ({ value: e.key, label: e.label }))]}
              onChange={(v) => {
                if (!v) return;
                run(() => {
                  if (!ed.setTextEffect(editor()!, v, textColor)) toast.info("حدّد النص أولاً لتطبيق التأثير");
                });
              }}
            />
          )}
          {isVisible("text-direction") && (
            <TSelect
              label="اتجاه الكتابة"
              value=""
              width="w-40"
              options={[{ value: "", label: "اتجاه الكتابة" }, ...ed.TEXT_DIRECTIONS.map((d) => ({ value: d.key, label: d.label }))]}
              onChange={(v) => v && run(() => ed.setTextDirection(editor()!, v))}
            />
          )}
          {isVisible("text-highlight") && (
            <TColor
              label="تلوين الخلفية"
              value={highlight}
              icon={<Highlighter className="h-3.5 w-3.5" />}
              onChange={(v) => {
                setHighlight(v);
                run(() => ed.exec("hiliteColor", v));
              }}
            />
          )}
          {isVisible("text-copy-cut-paste") && (
            <TGroup>
              <TBtn label="نسخ" onClick={() => void ed.copySelection(false)}>
                <Copy className="h-4 w-4" />
              </TBtn>
              <TBtn label="قص" onClick={() => run(() => void ed.copySelection(true))}>
                <Scissors className="h-4 w-4" />
              </TBtn>
              <TBtn label="لصق" onClick={() => run(() => void ed.pasteFromClipboard())}>
                <ClipboardPaste className="h-4 w-4" />
              </TBtn>
            </TGroup>
          )}
          {isVisible("text-find") && (
            <TBtn label="بحث واستبدال" onClick={onFind}>
              <Search className="h-4 w-4" />
            </TBtn>
          )}
          {isVisible("text-clear-format") && (
            <TBtn label="مسح التنسيق" onClick={() => run(() => ed.exec("removeFormat"))}>
              <Eraser className="h-4 w-4" />
            </TBtn>
          )}
        </ToolRow>
      )}

      {tab === "para" && (
        <ToolRow>
          {isVisible("para-style") && (
            <TSelect
              label="نمط الفقرة"
              value=""
              width="w-32"
              options={[
                { value: "", label: "النمط" },
                { value: "<p>", label: "نص عادي" },
                { value: "<h1>", label: "عنوان 1" },
                { value: "<h2>", label: "عنوان 2" },
                { value: "<h3>", label: "عنوان فرعي" },
              ]}
              onChange={(v) => v && run(() => ed.exec("formatBlock", v))}
            />
          )}
          {isVisible("para-align") && (
            <TGroup>
              <TBtn label="محاذاة لليمين" onClick={() => run(() => ed.exec("justifyRight"))}>
                <AlignRight className="h-4 w-4" />
              </TBtn>
              <TBtn label="توسيط" onClick={() => run(() => ed.exec("justifyCenter"))}>
                <AlignCenter className="h-4 w-4" />
              </TBtn>
              <TBtn label="محاذاة لليسار" onClick={() => run(() => ed.exec("justifyLeft"))}>
                <AlignLeft className="h-4 w-4" />
              </TBtn>
              <TBtn label="ضبط" onClick={() => run(() => ed.exec("justifyFull"))}>
                <AlignJustify className="h-4 w-4" />
              </TBtn>
            </TGroup>
          )}
          {isVisible("para-lists") && (
            <TGroup>
              <TBtn label="قائمة نقطية" onClick={() => run(() => ed.exec("insertUnorderedList"))}>
                <List className="h-4 w-4" />
              </TBtn>
              <TBtn label="قائمة مرقمة" onClick={() => run(() => ed.exec("insertOrderedList"))}>
                <ListOrdered className="h-4 w-4" />
              </TBtn>
            </TGroup>
          )}
          {isVisible("para-indent") && (
            <TGroup>
              <TBtn label="زيادة الإزاحة" onClick={() => run(() => ed.exec("indent"))}>
                <IndentIncrease className="h-4 w-4" />
              </TBtn>
              <TBtn label="تقليل الإزاحة" onClick={() => run(() => ed.exec("outdent"))}>
                <IndentDecrease className="h-4 w-4" />
              </TBtn>
            </TGroup>
          )}
          {isVisible("para-line-height") && (
            <TSelect
              label="تباعد الأسطر"
              value=""
              width="w-32"
              options={[
                { value: "", label: "تباعد الأسطر" },
                ...LINE_HEIGHTS.map((l) => ({ value: String(l), label: `${l}×` })),
              ]}
              onChange={(v) => v && run(() => ed.setLineHeight(editor()!, Number(v)))}
            />
          )}
          {isVisible("para-spacing") && (
            <TSelect
              label="تباعد الفقرات"
              value=""
              width="w-32"
              options={[
                { value: "", label: "تباعد الفقرات" },
                ...PARA_SPACING.map((p) => ({ value: String(p), label: `${p} بكسل` })),
              ]}
              onChange={(v) => v !== "" && run(() => ed.setParagraphSpacing(editor()!, Number(v)))}
            />
          )}
        </ToolRow>
      )}

      {tab === "insert" && (
        <ToolRow>
          {isVisible("insert-image") && (
            <label
              className="inline-flex h-9 shrink-0 cursor-pointer items-center gap-1.5 rounded-lg bg-secondary px-2.5 text-[13px] transition-colors hover:bg-accent"
              title="إضافة صورة"
            >
              <ImageIcon className="h-4 w-4" />
              {uploading ? "جارٍ الرفع…" : "صورة"}
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  void handleImageFile(e.target.files?.[0]);
                  e.target.value = "";
                }}
              />
            </label>
          )}

          {isVisible("insert-textbox") && (
            <TBtn label="مربع نص" wide onClick={() => run(() => ed.insertTextBox())}>
              <TextCursorInput className="h-4 w-4" />
            </TBtn>
          )}

          {isVisible("insert-free-text") && (
            <TBtn label="نص حر في أي مكان" wide active={freeTextMode} onClick={onToggleFreeText}>
              <span className="flex items-center gap-1 px-1 text-[12px]">
                <MousePointerSquareDashed className="h-4 w-4" /> نص حر
              </span>
            </TBtn>
          )}

          {isVisible("insert-table") && (
            <TSelect
              label="إدراج جدول"
              value=""
              width="w-28"
              options={[
                { value: "", label: "جدول" },
                { value: "2x2", label: "2 × 2" },
                { value: "3x3", label: "3 × 3" },
                { value: "4x3", label: "4 × 3" },
                { value: "5x4", label: "5 × 4" },
              ]}
              onChange={(v) => {
                if (!v) return;
                const [r, c] = v.split("x").map(Number);
                run(() => ed.insertTable(r, c, true));
              }}
            />
          )}

          {isVisible("insert-shape") && (
            <>
              <TSelect
                label="إدراج شكل"
                value=""
                width="w-28"
                options={[{ value: "", label: "شكل" }, ...ed.SHAPES.map((s) => ({ value: s.key, label: s.label }))]}
                onChange={(v) => v && run(() => { const el = editor(); if (el) ed.insertShape(el, v, shapeColor); })}
              />
              <TColor
                label="لون الشكل"
                value={shapeColor}
                icon={<Square className="h-3.5 w-3.5" />}
                onChange={setShapeColor}
              />
            </>
          )}

          {isVisible("insert-frame") && (
            <TGroup label="إطار">
              <TSelect
                label="نمط حدود الإطار"
                value={frameStyle}
                width="w-24"
                options={ed.FRAME_STYLES.map((s) => ({ value: s.key, label: s.label }))}
                onChange={(v) => setFrameStyle(v as typeof frameStyle)}
              />
              <TSelect
                label="سمك حدود الإطار"
                value={String(frameThickness)}
                width="w-20"
                options={[1, 2, 3, 5, 8].map((t) => ({ value: String(t), label: `${t}px` }))}
                onChange={(v) => setFrameThickness(Number(v))}
              />
              <TColor
                label="لون الإطار"
                value={frameColor}
                icon={<Frame className="h-3.5 w-3.5" />}
                onChange={setFrameColor}
              />
              <TBtn
                label="إضافة إطار"
                onClick={() =>
                  run(() =>
                    ed.insertFrame(editor()!, {
                      thickness: frameThickness,
                      color: frameColor,
                      style: frameStyle,
                      radius: 10,
                    })
                  )
                }
              >
                <Frame className="h-4 w-4" />
              </TBtn>
            </TGroup>
          )}

          {isVisible("insert-divider") && (
            <TGroup label="فاصل">
              <TSelect
                label="سمك الفاصل"
                value={String(dividerThickness)}
                width="w-20"
                options={[1, 2, 3, 5, 8].map((t) => ({ value: String(t), label: `${t}px` }))}
                onChange={(v) => setDividerThickness(Number(v))}
              />
              <TSelect
                label="طول الفاصل"
                value={String(dividerWidth)}
                width="w-20"
                options={[25, 50, 75, 100].map((w) => ({ value: String(w), label: `${w}٪` }))}
                onChange={(v) => setDividerWidth(Number(v))}
              />
              <TColor
                label="لون الفاصل"
                value={dividerColor}
                icon={<Minus className="h-3.5 w-3.5" />}
                onChange={setDividerColor}
              />
              <TBtn
                label="إضافة فاصل"
                onClick={() =>
                  run(() =>
                    ed.insertDivider({
                      thickness: dividerThickness,
                      width: dividerWidth,
                      color: dividerColor,
                    })
                  )
                }
              >
                <SeparatorHorizontal className="h-4 w-4" />
              </TBtn>
            </TGroup>
          )}

          {isVisible("insert-pagebreak") && (
            <TBtn label="فاصل صفحات" wide onClick={() => run(() => ed.insertPageBreak())}>
              <span className="flex items-center gap-1 px-1 text-[12px]">
                <Minus className="h-3.5 w-3.5" /> فاصل صفحة
              </span>
            </TBtn>
          )}
        </ToolRow>
      )}

      {tab === "table" && (
        <ToolRow>
          {isVisible("table-cell-select") && (
            <TBtn
              label="وضع تحديد الخلايا"
              wide
              active={cellSelectMode}
              onClick={() => setCellSelectMode(!cellSelectMode)}
            >
              <span className="flex items-center gap-1 px-1 text-[12px]">
                <MousePointerSquareDashed className="h-4 w-4" />
                تحديد الخلايا
              </span>
            </TBtn>
          )}
          {isVisible("table-merge-split") && (
            <>
              <TBtn
                label="دمج الخلايا"
                disabled={selectedCells.length < 2}
                onClick={() =>
                  run(() => {
                    if (!ed.mergeCells(selectedCells)) toast.error("اختر خليتين متجاورتين أو أكثر");
                  })
                }
              >
                <Merge className="h-4 w-4" />
              </TBtn>
              <TBtn
                label="تقسيم الخلية"
                disabled={!primaryCell}
                onClick={() =>
                  run(() => {
                    if (primaryCell && !ed.splitCell(primaryCell)) toast.info("هذه الخلية غير مدمجة");
                  })
                }
              >
                <Split className="h-4 w-4" />
              </TBtn>
            </>
          )}
          {isVisible("table-row") && (
            <TGroup label="صف">
              <TBtn label="صف قبل" disabled={!primaryCell} onClick={() => run(() => primaryCell && ed.addRow(primaryCell, false))}>
                <Rows3 className="h-4 w-4" />
              </TBtn>
              <TBtn label="صف بعد" disabled={!primaryCell} onClick={() => run(() => primaryCell && ed.addRow(primaryCell, true))}>
                <Rows3 className="h-4 w-4 rotate-180" />
              </TBtn>
              <TBtn label="حذف الصف" disabled={!primaryCell} onClick={() => run(() => primaryCell && ed.deleteRow(primaryCell))}>
                <Trash2 className="h-4 w-4" />
              </TBtn>
            </TGroup>
          )}
          {isVisible("table-column") && (
            <TGroup label="عمود">
              <TBtn label="عمود قبل" disabled={!primaryCell} onClick={() => run(() => primaryCell && ed.addColumn(primaryCell, false))}>
                <Columns3 className="h-4 w-4" />
              </TBtn>
              <TBtn label="عمود بعد" disabled={!primaryCell} onClick={() => run(() => primaryCell && ed.addColumn(primaryCell, true))}>
                <Columns3 className="h-4 w-4 rotate-180" />
              </TBtn>
              <TBtn label="حذف العمود" disabled={!primaryCell} onClick={() => run(() => primaryCell && ed.deleteColumn(primaryCell))}>
                <Trash2 className="h-4 w-4" />
              </TBtn>
            </TGroup>
          )}
          {isVisible("table-column-width") && (
            <TSelect
              label="عرض العمود"
              value=""
              width="w-28"
              options={[
                { value: "", label: "عرض العمود" },
                ...[60, 90, 120, 160, 220].map((w) => ({ value: String(w), label: `${w}px` })),
              ]}
              onChange={(v) => v && primaryCell && run(() => ed.setColumnWidth(primaryCell, Number(v)))}
            />
          )}
          {isVisible("table-row-height") && (
            <TSelect
              label="ارتفاع الصف"
              value=""
              width="w-28"
              options={[
                { value: "", label: "ارتفاع الصف" },
                ...[28, 36, 48, 64, 90].map((h) => ({ value: String(h), label: `${h}px` })),
              ]}
              onChange={(v) => v && primaryCell && run(() => ed.setRowHeight(primaryCell, Number(v)))}
            />
          )}
          {isVisible("table-borders") && (
            <TBtn
              label="إظهار/إخفاء الحدود"
              disabled={!primaryCell}
              onClick={() =>
                run(() => {
                  const table = primaryCell && ed.tableOf(primaryCell);
                  if (table) ed.toggleTableBorders(table);
                })
              }
            >
              <Grid2x2X className="h-4 w-4" />
            </TBtn>
          )}
        </ToolRow>
      )}

      {tab === "page" && (
        <ToolRow>
          {isVisible("page-setup") && (
            <TBtn label="إعداد الصفحة" wide onClick={onOpenSetup}>
              <span className="flex items-center gap-1.5 px-1 text-[12px]">
                <Settings2 className="h-4 w-4" />
                إعداد الصفحة (المقاس والاتجاه والهوامش)
              </span>
            </TBtn>
          )}
          {isVisible("page-border") && (
            <TBtn label="إطار الصفحة" wide onClick={onOpenPageBorder}>
              <span className="flex items-center gap-1.5 px-1 text-[12px]">
                <Frame className="h-4 w-4" />
                إطار الصفحة (أنواع الإطارات)
              </span>
            </TBtn>
          )}
          {isVisible("page-preview-export") && (
            <TBtn label="معاينة وتصدير PDF" wide onClick={onPreview}>
              <span className="flex items-center gap-1.5 px-1 text-[12px]">
                <FileDown className="h-4 w-4" />
                معاينة وتصدير PDF
              </span>
            </TBtn>
          )}
          {isVisible("page-pagebreak") && (
            <TBtn label="فاصل صفحات" wide onClick={() => run(() => ed.insertPageBreak())}>
              <span className="flex items-center gap-1.5 px-1 text-[12px]">
                <Type className="h-4 w-4" />
                فاصل صفحة
              </span>
            </TBtn>
          )}
        </ToolRow>
      )}

      <ToolbarSettingsSheet
        open={toolsMenuOpen}
        onOpenChange={setToolsMenuOpen}
        tools={TOOL_DEFS}
        isVisible={isVisible}
        onToggle={toggleTool}
        onShowAll={showAllTools}
        hiddenCount={hiddenCount}
      />
    </div>
  );
}
