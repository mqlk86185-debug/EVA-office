"use client";

import { useMemo, useState } from "react";
import { FileText, Loader2, Search } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { DOCUMENT_TEMPLATES as BASE_TEMPLATES } from "@/lib/office/templates/documents";
import { PRO_TEMPLATES } from "@/lib/office/templates/pro";
import { GOLD_STATIONERY } from "@/lib/office/templates/gold";
import { stationeryPayload } from "@/lib/office/templates/stationery";
import type { TemplateDef } from "@/lib/office/templates/build";

const GOLD_TEMPLATES: TemplateDef[] = GOLD_STATIONERY.map((spec) => ({
  id: spec.id,
  app: "eva",
  doc_type: "document",
  category: "ذهبية فاخرة",
  title: spec.name,
  desc: "قالب ذهبي فاخر فارغ بزخارف ملكية، جاهز للكتابة.",
  build: () => stationeryPayload(spec, spec.name),
}));

const DOCUMENT_TEMPLATES = [...GOLD_TEMPLATES, ...PRO_TEMPLATES, ...BASE_TEMPLATES];

const COLORS = ["bg-chart-1", "bg-chart-2", "bg-chart-3", "bg-chart-4", "bg-chart-5", "bg-eva", "bg-pdfapp", "bg-gilox", "bg-novel"];

export function TemplateGallery({ open, onOpenChange, onChoose, busy }: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onChoose: (template: TemplateDef) => void;
  busy: boolean;
}) {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("الكل");
  const categories = ["الكل", ...Array.from(new Set(DOCUMENT_TEMPLATES.map((item) => item.category)))];
  const visible = useMemo(() => {
    const term = search.trim().toLowerCase();
    return DOCUMENT_TEMPLATES.filter((item) =>
      (category === "الكل" || item.category === category) &&
      (!term || `${item.title} ${item.desc} ${item.category}`.toLowerCase().includes(term)),
    );
  }, [category, search]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent dir="rtl" className="flex h-[calc(100dvh-1rem)] w-[calc(100vw-1rem)] max-w-5xl grid-rows-none flex-col gap-3 overflow-hidden rounded-lg bg-card p-3 sm:h-auto sm:max-h-[90vh] sm:p-5">
        <DialogHeader className="shrink-0 pr-7 text-right">
          <DialogTitle className="font-display">{DOCUMENT_TEMPLATES.length} قالب EVA</DialogTitle>
        </DialogHeader>
        <div className="relative shrink-0">
          <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="ابحث عن قالب…" className="pr-9" />
        </div>
        <div className="no-scrollbar flex shrink-0 gap-2 overflow-x-auto pb-1">
          {categories.map((item) => (
            <Button key={item} type="button" size="sm" variant={category === item ? "default" : "outline"} onClick={() => setCategory(item)} className="shrink-0">
              {item}
            </Button>
          ))}
        </div>
        <div className="thin-scroll grid min-h-0 flex-1 grid-cols-2 content-start gap-2 overflow-y-auto sm:grid-cols-3 lg:grid-cols-4">
          {visible.map((template, index) => (
            <Button key={template.id} type="button" variant="outline" disabled={busy} onClick={() => onChoose(template)} className="h-auto min-h-32 items-stretch justify-start overflow-hidden p-0 text-right">
              <span className={`w-2 shrink-0 ${COLORS[index % COLORS.length]}`} />
              <span className="flex min-w-0 flex-1 flex-col p-3">
                <span className="mb-3 flex h-9 w-9 items-center justify-center rounded-md bg-muted text-primary"><FileText className="h-4 w-4" /></span>
                <span className="block w-full truncate font-display text-sm font-semibold">{template.title}</span>
                <span className="mt-1 line-clamp-2 whitespace-normal text-xs font-normal leading-relaxed text-muted-foreground">{template.desc}</span>
                <span className="mt-auto pt-3 text-[11px] font-medium text-primary">{busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : template.category}</span>
              </span>
            </Button>
          ))}
        </div>
        <p className="shrink-0 text-center text-xs text-muted-foreground">{visible.length} قالب</p>
      </DialogContent>
    </Dialog>
  );
}