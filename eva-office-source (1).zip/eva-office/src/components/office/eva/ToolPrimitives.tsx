"use client";

import type { ReactNode } from "react";

export function TBtn({
  children,
  label,
  active,
  onClick,
  disabled,
  wide,
}: {
  children: ReactNode;
  label: string;
  active?: boolean;
  onClick: () => void;
  disabled?: boolean;
  wide?: boolean;
}) {
  return (
    <button
      type="button"
      title={label}
      aria-label={label}
      aria-pressed={active}
      disabled={disabled}
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
      className={`inline-flex h-9 shrink-0 items-center justify-center gap-1.5 rounded-lg border px-2 text-[13px] transition-colors disabled:opacity-40 ${
        wide ? "min-w-9" : "w-9"
      } ${
        active
          ? "border-primary/40 bg-primary/12 text-primary"
          : "border-transparent bg-secondary text-foreground hover:bg-accent"
      }`}
    >
      {children}
    </button>
  );
}

export function TGroup({ children, label }: { children: ReactNode; label?: string }) {
  return (
    <div className="flex shrink-0 items-center gap-1 rounded-xl bg-muted/60 p-1">
      {label && <span className="px-1 text-[10px] text-muted-foreground">{label}</span>}
      {children}
    </div>
  );
}

export function TColor({
  value,
  onChange,
  label,
  icon,
}: {
  value: string;
  onChange: (v: string) => void;
  label: string;
  icon: ReactNode;
}) {
  return (
    <label
      title={label}
      className="relative inline-flex h-9 w-11 shrink-0 cursor-pointer flex-col items-center justify-center rounded-lg bg-secondary transition-colors hover:bg-accent"
    >
      <span className="pointer-events-none text-foreground">{icon}</span>
      <span
        className="pointer-events-none mt-0.5 h-1.5 w-5 rounded-full"
        style={{ background: value }}
      />
      <input
        type="color"
        value={value}
        aria-label={label}
        onChange={(e) => onChange(e.target.value)}
        className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
      />
    </label>
  );
}

export function TSelect({
  value,
  onChange,
  options,
  label,
  width = "w-32",
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
  label: string;
  width?: string;
}) {
  return (
    <select
      aria-label={label}
      title={label}
      value={value}
      onMouseDown={(e) => e.stopPropagation()}
      onChange={(e) => onChange(e.target.value)}
      className={`h-9 shrink-0 rounded-lg border border-transparent bg-secondary px-2 text-[13px] outline-none transition-colors hover:bg-accent focus:border-primary/40 ${width}`}
    >
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}

export function ToolRow({ children }: { children: ReactNode }) {
  // Wraps instead of scrolling sideways so every tool stays reachable on
  // narrow phone screens — nothing hides off the edge.
  return (
    <div className="flex flex-wrap items-center gap-1.5 px-2 pb-2">{children}</div>
  );
}
