"use client";

import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { SlidersHorizontal } from "lucide-react";
import type { ToolDef } from "./tool-defs";

/**
 * "إظهار/إخفاء الأدوات" — lists every tool in the toolbar grouped by tab so the
 * user can hide the ones they never use, keeping the toolbar quick and uncluttered.
 */
export function ToolbarSettingsSheet({
  open,
  onOpenChange,
  tools,
  isVisible,
  onToggle,
  onShowAll,
  hiddenCount,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  tools: ToolDef[];
  isVisible: (id: string) => boolean;
  onToggle: (id: string) => void;
  onShowAll: () => void;
  hiddenCount: number;
}) {
  const groups = tools.reduce<Record<string, ToolDef[]>>((acc, tool) => {
    (acc[tool.tabLabel] ??= []).push(tool);
    return acc;
  }, {});

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="max-h-[85vh] overflow-y-auto rounded-t-3xl thin-scroll">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2 font-display">
            <SlidersHorizontal className="h-4.5 w-4.5" />
            تخصيص الأدوات
          </SheetTitle>
          <p className="text-xs text-muted-foreground">
            أوقف الأدوات التي لا تستخدمها لتبقى شريط الأدوات سريعًا وواضحًا. يُطبَّق الاختيار على كل مستنداتك.
          </p>
        </SheetHeader>

        <div className="space-y-5 px-4 pb-6">
          {Object.entries(groups).map(([tabLabel, items]) => (
            <div key={tabLabel} className="space-y-1.5">
              <h3 className="px-1 text-[13px] font-semibold text-muted-foreground">{tabLabel}</h3>
              <div className="overflow-hidden rounded-xl border border-border">
                {items.map((tool, i) => (
                  <div
                    key={tool.id}
                    className={`flex items-center justify-between gap-3 px-3 py-2.5 ${
                      i > 0 ? "border-t border-border" : ""
                    }`}
                  >
                    <span className="text-sm">{tool.label}</span>
                    <Switch checked={isVisible(tool.id)} onCheckedChange={() => onToggle(tool.id)} />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="sticky bottom-0 border-t border-border bg-background px-4 py-3">
          <Button
            type="button"
            variant="outline"
            className="w-full"
            disabled={hiddenCount === 0}
            onClick={onShowAll}
          >
            إظهار كل الأدوات {hiddenCount > 0 ? `(${hiddenCount} مخفية)` : ""}
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
