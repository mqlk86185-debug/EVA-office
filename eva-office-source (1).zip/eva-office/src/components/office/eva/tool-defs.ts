export interface ToolDef {
  id: string;
  label: string;
  tabLabel: string;
}

/**
 * One entry per toggleable control in `DocToolbar`. Kept in one place so the
 * "إظهار/إخفاء الأدوات" menu always lists exactly what the toolbar can show.
 */
export const TOOL_DEFS: ToolDef[] = [
  // نص
  { id: "text-font-family", label: "نوع الخط", tabLabel: "نص" },
  { id: "text-font-size", label: "حجم الخط", tabLabel: "نص" },
  { id: "text-bold-italic-underline", label: "عريض / مائل / تحته خط", tabLabel: "نص" },
  { id: "text-strike-sup-sub", label: "يتوسطه خط / أُس علوي / أُس سفلي", tabLabel: "نص" },
  { id: "text-color", label: "لون النص", tabLabel: "نص" },
  { id: "text-effect", label: "تأثيرات الخط", tabLabel: "نص" },
  { id: "text-direction", label: "اتجاه الكتابة", tabLabel: "نص" },
  { id: "text-highlight", label: "تلوين الخلفية", tabLabel: "نص" },
  { id: "text-copy-cut-paste", label: "نسخ / قص / لصق", tabLabel: "نص" },
  { id: "text-find", label: "بحث واستبدال", tabLabel: "نص" },
  { id: "text-clear-format", label: "مسح التنسيق", tabLabel: "نص" },

  // فقرة
  { id: "para-style", label: "نمط الفقرة (عناوين)", tabLabel: "فقرة" },
  { id: "para-align", label: "محاذاة النص", tabLabel: "فقرة" },
  { id: "para-lists", label: "القوائم النقطية والمرقمة", tabLabel: "فقرة" },
  { id: "para-indent", label: "زيادة / تقليل الإزاحة", tabLabel: "فقرة" },
  { id: "para-line-height", label: "تباعد الأسطر", tabLabel: "فقرة" },
  { id: "para-spacing", label: "تباعد الفقرات", tabLabel: "فقرة" },

  // إدراج
  { id: "insert-image", label: "إدراج صورة", tabLabel: "إدراج" },
  { id: "insert-textbox", label: "مربع نص", tabLabel: "إدراج" },
  { id: "insert-free-text", label: "نص حر في أي مكان", tabLabel: "إدراج" },
  { id: "insert-table", label: "إدراج جدول", tabLabel: "إدراج" },
  { id: "insert-shape", label: "إدراج شكل", tabLabel: "إدراج" },
  { id: "insert-frame", label: "إدراج إطار", tabLabel: "إدراج" },
  { id: "insert-divider", label: "خط فاصل", tabLabel: "إدراج" },
  { id: "insert-pagebreak", label: "فاصل صفحات", tabLabel: "إدراج" },

  // جدول
  { id: "table-cell-select", label: "وضع تحديد الخلايا", tabLabel: "جدول" },
  { id: "table-merge-split", label: "دمج / تقسيم الخلايا", tabLabel: "جدول" },
  { id: "table-row", label: "إدارة الصفوف", tabLabel: "جدول" },
  { id: "table-column", label: "إدارة الأعمدة", tabLabel: "جدول" },
  { id: "table-column-width", label: "عرض العمود", tabLabel: "جدول" },
  { id: "table-row-height", label: "ارتفاع الصف", tabLabel: "جدول" },
  { id: "table-borders", label: "إظهار/إخفاء حدود الجدول", tabLabel: "جدول" },

  // صفحة
  { id: "page-setup", label: "إعداد الصفحة", tabLabel: "صفحة" },
  { id: "page-border", label: "إطار الصفحة", tabLabel: "صفحة" },
  { id: "page-preview-export", label: "معاينة وتصدير PDF", tabLabel: "صفحة" },
  { id: "page-pagebreak", label: "فاصل صفحات", tabLabel: "صفحة" },
];
