"use client";

import { useState } from "react";
import {
  Bold, Italic, Underline, AlignRight, AlignCenter, AlignLeft, WrapText, Baseline,
  PaintBucket, Grid2x2, Merge, Rows3, Columns3, Trash2, ArrowUpAZ, ArrowDownAZ,
  Filter, Search, BarChart3, Settings2, FileDown, Percent, DollarSign, Hash,
  CalendarDays, Clock, Plus, Minus,
} from "lucide-react";
import { TBtn, TColor, TGroup, TSelect, ToolRow } from "../eva/ToolPrimitives";
import { SHEET_FONTS } from "@/lib/office/sheet";
import type { CellStyle } from "@/lib/office/types";

const TABS = [
  { key: "format", label: "تنسيق" },
  { key: "numbers", label: "أرقام" },
  { key: "cells", label: "خلايا" },
  { key: "data", label: "بيانات" },
  { key: "chart", label: "رسوم" },
  { key: "page", label: "صفحة" },
] as const;

type TabKey = (typeof TABS)[number]["key"];

export function SheetToolbar({
  style,
  onStyle,
  onInsertRow,
  onInsertCol,
  onDeleteRow,
  onDeleteCol,
  onMerge,
  onColWidth,
  onRowHeight,
  onSort,
  onFilter,
  onFind,
  onAddChart,
  onOpenSetup,
  onPreview,
}: {
  style: CellStyle;
  onStyle: (patch: CellStyle) => void;
  onInsertRow: (after: boolean) => void;
  onInsertCol: (after: boolean) => void;
  onDeleteRow: () => void;
  onDeleteCol: () => void;
  onMerge: () => void;
  onColWidth: (w: number) => void;
  onRowHeight: (h: number) => void;
  onSort: (dir: "asc" | "desc") => void;
  onFilter: () => void;
  onFind: () => void;
  onAddChart: (kind: "bar" | "line" | "pie") => void;
  onOpenSetup: () => void;
  onPreview: () => void;
}) {
  const [tab, setTab] = useState<TabKey>("format");
  const [color, setColor] = useState(style.c ?? "#111827");
  const [bg, setBg] = useState(style.bg ?? "#fef3c7");

  return (
    <div className="border-t border-border bg-background/95">
      <div className="no-scrollbar flex gap-1 overflow-x-auto px-2 py-1.5">
        {TABS.map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            className={`shrink-0 rounded-lg px-3 py-1.5 text-[13px] font-medium transition-colors ${
              tab === t.key ? "bg-foreground text-background" : "text-muted-foreground hover:bg-accent"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "format" && (
        <ToolRow>
          <TSelect
            label="نوع الخط"
            value={style.ff ?? ""}
            width="w-36"
            options={[{ value: "", label: "نوع الخط" }, ...SHEET_FONTS]}
            onChange={(v) => onStyle({ ff: v || undefined })}
          />
          <TSelect
            label="حجم الخط"
            value={String(style.fs ?? "")}
            width="w-24"
            options={[
              { value: "", label: "الحجم" },
              ...[10, 11, 12, 14, 16, 18, 20, 24, 28].map((s) => ({ value: String(s), label: `${s}` })),
            ]}
            onChange={(v) => onStyle({ fs: v ? Number(v) : undefined })}
          />
          <TGroup>
            <TBtn label="عريض" active={style.b} onClick={() => onStyle({ b: !style.b })}>
              <Bold className="h-4 w-4" />
            </TBtn>
            <TBtn label="مائل" active={style.i} onClick={() => onStyle({ i: !style.i })}>
              <Italic className="h-4 w-4" />
            </TBtn>
            <TBtn label="تحته خط" active={style.u} onClick={() => onStyle({ u: !style.u })}>
              <Underline className="h-4 w-4" />
            </TBtn>
          </TGroup>
          <TColor
            label="لون النص"
            value={color}
            icon={<Baseline className="h-3.5 w-3.5" />}
            onChange={(v) => {
              setColor(v);
              onStyle({ c: v });
            }}
          />
          <TColor
            label="خلفية الخلية"
            value={bg}
            icon={<PaintBucket className="h-3.5 w-3.5" />}
            onChange={(v) => {
              setBg(v);
              onStyle({ bg: v });
            }}
          />
          <TGroup>
            <TBtn label="محاذاة يمين" active={style.a === "right"} onClick={() => onStyle({ a: "right" })}>
              <AlignRight className="h-4 w-4" />
            </TBtn>
            <TBtn label="توسيط" active={style.a === "center"} onClick={() => onStyle({ a: "center" })}>
              <AlignCenter className="h-4 w-4" />
            </TBtn>
            <TBtn label="محاذاة يسار" active={style.a === "left"} onClick={() => onStyle({ a: "left" })}>
              <AlignLeft className="h-4 w-4" />
            </TBtn>
          </TGroup>
          <TBtn label="التفاف النص" active={style.w} onClick={() => onStyle({ w: !style.w })}>
            <WrapText className="h-4 w-4" />
          </TBtn>
          <TBtn label="حدود الخلية" active={style.bd} onClick={() => onStyle({ bd: !style.bd })}>
            <Grid2x2 className="h-4 w-4" />
          </TBtn>
        </ToolRow>
      )}

      {tab === "numbers" && (
        <ToolRow>
          <TBtn label="عام" wide active={!style.fmt || style.fmt === "general"} onClick={() => onStyle({ fmt: "general" })}>
            <span className="px-1 text-[12px]">عام</span>
          </TBtn>
          <TBtn label="رقم" active={style.fmt === "number"} onClick={() => onStyle({ fmt: "number" })}>
            <Hash className="h-4 w-4" />
          </TBtn>
          <TBtn label="عملة" active={style.fmt === "currency"} onClick={() => onStyle({ fmt: "currency" })}>
            <DollarSign className="h-4 w-4" />
          </TBtn>
          <TBtn label="نسبة مئوية" active={style.fmt === "percent"} onClick={() => onStyle({ fmt: "percent" })}>
            <Percent className="h-4 w-4" />
          </TBtn>
          <TBtn label="تاريخ" active={style.fmt === "date"} onClick={() => onStyle({ fmt: "date" })}>
            <CalendarDays className="h-4 w-4" />
          </TBtn>
          <TBtn label="وقت" active={style.fmt === "time"} onClick={() => onStyle({ fmt: "time" })}>
            <Clock className="h-4 w-4" />
          </TBtn>
          <TGroup label="المنازل العشرية">
            <TBtn label="زيادة المنازل" onClick={() => onStyle({ dec: Math.min(6, (style.dec ?? 0) + 1) })}>
              <Plus className="h-4 w-4" />
            </TBtn>
            <span className="min-w-6 text-center text-[13px] tabular-nums">{style.dec ?? 0}</span>
            <TBtn label="تقليل المنازل" onClick={() => onStyle({ dec: Math.max(0, (style.dec ?? 0) - 1) })}>
              <Minus className="h-4 w-4" />
            </TBtn>
          </TGroup>
        </ToolRow>
      )}

      {tab === "cells" && (
        <ToolRow>
          <TGroup label="صف">
            <TBtn label="صف قبل" onClick={() => onInsertRow(false)}>
              <Rows3 className="h-4 w-4" />
            </TBtn>
            <TBtn label="صف بعد" onClick={() => onInsertRow(true)}>
              <Rows3 className="h-4 w-4 rotate-180" />
            </TBtn>
            <TBtn label="حذف الصف" onClick={onDeleteRow}>
              <Trash2 className="h-4 w-4" />
            </TBtn>
          </TGroup>
          <TGroup label="عمود">
            <TBtn label="عمود قبل" onClick={() => onInsertCol(false)}>
              <Columns3 className="h-4 w-4" />
            </TBtn>
            <TBtn label="عمود بعد" onClick={() => onInsertCol(true)}>
              <Columns3 className="h-4 w-4 rotate-180" />
            </TBtn>
            <TBtn label="حذف العمود" onClick={onDeleteCol}>
              <Trash2 className="h-4 w-4" />
            </TBtn>
          </TGroup>
          <TBtn label="دمج الخلايا" onClick={onMerge}>
            <Merge className="h-4 w-4" />
          </TBtn>
          <TSelect
            label="عرض العمود"
            value=""
            width="w-28"
            options={[
              { value: "", label: "عرض العمود" },
              ...[70, 90, 110, 140, 180, 240].map((w) => ({ value: String(w), label: `${w}px` })),
            ]}
            onChange={(v) => v && onColWidth(Number(v))}
          />
          <TSelect
            label="ارتفاع الصف"
            value=""
            width="w-28"
            options={[
              { value: "", label: "ارتفاع الصف" },
              ...[28, 34, 42, 56, 72].map((h) => ({ value: String(h), label: `${h}px` })),
            ]}
            onChange={(v) => v && onRowHeight(Number(v))}
          />
        </ToolRow>
      )}

      {tab === "data" && (
        <ToolRow>
          <TBtn label="ترتيب تصاعدي" wide onClick={() => onSort("asc")}>
            <span className="flex items-center gap-1 px-1 text-[12px]">
              <ArrowUpAZ className="h-4 w-4" /> تصاعدي
            </span>
          </TBtn>
          <TBtn label="ترتيب تنازلي" wide onClick={() => onSort("desc")}>
            <span className="flex items-center gap-1 px-1 text-[12px]">
              <ArrowDownAZ className="h-4 w-4" /> تنازلي
            </span>
          </TBtn>
          <TBtn label="تصفية البيانات" wide onClick={onFilter}>
            <span className="flex items-center gap-1 px-1 text-[12px]">
              <Filter className="h-4 w-4" /> تصفية
            </span>
          </TBtn>
          <TBtn label="بحث واستبدال" wide onClick={onFind}>
            <span className="flex items-center gap-1 px-1 text-[12px]">
              <Search className="h-4 w-4" /> بحث واستبدال
            </span>
          </TBtn>
        </ToolRow>
      )}

      {tab === "chart" && (
        <ToolRow>
          <TBtn label="مخطط أعمدة" wide onClick={() => onAddChart("bar")}>
            <span className="flex items-center gap-1 px-1 text-[12px]">
              <BarChart3 className="h-4 w-4" /> أعمدة
            </span>
          </TBtn>
          <TBtn label="مخطط خطي" wide onClick={() => onAddChart("line")}>
            <span className="flex items-center gap-1 px-1 text-[12px]">
              <svg viewBox="0 0 16 16" className="h-4 w-4" fill="none">
                <path d="M2 12l4-5 3 3 5-7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              خطي
            </span>
          </TBtn>
          <TBtn label="مخطط دائري" wide onClick={() => onAddChart("pie")}>
            <span className="flex items-center gap-1 px-1 text-[12px]">
              <svg viewBox="0 0 16 16" className="h-4 w-4" fill="none">
                <circle cx="8" cy="8" r="6" stroke="currentColor" strokeWidth="1.6" />
                <path d="M8 2v6h6" stroke="currentColor" strokeWidth="1.6" />
              </svg>
              دائري
            </span>
          </TBtn>
        </ToolRow>
      )}

      {tab === "page" && (
        <ToolRow>
          <TBtn label="إعداد الصفحة" wide onClick={onOpenSetup}>
            <span className="flex items-center gap-1.5 px-1 text-[12px]">
              <Settings2 className="h-4 w-4" /> إعداد الصفحة
            </span>
          </TBtn>
          <TBtn label="معاينة وتصدير PDF" wide onClick={onPreview}>
            <span className="flex items-center gap-1.5 px-1 text-[12px]">
              <FileDown className="h-4 w-4" /> معاينة وتصدير PDF
            </span>
          </TBtn>
        </ToolRow>
      )}
    </div>
  );
}
