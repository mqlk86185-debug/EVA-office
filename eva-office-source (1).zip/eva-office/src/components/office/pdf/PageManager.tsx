"use client";

import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  Trash2, Scissors, ArrowUp, ArrowDown, RotateCw, FileOutput, Merge, Loader2, Save,
} from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { listFiles, savePdfBytes } from "@/lib/office/client";
import { fetchPdfBytes } from "@/lib/office/pdfjs";
import type { OfficeFile } from "@/lib/office/types";

interface PageEntry {
  /** index in the ORIGINAL document */
  source: number;
  rotation: number;
  selected: boolean;
}

/**
 * Full page management for a PDF: delete, extract, reorder, rotate, split and
 * merge. All edits happen in the browser with pdf-lib, then the resulting bytes
 * are pushed back to Totalum.
 */
export function PageManager({
  open,
  onOpenChange,
  file,
  thumbnails,
  pageCount,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  file: OfficeFile;
  thumbnails: string[];
  pageCount: number;
  onSaved: () => void;
}) {
  const [pages, setPages] = useState<PageEntry[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [library, setLibrary] = useState<OfficeFile[]>([]);
  const [mergePickerOpen, setMergePickerOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    setPages(
      Array.from({ length: pageCount }).map((_, i) => ({ source: i, rotation: 0, selected: false }))
    );
  }, [open, pageCount]);

  useEffect(() => {
    if (!mergePickerOpen) return;
    listFiles({ app: "pdf", limit: 100 })
      .then((list) => setLibrary(list.filter((f) => f._id !== file._id && f.pdf_file?.url)))
      .catch((err) => {
        console.error("[PageManager] failed to list PDFs:", err);
        toast.error("تعذّر تحميل قائمة الملفات");
      });
  }, [mergePickerOpen, file._id]);

  const selectedIdx = useMemo(
    () => pages.map((p, i) => (p.selected ? i : -1)).filter((i) => i >= 0),
    [pages]
  );

  const toggle = (i: number) =>
    setPages((prev) => prev.map((p, pi) => (pi === i ? { ...p, selected: !p.selected } : p)));

  const move = (i: number, delta: number) => {
    const target = i + delta;
    if (target < 0 || target >= pages.length) return;
    setPages((prev) => {
      const next = [...prev];
      [next[i], next[target]] = [next[target], next[i]];
      return next;
    });
  };

  const rotateSelected = () =>
    setPages((prev) =>
      prev.map((p) => (p.selected ? { ...p, rotation: (p.rotation + 90) % 360 } : p))
    );

  const deleteSelected = () => {
    if (!selectedIdx.length) {
      toast.info("حدّد صفحة واحدة على الأقل");
      return;
    }
    if (selectedIdx.length >= pages.length) {
      toast.error("لا يمكن حذف كل الصفحات");
      return;
    }
    setPages((prev) => prev.filter((p) => !p.selected));
    toast.success(`تم تعليم ${selectedIdx.length} صفحة للحذف — اضغط حفظ لتطبيق التغييرات`);
  };

  /** Builds a new PDF from the given ordered entries. */
  const buildPdf = async (entries: PageEntry[]) => {
    const { PDFDocument, degrees } = await import("pdf-lib");
    const bytes = await fetchPdfBytes(file.pdf_file!.url);
    const source = await PDFDocument.load(bytes);
    const out = await PDFDocument.create();
    const copied = await out.copyPages(
      source,
      entries.map((e) => e.source)
    );
    copied.forEach((page, i) => {
      const rotation = entries[i].rotation;
      if (rotation) page.setRotation(degrees((page.getRotation().angle + rotation) % 360));
      out.addPage(page);
    });
    return { bytes: await out.save(), count: entries.length };
  };

  const applyChanges = async () => {
    setBusy("save");
    try {
      const { bytes, count } = await buildPdf(pages);
      await savePdfBytes({
        file_id: file._id,
        title: file.title,
        bytes,
        page_count: count,
      });
      toast.success("تم حفظ التغييرات على الملف");
      onOpenChange(false);
      onSaved();
    } catch (err) {
      console.error("[PageManager] save failed:", err);
      toast.error("تعذّر حفظ التغييرات", { description: (err as Error).message });
    } finally {
      setBusy(null);
    }
  };

  const extractSelected = async () => {
    if (!selectedIdx.length) {
      toast.info("حدّد الصفحات المطلوب استخراجها");
      return;
    }
    setBusy("extract");
    try {
      const entries = selectedIdx.map((i) => pages[i]);
      const { bytes, count } = await buildPdf(entries);
      await savePdfBytes({
        title: `${file.title} — صفحات مستخرجة`,
        bytes,
        page_count: count,
        as_new: true,
      });
      toast.success(`تم استخراج ${count} صفحة إلى ملف جديد`);
      onSaved();
    } catch (err) {
      console.error("[PageManager] extract failed:", err);
      toast.error("تعذّر الاستخراج", { description: (err as Error).message });
    } finally {
      setBusy(null);
    }
  };

  const splitHere = async () => {
    if (selectedIdx.length !== 1) {
      toast.info("حدّد صفحة واحدة ليتم التقسيم عندها");
      return;
    }
    const at = selectedIdx[0];
    if (at === 0 || at >= pages.length) {
      toast.info("اختر صفحة غير الأولى للتقسيم");
      return;
    }
    setBusy("split");
    try {
      const first = await buildPdf(pages.slice(0, at));
      const second = await buildPdf(pages.slice(at));
      await savePdfBytes({
        title: `${file.title} — الجزء 1`,
        bytes: first.bytes,
        page_count: first.count,
        as_new: true,
      });
      await savePdfBytes({
        title: `${file.title} — الجزء 2`,
        bytes: second.bytes,
        page_count: second.count,
        as_new: true,
      });
      toast.success("تم تقسيم الملف إلى جزأين");
      onSaved();
    } catch (err) {
      console.error("[PageManager] split failed:", err);
      toast.error("تعذّر التقسيم", { description: (err as Error).message });
    } finally {
      setBusy(null);
    }
  };

  const mergeWith = async (other: OfficeFile) => {
    setBusy("merge");
    try {
      const { PDFDocument } = await import("pdf-lib");
      const [ownBytes, otherBytes] = await Promise.all([
        fetchPdfBytes(file.pdf_file!.url),
        fetchPdfBytes(other.pdf_file!.url),
      ]);
      const out = await PDFDocument.create();
      for (const source of [ownBytes, otherBytes]) {
        const doc = await PDFDocument.load(source);
        const copied = await out.copyPages(doc, doc.getPageIndices());
        copied.forEach((p) => out.addPage(p));
      }
      const bytes = await out.save();
      await savePdfBytes({
        title: `${file.title} + ${other.title}`,
        bytes,
        page_count: out.getPageCount(),
        as_new: true,
      });
      toast.success("تم دمج الملفين في ملف جديد");
      setMergePickerOpen(false);
      onSaved();
    } catch (err) {
      console.error("[PageManager] merge failed:", err);
      toast.error("تعذّر الدمج", { description: (err as Error).message });
    } finally {
      setBusy(null);
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="h-[90vh] rounded-t-3xl p-0">
        <SheetHeader className="border-b border-border">
          <SheetTitle className="font-display">إدارة الصفحات</SheetTitle>
        </SheetHeader>

        <div className="no-scrollbar flex gap-2 overflow-x-auto border-b border-border px-4 py-2.5">
          <Button size="sm" variant="outline" onClick={deleteSelected} disabled={busy !== null}>
            <Trash2 className="h-4 w-4" /> حذف
          </Button>
          <Button size="sm" variant="outline" onClick={rotateSelected} disabled={busy !== null}>
            <RotateCw className="h-4 w-4" /> تدوير
          </Button>
          <Button size="sm" variant="outline" onClick={extractSelected} disabled={busy !== null}>
            {busy === "extract" ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileOutput className="h-4 w-4" />}
            استخراج
          </Button>
          <Button size="sm" variant="outline" onClick={splitHere} disabled={busy !== null}>
            {busy === "split" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Scissors className="h-4 w-4" />}
            تقسيم
          </Button>
          <Button size="sm" variant="outline" onClick={() => setMergePickerOpen(true)} disabled={busy !== null}>
            <Merge className="h-4 w-4" /> دمج
          </Button>
        </div>

        <div className="thin-scroll grid max-h-[calc(90vh-190px)] grid-cols-3 gap-3 overflow-y-auto p-4 sm:grid-cols-4">
          {pages.map((page, i) => (
            <div
              key={`${page.source}-${i}`}
              className={`overflow-hidden rounded-xl border-2 transition-colors ${
                page.selected ? "border-primary" : "border-border"
              }`}
            >
              <button
                type="button"
                onClick={() => toggle(i)}
                className="block w-full bg-white"
                aria-label={`الصفحة ${i + 1}`}
              >
                {thumbnails[page.source] ? (
                  <img
                    src={thumbnails[page.source]}
                    alt={`صفحة ${page.source + 1}`}
                    className="h-auto w-full"
                    style={{ transform: `rotate(${page.rotation}deg)` }}
                  />
                ) : (
                  <span className="flex h-28 items-center justify-center text-xs text-muted-foreground">
                    {page.source + 1}
                  </span>
                )}
              </button>
              <div className="flex items-center justify-between bg-card px-1.5 py-1">
                <span className="text-[11px] tabular-nums text-muted-foreground">{i + 1}</span>
                <span className="flex">
                  <button
                    type="button"
                    aria-label="تحريك لأعلى"
                    onClick={() => move(i, -1)}
                    className="inline-flex h-7 w-7 items-center justify-center rounded hover:bg-accent"
                  >
                    <ArrowUp className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    aria-label="تحريك لأسفل"
                    onClick={() => move(i, 1)}
                    className="inline-flex h-7 w-7 items-center justify-center rounded hover:bg-accent"
                  >
                    <ArrowDown className="h-3.5 w-3.5" />
                  </button>
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="border-t border-border p-3">
          <Button className="w-full" onClick={applyChanges} disabled={busy !== null}>
            {busy === "save" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            حفظ التغييرات على الملف
          </Button>
        </div>

        {mergePickerOpen && (
          <div className="absolute inset-0 z-20 flex flex-col bg-background">
            <div className="flex items-center justify-between border-b border-border px-4 py-3">
              <span className="font-display font-medium">اختر ملفًا للدمج</span>
              <Button variant="ghost" size="sm" onClick={() => setMergePickerOpen(false)}>
                إلغاء
              </Button>
            </div>
            <div className="thin-scroll flex-1 space-y-2 overflow-y-auto p-4">
              {library.length === 0 ? (
                <p className="py-10 text-center text-sm text-muted-foreground">لا توجد ملفات PDF أخرى</p>
              ) : (
                library.map((other) => (
                  <button
                    key={other._id}
                    type="button"
                    disabled={busy !== null}
                    onClick={() => mergeWith(other)}
                    className="flex w-full items-center gap-2 rounded-xl border border-border p-3 text-right hover:bg-accent disabled:opacity-60"
                  >
                    {busy === "merge" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Merge className="h-4 w-4" />}
                    <span className="truncate">{other.title}</span>
                  </button>
                ))
              )}
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
