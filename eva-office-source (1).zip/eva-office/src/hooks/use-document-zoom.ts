import { useEffect, useRef, useState } from "react";

export function fitDocumentScale(available: number, pageWidth: number) {
  return Math.min(1, Math.max(1, available) / Math.max(1, pageWidth));
}

/** Observe the viewport, not the scaled paper, so zoom cannot resize its own bounds. */
export function useDocumentZoom(pageWidth: number, gutter = 24, active = true) {
  const viewportRef = useRef<HTMLDivElement>(null);
  const [bounds, setBounds] = useState({ fit: 1, mobile: true });
  const [requested, setRequested] = useState<number | null>(null);

  useEffect(() => {
    const el = viewportRef.current;
    if (!el) return;
    const media = window.matchMedia("(max-width: 767px)");
    const update = () => {
      if (!el.clientWidth) return;
      setBounds({ fit: fitDocumentScale(el.clientWidth - gutter, pageWidth), mobile: media.matches });
    };
    update();
    const observer = new ResizeObserver(update);
    observer.observe(el);
    media.addEventListener("change", update);
    return () => { observer.disconnect(); media.removeEventListener("change", update); };
  }, [pageWidth, gutter, active]);

  const maximum = bounds.mobile ? bounds.fit : 4;
  const minimum = Math.min(0.25, bounds.fit);
  const zoom = Math.max(minimum, Math.min(requested ?? bounds.fit, maximum));
  const changeZoom = (delta: number) => setRequested(Math.max(minimum, Math.min(maximum, zoom + delta)));
  return { viewportRef, zoom, minimum, maximum, autoZoom: requested === null,
    changeZoom, resetZoom: () => setRequested(null) };
}