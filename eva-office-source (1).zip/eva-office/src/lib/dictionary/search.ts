export interface DictionaryEntry {
  id: string;
  en: string;
  ar: string;
  phonetic?: string;
  partOfSpeechAr?: string;
  categoryAr?: string;
  exampleEn?: string;
  exampleAr?: string;
  level?: string;
  synonyms?: string[];
}

export function normalizeTerm(value: string) {
  return value.normalize("NFKC").toLowerCase().replace(/[\u064B-\u065F\u0670\u0640]/g, "").replace(/[أإآٱ]/g, "ا").replace(/ى/g, "ي").trim();
}

export function searchEntries(entries: DictionaryEntry[], term: string, category = "all") {
  const query = normalizeTerm(term).slice(0, 200);
  const tokens = query.split(/\s+/).filter(Boolean);
  return entries.filter((entry) => {
    if (category !== "all" && entry.categoryAr !== category) return false;
    if (!query) return true;
    const text = searchText(entry);
    return tokens.every((token) => text.includes(token));
  }).sort((a, b) => {
    if (!query) return 0;
    const rank = (entry: DictionaryEntry) => {
      const en = normalizeTerm(entry.en), ar = normalizeTerm(entry.ar);
      return en === query || ar === query ? 0 : en.startsWith(query) || ar.startsWith(query) ? 1 : 2;
    };
    return rank(a) - rank(b);
  });
}

const textCache = new WeakMap<DictionaryEntry, string>();
function searchText(entry: DictionaryEntry) {
  let text = textCache.get(entry);
  if (text === undefined) { text = normalizeTerm(`${entry.en} ${entry.ar}`); textCache.set(entry, text); }
  return text;
}

let pending: Promise<DictionaryEntry[]> | null = null;
export function loadDictionary(): Promise<DictionaryEntry[]> {
  pending ??= Promise.all([1, 2, 3].map((n) => fetch(`/dictionary/entries-${n}.json`).then((r) => {
    if (!r.ok) throw new Error("dictionary load failed");
    return r.json() as Promise<DictionaryEntry[]>;
  }))).then((parts) => parts.flat()).catch((error) => { pending = null; throw error; });
  return pending;
}

/** Warm the dictionary in the background so opening it feels instant. */
export function prefetchDictionary() {
  if (typeof window === "undefined") return;
  const run = () => { void loadDictionary().catch(() => {}); };
  const idle = (window as Window & { requestIdleCallback?: (cb: () => void) => void }).requestIdleCallback;
  if (idle) idle(run); else setTimeout(run, 1500);
}
