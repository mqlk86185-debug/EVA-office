"use client";

/**
 * Manager mode for this device. The access code is never stored in the app
 * code: it is checked on the server, and the typed code is kept locally only
 * so the manager can publish without retyping it.
 */

const KEY = "eva-office-manager-code";

export function getManagerCode(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(KEY);
  } catch {
    return null;
  }
}

export function isManager(): boolean {
  return Boolean(getManagerCode());
}

export function rememberManager(code: string): void {
  try {
    window.localStorage.setItem(KEY, code.trim());
  } catch (err) {
    console.error("[admin] could not persist manager code:", err);
  }
}

export function lockManager(): void {
  try {
    window.localStorage.removeItem(KEY);
    window.localStorage.removeItem("eva-office-manager");
  } catch (err) {
    console.error("[admin] could not clear manager flag:", err);
  }
}
