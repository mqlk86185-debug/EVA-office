/**
 * Offline data layer for EVA Office.
 *
 * Keeps the exact same shape as the old HTTP client so every screen works
 * unchanged, but all reads and writes go to IndexedDB on the device. No server,
 * no account, and everything stays available without a connection.
 */

import { idbDelete, idbGet, idbGetList, idbSet, newId } from "./idb";
import {
  DEFAULT_PAGE_SETUP,
  type ExamQuestion,
  type OfficeFile,
  type OfficeFolder,
  type PageSetup,
  type PdfAnnotation,
} from "./types";

const FILES = "files";
const QUESTIONS = "questions";
const ANNOTATIONS = "annotations";
const FOLDERS = "folders";
const pdfKey = (id: string) => `pdf:${id}`;

function fail(context: string, error: unknown): never {
  console.error(`[office-client] ${context}:`, error);
  throw new Error(
    typeof error === "string" ? error : ((error as Error)?.message ?? "حدث خطأ غير متوقع"),
  );
}

const blobUrls = new Map<string, string>();

/** Returns a fresh in-memory URL for the PDF bytes stored on the device. */
async function attachPdfUrl(file: OfficeFile): Promise<OfficeFile> {
  if (file.doc_type !== "pdf") return file;
  const cached = blobUrls.get(file._id);
  if (cached) return { ...file, pdf_file: { name: `${file.title}.pdf`, url: cached } };
  const bytes = await idbGet<ArrayBuffer | Uint8Array>(pdfKey(file._id));
  if (!bytes) return file;
  const url = URL.createObjectURL(new Blob([bytes as BlobPart], { type: "application/pdf" }));
  blobUrls.set(file._id, url);
  return { ...file, pdf_file: { name: `${file.title}.pdf`, url } };
}

function forgetPdfUrl(id: string) {
  const url = blobUrls.get(id);
  if (url) {
    URL.revokeObjectURL(url);
    blobUrls.delete(id);
  }
}

async function readFiles(): Promise<OfficeFile[]> {
  return idbGetList<OfficeFile>(FILES);
}

async function writeFiles(files: OfficeFile[]): Promise<void> {
  await idbSet(FILES, files);
}

export async function listFiles(
  params: {
    app?: string;
    doc_type?: string;
    search?: string;
    favorite?: boolean;
    trashed?: boolean;
    limit?: number;
  } = {},
): Promise<OfficeFile[]> {
  try {
    let list = await readFiles();
    list = list.filter((f) => (f.is_trashed === "yes") === Boolean(params.trashed));
    if (params.favorite) list = list.filter((f) => f.is_favorite === "yes");
    if (params.app) list = list.filter((f) => f.app_type === params.app);
    if (params.doc_type) list = list.filter((f) => f.doc_type === params.doc_type);
    if (params.search) {
      const term = params.search.trim().toLowerCase();
      list = list.filter((f) => f.title.toLowerCase().includes(term));
    }
    list.sort(
      (a, b) =>
        new Date(b.last_opened_at ?? b.updatedAt).getTime() -
        new Date(a.last_opened_at ?? a.updatedAt).getTime(),
    );
    if (params.limit) list = list.slice(0, params.limit);
    return await Promise.all(list.map(attachPdfUrl));
  } catch (err) {
    fail("listFiles", err);
  }
}

export async function getFile(id: string): Promise<OfficeFile> {
  try {
    const found = (await readFiles()).find((f) => f._id === id);
    if (!found) throw new Error("الملف غير موجود");
    return await attachPdfUrl(found);
  } catch (err) {
    fail("getFile", err);
  }
}

export async function createFile(payload: {
  title: string;
  doc_type: string;
  app_type?: string;
  content?: string;
  page_setup?: string;
}): Promise<OfficeFile> {
  try {
    const now = new Date().toISOString();
    const docType = payload.doc_type as OfficeFile["doc_type"];
    const appType = (payload.app_type ??
      (docType === "spreadsheet"
        ? "gilox"
        : docType === "pdf"
          ? "pdf"
          : docType === "note"
            ? "novel"
            : "eva")) as OfficeFile["app_type"];
    const file: OfficeFile = {
      _id: newId(),
      title: payload.title || "بدون عنوان",
      app_type: appType,
      doc_type: docType,
      content: payload.content ?? "",
      page_setup: payload.page_setup ?? JSON.stringify(DEFAULT_PAGE_SETUP),
      is_favorite: "no",
      is_trashed: "no",
      last_opened_at: now,
      createdAt: now,
      updatedAt: now,
    };
    const files = await readFiles();
    await writeFiles([file, ...files]);
    return file;
  } catch (err) {
    fail("createFile", err);
  }
}

export async function updateFile(
  id: string,
  payload: Record<string, unknown>,
): Promise<OfficeFile> {
  try {
    const files = await readFiles();
    const index = files.findIndex((f) => f._id === id);
    if (index === -1) throw new Error("الملف غير موجود");
    const next: OfficeFile = {
      ...files[index],
      ...(payload as Partial<OfficeFile>),
      updatedAt: new Date().toISOString(),
    };
    files[index] = next;
    await writeFiles(files);
    return next;
  } catch (err) {
    fail("updateFile", err);
  }
}

export async function deleteFileForever(id: string): Promise<void> {
  try {
    const files = await readFiles();
    await writeFiles(files.filter((f) => f._id !== id));
    forgetPdfUrl(id);
    await idbDelete(pdfKey(id));
    const questions = await idbGetList<ExamQuestion>(QUESTIONS);
    await idbSet(
      QUESTIONS,
      questions.filter((q) => q.office_file !== id),
    );
    const annotations = await idbGetList<PdfAnnotation>(ANNOTATIONS);
    await idbSet(
      ANNOTATIONS,
      annotations.filter((a) => a.office_file !== id),
    );
  } catch (err) {
    fail("deleteFileForever", err);
  }
}

/** Strips characters that break file names on Windows/Android downloads. */
function safeFileName(title: string): string {
  const cleaned = (title || "").replace(/[\\/:*?"<>|\u0000-\u001f]/g, " ").trim();
  return (cleaned || "document").slice(0, 80);
}

/** Saves a blob to the device through a temporary download link. */
function isMobileShell(): boolean {
  if (typeof navigator === "undefined") return false;
  const ua = navigator.userAgent || "";
  const standalone =
    typeof window !== "undefined" &&
    (window.matchMedia?.("(display-mode: standalone)").matches ||
      (navigator as Navigator & { standalone?: boolean }).standalone === true);
  return /Android|iPhone|iPad|iPod|wv\)|; wv|Median|GoNative/i.test(ua) || !!standalone;
}

/**
 * Saves a blob in the most reliable way for the current environment.
 * Mobile apps / WebViews often ignore `<a download>`, so we try the native
 * share sheet first, then a regular download, then opening the file.
 * Never throws — the file was generated successfully either way.
 */
export async function saveBlob(blob: Blob, filename: string): Promise<void> {
  const type = blob.type || (filename.endsWith(".pdf") ? "application/pdf" : "image/png");
  if (isMobileShell()) {
    try {
      const file = new File([blob], filename, { type });
      const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
      if (nav.share && nav.canShare?.({ files: [file] })) {
        await nav.share({ files: [file], title: filename });
        return;
      }
    } catch (err) {
      if ((err as Error)?.name === "AbortError") return; // user closed share sheet
      console.warn("[saveBlob] share failed, falling back:", err);
    }
  }
  try {
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.rel = "noopener";
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    link.remove();
    if (isMobileShell()) {
      // Some WebViews silently ignore downloads — also try opening the file.
      setTimeout(() => {
        try {
          window.open(url, "_blank");
        } catch {
          /* ignore */
        }
      }, 400);
    }
    setTimeout(() => URL.revokeObjectURL(url), 120_000);
    return;
  } catch (err) {
    console.warn("[saveBlob] download link failed, trying data URL:", err);
  }
  try {
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(String(r.result));
      r.onerror = () => reject(r.error);
      r.readAsDataURL(blob);
    });
    window.location.assign(dataUrl);
  } catch (err) {
    console.error("[saveBlob] all save strategies failed:", err);
  }
}

async function safeUpdateCount(id: string, count: number) {
  try {
    await updateFile(id, { page_count: count });
  } catch (err) {
    console.warn("[export] page count update skipped:", err);
  }
}

/** Renders the paginated pages to a PDF in the browser and saves it locally. */
export async function exportPdf(
  id: string,
  pages: string[],
  page_setup: PageSetup,
  title: string,
): Promise<{ pages: number }> {
  try {
    const { renderPagesToPdfBlob } = await import("./pdf-render");
    const blob = await renderPagesToPdfBlob(pages, page_setup, title);
    if (!blob.size) throw new Error("الملف الناتج فارغ");
    saveBlob(blob, `${safeFileName(title)}.pdf`);
    await updateFile(id, { page_count: pages.length });
    return { pages: pages.length };
  } catch (err) {
    fail("exportPdf", err);
  }
}

/** Renders every page as a PNG image and saves them to the device. */
export async function exportPng(
  id: string,
  pages: string[],
  page_setup: PageSetup,
  title: string,
): Promise<{ pages: number }> {
  try {
    const { renderPagesToPngBlobs } = await import("./pdf-render");
    const blobs = await renderPagesToPngBlobs(pages, page_setup, title);
    const base = safeFileName(title);
    blobs.forEach((blob, index) => {
      const name = blobs.length > 1 ? `${base}-${index + 1}.png` : `${base}.png`;
      setTimeout(() => saveBlob(blob, name), index * 300);
    });
    await updateFile(id, { page_count: pages.length });
    return { pages: blobs.length };
  } catch (err) {
    fail("exportPng", err);
  }
}

/** ينزّل ملف PDF المخزّن على الجهاز كما هو. */
export async function downloadStoredPdf(id: string, title: string): Promise<void> {
  try {
    const bytes = await idbGet<ArrayBuffer | Uint8Array>(pdfKey(id));
    if (!bytes) throw new Error("لا يوجد ملف PDF مخزّن");
    const blob = new Blob([bytes as BlobPart], { type: "application/pdf" });
    await saveBlob(blob, `${safeFileName(title)}.pdf`);
  } catch (err) {
    fail("downloadStoredPdf", err);
  }
}

/* ---------------- exam questions ---------------- */

export async function listQuestions(fileId: string): Promise<ExamQuestion[]> {
  try {
    const all = await idbGetList<ExamQuestion>(QUESTIONS);
    return all
      .filter((q) => q.office_file === fileId)
      .sort((a, b) => (a.order_index ?? 0) - (b.order_index ?? 0));
  } catch (err) {
    fail("listQuestions", err);
  }
}

export async function createQuestion(
  fileId: string,
  payload: Partial<ExamQuestion>,
): Promise<ExamQuestion> {
  try {
    const all = await idbGetList<ExamQuestion>(QUESTIONS);
    const question: ExamQuestion = {
      _id: newId(),
      question_text: "",
      question_type: "multiple_choice",
      ...payload,
      office_file: fileId,
    };
    await idbSet(QUESTIONS, [...all, question]);
    return question;
  } catch (err) {
    fail("createQuestion", err);
  }
}

export async function updateQuestion(id: string, payload: Partial<ExamQuestion>): Promise<void> {
  try {
    const all = await idbGetList<ExamQuestion>(QUESTIONS);
    await idbSet(
      QUESTIONS,
      all.map((q) => (q._id === id ? { ...q, ...payload } : q)),
    );
  } catch (err) {
    fail("updateQuestion", err);
  }
}

export async function deleteQuestion(id: string): Promise<void> {
  try {
    const all = await idbGetList<ExamQuestion>(QUESTIONS);
    await idbSet(
      QUESTIONS,
      all.filter((q) => q._id !== id),
    );
  } catch (err) {
    fail("deleteQuestion", err);
  }
}

/* ---------------- PDF annotations ---------------- */

export async function listAnnotations(fileId: string): Promise<PdfAnnotation[]> {
  try {
    const all = await idbGetList<PdfAnnotation>(ANNOTATIONS);
    return all.filter((a) => a.office_file === fileId);
  } catch (err) {
    fail("listAnnotations", err);
  }
}

export async function createAnnotation(
  fileId: string,
  payload: Partial<PdfAnnotation>,
): Promise<PdfAnnotation> {
  try {
    const all = await idbGetList<PdfAnnotation>(ANNOTATIONS);
    const annotation: PdfAnnotation = {
      _id: newId(),
      annotation_type: "highlight",
      page_number: 1,
      ...payload,
      office_file: fileId,
    };
    await idbSet(ANNOTATIONS, [...all, annotation]);
    return annotation;
  } catch (err) {
    fail("createAnnotation", err);
  }
}

export async function updateAnnotation(
  id: string,
  payload: Partial<PdfAnnotation>,
): Promise<void> {
  try {
    const all = await idbGetList<PdfAnnotation>(ANNOTATIONS);
    await idbSet(
      ANNOTATIONS,
      all.map((a) => (a._id === id ? { ...a, ...payload } : a)),
    );
  } catch (err) {
    fail("updateAnnotation", err);
  }
}

export async function deleteAnnotation(id: string): Promise<void> {
  try {
    const all = await idbGetList<PdfAnnotation>(ANNOTATIONS);
    await idbSet(
      ANNOTATIONS,
      all.filter((a) => a._id !== id),
    );
  } catch (err) {
    fail("deleteAnnotation", err);
  }
}

/* ---------------- folders ---------------- */

export async function listFolders(): Promise<OfficeFolder[]> {
  try {
    return await idbGetList<OfficeFolder>(FOLDERS);
  } catch (err) {
    fail("listFolders", err);
  }
}

/* ---------------- PDF binaries ---------------- */

export async function savePdfBytes(payload: {
  file_id?: string;
  title: string;
  bytes: Uint8Array;
  page_count?: number;
  as_new?: boolean;
}): Promise<OfficeFile> {
  try {
    const buffer = payload.bytes.slice().buffer;
    let file: OfficeFile;
    if (payload.file_id && !payload.as_new) {
      file = await updateFile(payload.file_id, {
        title: payload.title,
        page_count: payload.page_count ?? null,
      });
      forgetPdfUrl(file._id);
    } else {
      file = await createFile({ title: payload.title, doc_type: "pdf", app_type: "pdf" });
      if (payload.page_count) {
        file = await updateFile(file._id, { page_count: payload.page_count });
      }
    }
    await idbSet(pdfKey(file._id), buffer);
    return await attachPdfUrl(file);
  } catch (err) {
    fail("savePdfBytes", err);
  }
}

export async function uploadPdf(file: File, pageCount?: number): Promise<OfficeFile> {
  try {
    const bytes = new Uint8Array(await file.arrayBuffer());
    return await savePdfBytes({
      title: file.name.replace(/\.pdf$/i, ""),
      bytes,
      page_count: pageCount,
    });
  } catch (err) {
    fail("uploadPdf", err);
  }
}

/** Stores an image on the device and returns a data URL usable inside documents. */
export async function uploadImage(file: File): Promise<string> {
  return await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error ?? new Error("تعذّر قراءة الصورة"));
    reader.readAsDataURL(file);
  });
}

/** Shares a URL via the Web Share API, falling back to the clipboard. */
export async function shareUrl(title: string, url: string): Promise<"shared" | "copied"> {
  const absolute = url.startsWith("http") || url.startsWith("blob:")
    ? url
    : `${window.location.origin}${url}`;
  if (navigator.share) {
    try {
      await navigator.share({ title, url: absolute });
      return "shared";
    } catch (err) {
      if ((err as Error)?.name === "AbortError") return "shared";
      console.error("[shareUrl] native share failed, falling back to clipboard:", err);
    }
  }
  await navigator.clipboard.writeText(absolute);
  return "copied";
}
