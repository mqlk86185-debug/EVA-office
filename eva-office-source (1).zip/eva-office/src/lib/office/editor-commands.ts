"use client";

/**
 * DOM-level commands powering the EVA rich-text editor.
 * Built on `document.execCommand`, which is still the only cross-browser way to
 * get native undo/redo and selection-aware formatting inside contentEditable.
 */

export function focusEditor(el: HTMLElement | null) {
  if (el && document.activeElement !== el) el.focus();
}

export function exec(command: string, value?: string): boolean {
  try {
    document.execCommand("styleWithCSS", false, "true");
    return document.execCommand(command, false, value);
  } catch (err) {
    console.error(`[editor] command "${command}" failed:`, err);
    return false;
  }
}

export function queryState(command: string): boolean {
  try {
    return document.queryCommandState(command);
  } catch {
    return false;
  }
}

/** execCommand only knows 7 font sizes — map the result back to real pixels. */
/**
 * Sets the font size on the current selection to an exact pixel value.
 *
 * `execCommand("fontSize", …)` only accepts the legacy 1–7 scale, and with
 * `styleWithCSS` on (required for our other commands) Chromium doesn't even
 * wrap it in a `<font size="7">` tag when the selection already touches a
 * styled span — it silently rewrites that span's style to a CSS keyword like
 * `xxx-large` instead of a pixel value. So we set the size manually via the
 * Range API: wrap the selected content in one span carrying the exact size,
 * and strip any inline font-size left on its descendants so it isn't
 * overridden by a more specific nested style.
 */
export function setFontSize(editor: HTMLElement, px: number) {
  const selection = window.getSelection();
  const hasSelection =
    selection &&
    selection.rangeCount > 0 &&
    !selection.isCollapsed &&
    editor.contains(selection.anchorNode);

  if (!hasSelection) {
    // No text selected (just a caret) — fall back to the legacy path so the
    // browser still remembers a size for text typed next.
    exec("fontSize", "7");
    editor.querySelectorAll<HTMLElement>('font[size="7"]').forEach((node) => {
      const span = document.createElement("span");
      span.style.fontSize = `${px}px`;
      span.innerHTML = node.innerHTML;
      node.replaceWith(span);
    });
    return;
  }

  const range = selection.getRangeAt(0);
  const span = document.createElement("span");
  span.style.fontSize = `${px}px`;
  span.appendChild(range.extractContents());
  span.querySelectorAll<HTMLElement>("[style]").forEach((node) => {
    node.style.removeProperty("font-size");
    if (!node.getAttribute("style")) node.removeAttribute("style");
  });
  range.insertNode(span);

  const after = document.createRange();
  after.selectNodeContents(span);
  selection.removeAllRanges();
  selection.addRange(after);
}

export function setFontFamily(family: string) {
  exec("fontName", family);
}

/** Common quick-step sizes for the A+ / A- buttons, in pixels. */
export const FONT_SIZE_STEPS = [10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 40, 48, 60, 72];

/** Reads the effective font size (px) at the caret/selection, falling back to the editor's own size. */
export function getCaretFontSizePx(editor: HTMLElement): number {
  const selection = window.getSelection();
  let node: Node | null =
    selection && selection.rangeCount > 0 && editor.contains(selection.anchorNode)
      ? selection.anchorNode
      : null;
  let el = node instanceof Element ? node : node?.parentElement ?? null;
  if (!el || !editor.contains(el)) el = editor;
  const px = parseFloat(getComputedStyle(el).fontSize);
  return Number.isFinite(px) && px > 0 ? Math.round(px) : 16;
}

/** Steps the selection's font size up/down through `FONT_SIZE_STEPS`. */
export function stepFontSize(editor: HTMLElement, direction: 1 | -1) {
  const current = getCaretFontSizePx(editor);
  const next =
    direction > 0
      ? FONT_SIZE_STEPS.find((s) => s > current) ?? FONT_SIZE_STEPS[FONT_SIZE_STEPS.length - 1]
      : [...FONT_SIZE_STEPS].reverse().find((s) => s < current) ?? FONT_SIZE_STEPS[0];
  setFontSize(editor, next);
  return next;
}

/** Blocks (paragraphs, headings, list items) touched by the current selection. */
export function selectedBlocks(editor: HTMLElement): HTMLElement[] {
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0) return [];
  const range = sel.getRangeAt(0);

  const blocks = Array.from(
    editor.querySelectorAll<HTMLElement>("p, h1, h2, h3, h4, li, div, blockquote, td, th")
  ).filter((el) => range.intersectsNode(el));

  if (blocks.length) {
    // Keep only the innermost blocks so styles are not applied twice.
    return blocks.filter((el) => !blocks.some((other) => other !== el && el.contains(other)));
  }

  let node: Node | null = range.startContainer;
  while (node && node !== editor) {
    if (node.nodeType === Node.ELEMENT_NODE && /^(P|H1|H2|H3|H4|LI|DIV|TD|TH)$/.test((node as HTMLElement).tagName)) {
      return [node as HTMLElement];
    }
    node = node.parentNode;
  }
  return [];
}

export function applyToBlocks(editor: HTMLElement, apply: (el: HTMLElement) => void) {
  const blocks = selectedBlocks(editor);
  if (!blocks.length) {
    // Nothing selected yet: normalise the editor into a paragraph first.
    exec("formatBlock", "<p>");
    selectedBlocks(editor).forEach(apply);
    return;
  }
  blocks.forEach(apply);
}

export function setLineHeight(editor: HTMLElement, value: number) {
  applyToBlocks(editor, (el) => {
    el.style.lineHeight = String(value);
  });
}

export function setParagraphSpacing(editor: HTMLElement, px: number) {
  applyToBlocks(editor, (el) => {
    el.style.marginBottom = `${px}px`;
  });
}

export function insertHtml(html: string) {
  exec("insertHTML", html);
}

export function insertDivider(opts: { thickness: number; width: number; color: string }) {
  insertHtml(
    `<hr style="border:none;border-top:${opts.thickness}px solid ${opts.color};width:${opts.width}%;margin:14px auto;" /><p><br></p>`
  );
}

export const FRAME_STYLES = [
  { key: "solid", label: "متصل" },
  { key: "dashed", label: "متقطع" },
  { key: "dotted", label: "منقّط" },
  { key: "double", label: "مزدوج" },
] as const;

/**
 * Inserts a block-level HTML fragment directly via the Range API instead of
 * `execCommand("insertHTML", …)`. `execCommand` parses the fragment relative
 * to the caret's exact inline context, and when the caret sits inside inline
 * formatting (e.g. right after </em> at the end of a paragraph) some browsers
 * silently unwrap block elements like <div> and merge their text into the
 * surrounding paragraph instead of inserting them as siblings. Building the
 * nodes and inserting them with `range.insertNode` sidesteps that entirely.
 */
function insertBlockAtCaret(editor: HTMLElement, html: string) {
  const selection = window.getSelection();
  let range: Range;

  if (selection && selection.rangeCount > 0 && editor.contains(selection.anchorNode)) {
    range = selection.getRangeAt(0);
  } else {
    range = document.createRange();
    range.selectNodeContents(editor);
    range.collapse(false);
  }
  range.deleteContents();

  const template = document.createElement("template");
  template.innerHTML = html;
  const fragment = template.content;
  const lastNode = fragment.lastChild;
  range.insertNode(fragment);

  if (lastNode && selection) {
    const after = document.createRange();
    after.setStartAfter(lastNode);
    after.collapse(true);
    selection.removeAllRanges();
    selection.addRange(after);
  }
}

export function insertFrame(
  editor: HTMLElement,
  opts: { thickness: number; color: string; style: "solid" | "dashed" | "dotted" | "double"; radius: number }
) {
  insertBlockAtCaret(
    editor,
    `<div class="eva-frame" style="border:${opts.thickness}px ${opts.style} ${opts.color};border-radius:${opts.radius}px;padding:14px 16px;margin:12px 0;">اكتب محتوى الإطار هنا…</div><p><br></p>`
  );
}

export function insertPageBreak() {
  insertHtml('<div class="eva-pagebreak" contenteditable="false">— فاصل صفحة —</div><p><br></p>');
}

export function insertTable(rows: number, cols: number, withHeader: boolean) {
  const head = withHeader
    ? `<thead><tr>${Array.from({ length: cols })
        .map((_, i) => `<th>عنوان ${i + 1}</th>`)
        .join("")}</tr></thead>`
    : "";
  const bodyRows = Array.from({ length: withHeader ? rows - 1 : rows })
    .map(() => `<tr>${Array.from({ length: cols }).map(() => "<td><br></td>").join("")}</tr>`)
    .join("");
  insertHtml(`<table>${head}<tbody>${bodyRows}</tbody></table><p><br></p>`);
}

export function insertTextBox(text = "اكتب هنا…") {
  insertHtml(`<div class="eva-textbox">${text}</div><p><br></p>`);
}

export function insertFreeText(editor: HTMLElement, x: number, y: number) {
  const el = document.createElement("div");
  el.className = "eva-float eva-free-text";
  el.contentEditable = "false";
  el.dataset.kind = "text";
  el.style.left = `${Math.max(0, Math.min(editor.clientWidth - 180, Math.round(x)))}px`;
  el.style.top = `${Math.max(0, Math.round(y))}px`;
  el.style.width = "180px";
  el.style.height = "54px";
  el.innerHTML = '<div class="eva-free-text-content" contenteditable="true" dir="rtl">اكتب هنا…</div>';
  editor.appendChild(el);
  const content = el.querySelector<HTMLElement>(".eva-free-text-content");
  content?.focus();
  const selection = window.getSelection();
  if (content && selection) {
    const range = document.createRange();
    range.selectNodeContents(content);
    selection.removeAllRanges();
    selection.addRange(range);
  }
  editor.dispatchEvent(new Event("input", { bubbles: true }));
  return el;
}

/* -------------------- floating objects (images & shapes) -------------------- */

/** Where to drop a new floating object: next to the caret, or near the top. */
function floatDropPoint(editor: HTMLElement, w: number): { x: number; y: number } {
  const sel = window.getSelection();
  const er = editor.getBoundingClientRect();
  const scale = er.width / (editor.offsetWidth || er.width) || 1;
  let x = Math.max(0, (editor.offsetWidth - w) / 2);
  let y = 10;
  if (sel && sel.rangeCount && editor.contains(sel.anchorNode)) {
    const r = sel.getRangeAt(0).getBoundingClientRect();
    if (r.height || r.top) y = Math.max(0, (r.bottom - er.top) / scale + 6);
  }
  return { x: Math.round(x), y: Math.round(y) };
}

export function insertFloat(editor: HTMLElement, inner: string, w: number, h: number, kind: string) {
  const { x, y } = floatDropPoint(editor, w);
  const el = document.createElement("div");
  el.className = "eva-float";
  el.contentEditable = "false";
  el.dataset.kind = kind;
  el.style.left = `${x}px`;
  el.style.top = `${y}px`;
  el.style.width = `${w}px`;
  el.style.height = `${h}px`;
  el.innerHTML = inner;
  editor.appendChild(el);
  return el;
}

export function insertImage(editor: HTMLElement, url: string) {
  const w = Math.min(260, Math.round(editor.offsetWidth * 0.5));
  const el = insertFloat(editor, `<img src="${url}" alt="" />`, w, w, "image");
  const img = el.querySelector("img");
  if (!img) return;
  const fit = () => {
    if (img.naturalWidth) el.style.height = `${Math.round((w * img.naturalHeight) / img.naturalWidth)}px`;
    editor.dispatchEvent(new Event("input", { bubbles: true }));
  };
  if (img.complete) fit();
  else img.addEventListener("load", fit, { once: true });
}

const poly = (n: number, rot = -90, r = 46) =>
  Array.from({ length: n }, (_, i) => {
    const a = ((rot + (360 / n) * i) * Math.PI) / 180;
    return `${(50 + r * Math.cos(a)).toFixed(1)},${(50 + r * Math.sin(a)).toFixed(1)}`;
  }).join(" ");

const star = (n: number, inner = 0.45) =>
  Array.from({ length: n * 2 }, (_, i) => {
    const r = i % 2 ? 46 * inner : 46;
    const a = ((-90 + (180 / n) * i) * Math.PI) / 180;
    return `${(50 + r * Math.cos(a)).toFixed(1)},${(50 + r * Math.sin(a)).toFixed(1)}`;
  }).join(" ");

/** Shape catalogue: key, Arabic label and the SVG body (viewBox 0 0 100 100). */
const SHAPE_DEFS: { key: string; label: string; body: (f: string) => string }[] = [
  { key: "square", label: "مربع", body: (f) => `<rect x="6" y="6" width="88" height="88" fill="${f}"/>` },
  { key: "rect", label: "مستطيل", body: (f) => `<rect x="4" y="22" width="92" height="56" fill="${f}"/>` },
  { key: "rounded", label: "مستطيل مستدير", body: (f) => `<rect x="4" y="22" width="92" height="56" rx="12" fill="${f}"/>` },
  { key: "circle", label: "دائرة", body: (f) => `<circle cx="50" cy="50" r="46" fill="${f}"/>` },
  { key: "ellipse", label: "بيضاوي", body: (f) => `<ellipse cx="50" cy="50" rx="46" ry="30" fill="${f}"/>` },
  { key: "triangle", label: "مثلث", body: (f) => `<polygon points="50,6 94,92 6,92" fill="${f}"/>` },
  { key: "rtriangle", label: "مثلث قائم", body: (f) => `<polygon points="6,6 6,94 94,94" fill="${f}"/>` },
  { key: "diamond", label: "معيّن", body: (f) => `<polygon points="50,4 96,50 50,96 4,50" fill="${f}"/>` },
  { key: "parallelogram", label: "متوازي أضلاع", body: (f) => `<polygon points="26,20 96,20 74,80 4,80" fill="${f}"/>` },
  { key: "trapezoid", label: "شبه منحرف", body: (f) => `<polygon points="26,20 74,20 96,80 4,80" fill="${f}"/>` },
  { key: "pentagon", label: "خماسي", body: (f) => `<polygon points="${poly(5)}" fill="${f}"/>` },
  { key: "hexagon", label: "سداسي", body: (f) => `<polygon points="${poly(6, 0)}" fill="${f}"/>` },
  { key: "heptagon", label: "سباعي", body: (f) => `<polygon points="${poly(7)}" fill="${f}"/>` },
  { key: "octagon", label: "ثماني", body: (f) => `<polygon points="${poly(8, 22.5)}" fill="${f}"/>` },
  { key: "star", label: "نجمة خماسية", body: (f) => `<polygon points="${star(5, 0.42)}" fill="${f}"/>` },
  { key: "star6", label: "نجمة سداسية", body: (f) => `<polygon points="${star(6, 0.55)}" fill="${f}"/>` },
  { key: "star8", label: "نجمة ثمانية", body: (f) => `<polygon points="${star(8, 0.6)}" fill="${f}"/>` },
  { key: "heart", label: "قلب", body: (f) => `<path d="M50 90 C10 62 4 40 14 24 C24 8 44 12 50 28 C56 12 76 8 86 24 C96 40 90 62 50 90Z" fill="${f}"/>` },
  { key: "plus", label: "علامة زائد", body: (f) => `<polygon points="36,6 64,6 64,36 94,36 94,64 64,64 64,94 36,94 36,64 6,64 6,36 36,36" fill="${f}"/>` },
  { key: "crescent", label: "هلال", body: (f) => `<path d="M62 6 A44 44 0 1 0 62 94 A36 36 0 1 1 62 6Z" fill="${f}"/>` },
  { key: "arrow-left", label: "سهم يسار", body: (f) => `<polygon points="4,50 40,18 40,36 96,36 96,64 40,64 40,82" fill="${f}"/>` },
  { key: "arrow", label: "سهم يمين", body: (f) => `<polygon points="96,50 60,18 60,36 4,36 4,64 60,64 60,82" fill="${f}"/>` },
  { key: "arrow-up", label: "سهم أعلى", body: (f) => `<polygon points="50,4 82,40 64,40 64,96 36,96 36,40 18,40" fill="${f}"/>` },
  { key: "arrow-down", label: "سهم أسفل", body: (f) => `<polygon points="50,96 82,60 64,60 64,4 36,4 36,60 18,60" fill="${f}"/>` },
  { key: "arrow-both", label: "سهم مزدوج", body: (f) => `<polygon points="4,50 28,24 28,40 72,40 72,24 96,50 72,76 72,60 28,60 28,76" fill="${f}"/>` },
  { key: "bubble", label: "فقاعة كلام", body: (f) => `<path d="M10 10 H90 Q96 10 96 16 V62 Q96 68 90 68 H40 L22 90 L26 68 H10 Q4 68 4 62 V16 Q4 10 10 10Z" fill="${f}"/>` },
  { key: "cloud", label: "سحابة", body: (f) => `<path d="M26 80 A18 18 0 0 1 22 44 A22 22 0 0 1 62 30 A18 18 0 0 1 84 48 A16 16 0 0 1 80 80Z" fill="${f}"/>` },
  { key: "ring", label: "حلقة", body: (f) => `<circle cx="50" cy="50" r="38" fill="none" stroke="${f}" stroke-width="12"/>` },
  { key: "frame", label: "إطار مربع", body: (f) => `<rect x="10" y="10" width="80" height="80" fill="none" stroke="${f}" stroke-width="8"/>` },
  { key: "line", label: "خط", body: (f) => `<rect x="0" y="46" width="100" height="8" rx="4" fill="${f}"/>` },
];

export const SHAPES = SHAPE_DEFS.map(({ key, label }) => ({ key, label }));

export function shapeSvg(kind: string, color: string, size = 90): string {
  const def = SHAPE_DEFS.find((d) => d.key === kind) ?? SHAPE_DEFS[0];
  return `<svg width="${size}" height="${size}" viewBox="0 0 100 100" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">${def.body(color)}</svg>`;
}

export function insertShape(editor: HTMLElement, kind: string, color: string) {
  const isLine = kind === "line";
  const w = isLine ? 200 : kind === "rect" || kind === "rounded" || kind === "ellipse" ? 160 : 110;
  const h = isLine ? 14 : kind === "rect" || kind === "rounded" || kind === "ellipse" ? 100 : 110;
  insertFloat(editor, shapeSvg(kind, color), w, h, "shape");
}

/** Rich colour palette for shapes. */
export const SHAPE_PALETTE = [
  "#ef4444", "#f97316", "#f59e0b", "#eab308", "#84cc16", "#22c55e", "#10b981", "#14b8a6",
  "#06b6d4", "#0ea5e9", "#3b82f6", "#6366f1", "#8b5cf6", "#d946ef", "#ec4899", "#f43f5e",
  "#b45309", "#d4af37", "#64748b", "#1e293b", "#000000", "#ffffff",
];

export const SHAPE_EFFECTS = [
  { key: "none", label: "بدون" },
  { key: "gradient", label: "تدرّج" },
  { key: "shadow", label: "ظل" },
  { key: "glow", label: "توهج" },
  { key: "neon", label: "نيون" },
  { key: "3d", label: "ثلاثي الأبعاد" },
  { key: "glass", label: "زجاجي" },
  { key: "metal", label: "معدني" },
];

function shade(hex: string, amt: number): string {
  const n = parseInt(hex.replace("#", "").padEnd(6, "0").slice(0, 6), 16);
  const c = [n >> 16, (n >> 8) & 255, n & 255].map((v) => Math.round(amt >= 0 ? v + (255 - v) * amt : v * (1 + amt)));
  return `#${c.map((v) => Math.max(0, Math.min(255, v)).toString(16).padStart(2, "0")).join("")}`;
}

function paint(el: HTMLElement, value: string) {
  el.querySelectorAll("svg > :not(defs)").forEach((n) => {
    if (n.getAttribute("fill") && n.getAttribute("fill") !== "none") n.setAttribute("fill", value);
    if (n.getAttribute("stroke")) n.setAttribute("stroke", value);
  });
}

/** Applies a visual effect (gradient, shadow, glow, neon, 3D, glass, metal) to a shape. */
export function setShapeEffect(el: HTMLElement, effect: string) {
  const color = getShapeColor(el);
  const svg = el.querySelector("svg");
  if (!svg) return;
  el.dataset.color = color;
  svg.querySelector("defs")?.remove();
  svg.style.filter = "";
  svg.style.opacity = "";
  el.dataset.effect = effect;
  const id = `g${Math.random().toString(36).slice(2, 9)}`;
  const grad = (stops: [number, string, number?][], radial = false) => {
    const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
    const tag = radial ? "radialGradient" : "linearGradient";
    const attrs = radial ? `cx="35%" cy="30%" r="75%"` : `x1="0" y1="0" x2="1" y2="1"`;
    defs.innerHTML = `<${tag} id="${id}" ${attrs}>${stops.map(([o, c, a]) => `<stop offset="${o}" stop-color="${c}" stop-opacity="${a ?? 1}"/>`).join("")}</${tag}>`;
    svg.prepend(defs);
    paint(el, `url(#${id})`);
  };
  paint(el, color);
  switch (effect) {
    case "gradient": grad([[0, shade(color, 0.45)], [1, shade(color, -0.35)]]); break;
    case "shadow": svg.style.filter = "drop-shadow(4px 6px 6px rgba(0,0,0,.35))"; break;
    case "glow": svg.style.filter = `drop-shadow(0 0 6px ${color}) drop-shadow(0 0 14px ${color})`; break;
    case "neon": grad([[0, "#ffffff"], [0.5, shade(color, 0.3)], [1, color]], true); svg.style.filter = `drop-shadow(0 0 4px ${color}) drop-shadow(0 0 12px ${color}) drop-shadow(0 0 24px ${color})`; break;
    case "3d": grad([[0, shade(color, 0.55)], [0.6, color], [1, shade(color, -0.5)]], true); svg.style.filter = `drop-shadow(3px 3px 0 ${shade(color, -0.55)}) drop-shadow(5px 8px 6px rgba(0,0,0,.35))`; break;
    case "glass": grad([[0, shade(color, 0.7), 0.85], [1, color, 0.45]]); svg.style.filter = "drop-shadow(0 4px 10px rgba(0,0,0,.18))"; break;
    case "metal": grad([[0, shade(color, 0.7)], [0.35, shade(color, -0.2)], [0.55, shade(color, 0.6)], [1, shade(color, -0.45)]]); svg.style.filter = "drop-shadow(2px 4px 4px rgba(0,0,0,.3))"; break;
  }
}

/** Recolours every filled/stroked part of a shape's SVG (keeps the current effect). */
export function setShapeColor(el: HTMLElement, color: string) {
  el.dataset.color = color;
  paint(el, color);
  if (el.dataset.effect && el.dataset.effect !== "none") setShapeEffect(el, el.dataset.effect);
}

export function getShapeColor(el: HTMLElement): string {
  if (el.dataset.color) return el.dataset.color;
  const n = el.querySelector("svg [fill]:not([fill='none'])") ?? el.querySelector("svg [stroke]");
  const v = n?.getAttribute("fill") ?? n?.getAttribute("stroke") ?? "";
  return v && !v.startsWith("url(") ? v : "#6366f1";
}

/** Returns (creating if needed) the editable text layer written on top of a shape. */
export function ensureShapeText(el: HTMLElement): HTMLElement {
  let t = el.querySelector<HTMLElement>(".eva-shape-text");
  if (!t) {
    t = document.createElement("div");
    t.className = "eva-shape-text";
    t.contentEditable = "true";
    t.dir = "auto";
    el.appendChild(t);
  }
  return t;
}

export const SHAPE_TEXT_POSITIONS = [
  { key: "tr", label: "↗", v: "flex-start", h: "flex-end", title: "أعلى يمين" },
  { key: "t", label: "↑", v: "flex-start", h: "center", title: "أعلى" },
  { key: "tl", label: "↖", v: "flex-start", h: "flex-start", title: "أعلى يسار" },
  { key: "r", label: "→", v: "center", h: "flex-end", title: "يمين" },
  { key: "c", label: "•", v: "center", h: "center", title: "الوسط" },
  { key: "l", label: "←", v: "center", h: "flex-start", title: "يسار" },
  { key: "br", label: "↘", v: "flex-end", h: "flex-end", title: "أسفل يمين" },
  { key: "b", label: "↓", v: "flex-end", h: "center", title: "أسفل" },
  { key: "bl", label: "↙", v: "flex-end", h: "flex-start", title: "أسفل يسار" },
] as const;

/** Moves a shape's text to any edge/corner (physical directions, independent of RTL). */
export function setShapeTextPosition(el: HTMLElement, key: string) {
  const p = SHAPE_TEXT_POSITIONS.find((x) => x.key === key);
  if (!p) return;
  const t = ensureShapeText(el);
  t.style.direction = "ltr";
  t.style.alignItems = p.v;
  t.style.justifyContent = p.h;
  t.style.textAlign = p.h === "flex-start" ? "left" : p.h === "flex-end" ? "right" : "center";
  t.style.unicodeBidi = "plaintext";
  el.dataset.textPos = key;
}

/* -------------------- find & replace -------------------- */

const HIT_CLASS = "eva-search-hit";

export function clearHighlights(editor: HTMLElement) {
  editor.querySelectorAll(`.${HIT_CLASS}`).forEach((el) => {
    const parent = el.parentNode;
    if (!parent) return;
    while (el.firstChild) parent.insertBefore(el.firstChild, el);
    parent.removeChild(el);
    parent.normalize();
  });
}

/** Highlights every occurrence and returns the number of hits. */
export function highlightAll(editor: HTMLElement, term: string): number {
  clearHighlights(editor);
  if (!term.trim()) return 0;

  const walker = document.createTreeWalker(editor, NodeFilter.SHOW_TEXT);
  const targets: Text[] = [];
  let node = walker.nextNode() as Text | null;
  while (node) {
    if (node.nodeValue && node.nodeValue.toLowerCase().includes(term.toLowerCase())) targets.push(node);
    node = walker.nextNode() as Text | null;
  }

  let count = 0;
  for (const text of targets) {
    const value = text.nodeValue ?? "";
    const lower = value.toLowerCase();
    const needle = term.toLowerCase();
    const frag = document.createDocumentFragment();
    let index = 0;
    let found = lower.indexOf(needle, index);
    if (found === -1) continue;
    while (found !== -1) {
      if (found > index) frag.appendChild(document.createTextNode(value.slice(index, found)));
      const mark = document.createElement("span");
      mark.className = HIT_CLASS;
      mark.textContent = value.slice(found, found + term.length);
      frag.appendChild(mark);
      count += 1;
      index = found + term.length;
      found = lower.indexOf(needle, index);
    }
    if (index < value.length) frag.appendChild(document.createTextNode(value.slice(index)));
    text.parentNode?.replaceChild(frag, text);
  }
  return count;
}

export function focusHit(editor: HTMLElement, index: number) {
  const hits = Array.from(editor.querySelectorAll<HTMLElement>(`.${HIT_CLASS}`));
  hits.forEach((h) => h.classList.remove("active"));
  const hit = hits[index];
  if (hit) {
    hit.classList.add("active");
    hit.scrollIntoView({ block: "center", behavior: "smooth" });
  }
  return hits.length;
}

/** Replaces the highlighted occurrences (all, or just the active one). */
export function replaceHits(editor: HTMLElement, replacement: string, onlyActive: boolean) {
  const hits = Array.from(editor.querySelectorAll<HTMLElement>(`.${HIT_CLASS}`));
  const list = onlyActive ? hits.filter((h) => h.classList.contains("active")) : hits;
  list.forEach((hit) => {
    hit.replaceWith(document.createTextNode(replacement));
  });
  editor.normalize();
  return list.length;
}

/* -------------------- clipboard -------------------- */

export async function copySelection(cut: boolean) {
  const sel = window.getSelection();
  const text = sel?.toString() ?? "";
  if (!text) return false;
  try {
    await navigator.clipboard.writeText(text);
  } catch (err) {
    console.error("[editor] clipboard write failed, using execCommand:", err);
    exec(cut ? "cut" : "copy");
    return true;
  }
  if (cut) exec("delete");
  return true;
}

export async function pasteFromClipboard() {
  try {
    const text = await navigator.clipboard.readText();
    if (text) insertHtml(text.replace(/</g, "&lt;").replace(/\n/g, "<br>"));
    return true;
  } catch (err) {
    console.error("[editor] clipboard read failed:", err);
    return false;
  }
}

/* -------------------- tables -------------------- */

export interface CellPos {
  row: number;
  col: number;
}

export function tableOf(cell: HTMLTableCellElement): HTMLTableElement | null {
  return cell.closest("table");
}

export function cellMatrix(table: HTMLTableElement): HTMLTableCellElement[][] {
  const rows = Array.from(table.rows);
  const matrix: HTMLTableCellElement[][] = rows.map(() => []);
  rows.forEach((row, r) => {
    Array.from(row.cells).forEach((cell) => {
      let c = 0;
      while (matrix[r][c]) c++;
      for (let dr = 0; dr < cell.rowSpan; dr++) {
        for (let dc = 0; dc < cell.colSpan; dc++) {
          if (matrix[r + dr]) matrix[r + dr][c + dc] = cell;
        }
      }
    });
  });
  return matrix;
}

export function mergeCells(cells: HTMLTableCellElement[]): boolean {
  if (cells.length < 2) return false;
  const table = tableOf(cells[0]);
  if (!table) return false;
  const matrix = cellMatrix(table);

  const positions: CellPos[] = [];
  matrix.forEach((row, r) =>
    row.forEach((cell, c) => {
      if (cells.includes(cell)) positions.push({ row: r, col: c });
    })
  );
  if (!positions.length) return false;

  const r1 = Math.min(...positions.map((p) => p.row));
  const r2 = Math.max(...positions.map((p) => p.row));
  const c1 = Math.min(...positions.map((p) => p.col));
  const c2 = Math.max(...positions.map((p) => p.col));

  const anchor = matrix[r1][c1];
  const contents: string[] = [];
  const removed = new Set<HTMLTableCellElement>();
  for (let r = r1; r <= r2; r++) {
    for (let c = c1; c <= c2; c++) {
      const cell = matrix[r]?.[c];
      if (!cell || cell === anchor || removed.has(cell)) continue;
      const html = cell.innerHTML.trim();
      if (html && html !== "<br>") contents.push(html);
      removed.add(cell);
    }
  }
  removed.forEach((cell) => cell.remove());
  anchor.rowSpan = r2 - r1 + 1;
  anchor.colSpan = c2 - c1 + 1;
  if (contents.length) anchor.innerHTML = [anchor.innerHTML, ...contents].join(" ");
  return true;
}

export function splitCell(cell: HTMLTableCellElement): boolean {
  const rowSpan = cell.rowSpan;
  const colSpan = cell.colSpan;
  if (rowSpan <= 1 && colSpan <= 1) return false;
  const table = tableOf(cell);
  if (!table) return false;
  const matrix = cellMatrix(table);

  let pos: CellPos | null = null;
  matrix.forEach((row, r) =>
    row.forEach((c, ci) => {
      if (c === cell && !pos) pos = { row: r, col: ci };
    })
  );
  if (!pos) return false;
  const at = pos as CellPos;

  cell.rowSpan = 1;
  cell.colSpan = 1;

  for (let r = at.row; r < at.row + rowSpan; r++) {
    const row = table.rows[r];
    if (!row) continue;
    for (let c = at.col; c < at.col + colSpan; c++) {
      if (r === at.row && c === at.col) continue;
      const fresh = document.createElement(cell.tagName === "TH" ? "th" : "td") as HTMLTableCellElement;
      fresh.innerHTML = "<br>";
      const reference = Array.from(row.cells).find((existing) => {
        const m = cellMatrix(table);
        const found = m[r]?.indexOf(existing);
        return found != null && found > c;
      });
      if (reference) row.insertBefore(fresh, reference);
      else row.appendChild(fresh);
    }
  }
  return true;
}

export function addRow(cell: HTMLTableCellElement, after: boolean) {
  const table = tableOf(cell);
  const row = cell.parentElement as HTMLTableRowElement | null;
  if (!table || !row) return;
  const cols = cellMatrix(table)[0]?.length ?? row.cells.length;
  const fresh = table.insertRow(row.rowIndex + (after ? 1 : 0));
  for (let i = 0; i < cols; i++) fresh.insertCell().innerHTML = "<br>";
}

export function addColumn(cell: HTMLTableCellElement, after: boolean) {
  const table = tableOf(cell);
  if (!table) return;
  const matrix = cellMatrix(table);
  let targetCol = -1;
  matrix.forEach((row) =>
    row.forEach((c, ci) => {
      if (c === cell && targetCol === -1) targetCol = ci;
    })
  );
  if (targetCol === -1) return;
  const insertAt = targetCol + (after ? 1 : 0);
  Array.from(table.rows).forEach((row, r) => {
    const anchor = matrix[r]?.[insertAt];
    const isHeaderRow = row.parentElement?.tagName === "THEAD";
    const fresh = document.createElement(isHeaderRow ? "th" : "td") as HTMLTableCellElement;
    fresh.innerHTML = "<br>";
    if (anchor && anchor.parentElement === row) row.insertBefore(fresh, anchor);
    else row.appendChild(fresh);
  });
}

export function deleteRow(cell: HTMLTableCellElement) {
  const table = tableOf(cell);
  const row = cell.parentElement as HTMLTableRowElement | null;
  if (!table || !row) return;
  if (table.rows.length <= 1) table.remove();
  else row.remove();
}

export function deleteColumn(cell: HTMLTableCellElement) {
  const table = tableOf(cell);
  if (!table) return;
  const matrix = cellMatrix(table);
  let targetCol = -1;
  matrix.forEach((row) =>
    row.forEach((c, ci) => {
      if (c === cell && targetCol === -1) targetCol = ci;
    })
  );
  if (targetCol === -1) return;
  const doomed = new Set<HTMLTableCellElement>();
  matrix.forEach((row) => {
    const c = row[targetCol];
    if (c) doomed.add(c);
  });
  doomed.forEach((c) => {
    if (c.colSpan > 1) c.colSpan -= 1;
    else c.remove();
  });
  if (!table.rows.length || !table.rows[0].cells.length) table.remove();
}

export function setColumnWidth(cell: HTMLTableCellElement, width: number) {
  const table = tableOf(cell);
  if (!table) return;
  const matrix = cellMatrix(table);
  let targetCol = -1;
  matrix.forEach((row) =>
    row.forEach((c, ci) => {
      if (c === cell && targetCol === -1) targetCol = ci;
    })
  );
  if (targetCol === -1) return;
  matrix.forEach((row) => {
    const c = row[targetCol];
    if (c) c.style.width = `${width}px`;
  });
}

export function setRowHeight(cell: HTMLTableCellElement, height: number) {
  const row = cell.parentElement as HTMLTableRowElement | null;
  if (row) row.style.height = `${height}px`;
}

export function toggleTableBorders(table: HTMLTableElement) {
  const hidden = table.dataset.borders === "off";
  if (hidden) {
    delete table.dataset.borders;
    table.querySelectorAll<HTMLElement>("td, th").forEach((c) => (c.style.border = ""));
  } else {
    table.dataset.borders = "off";
    table.querySelectorAll<HTMLElement>("td, th").forEach((c) => (c.style.border = "none"));
  }
  return !hidden;
}

/* ---------- Writing direction (per paragraph / text box) ---------- */
export const TEXT_DIRECTIONS = [
  { key: "rtl", label: "من اليمين لليسار" },
  { key: "ltr", label: "من اليسار لليمين" },
  { key: "ttb", label: "من الأعلى للأسفل" },
  { key: "btt", label: "من الأسفل للأعلى" },
] as const;

export function setTextDirection(editor: HTMLElement, dir: string) {
  applyToBlocks(editor, (el) => {
    el.style.removeProperty("writing-mode");
    el.style.removeProperty("transform");
    el.style.removeProperty("text-orientation");
    el.style.removeProperty("min-height");
    if (dir === "rtl" || dir === "ltr") {
      el.setAttribute("dir", dir);
      el.style.direction = dir;
      return;
    }
    el.setAttribute("dir", "rtl");
    el.style.direction = "rtl";
    el.style.minHeight = "8em";
    if (dir === "ttb") {
      el.style.setProperty("writing-mode", "vertical-rl");
    } else {
      el.style.setProperty("writing-mode", "vertical-rl");
      el.style.transform = "rotate(180deg)";
    }
  });
}

/* ---------- Text effects (on selected text) ---------- */
export const TEXT_EFFECTS = [
  { key: "none", label: "بدون تأثير" },
  { key: "shadow", label: "ظل" },
  { key: "glow", label: "توهّج" },
  { key: "neon", label: "نيون" },
  { key: "outline", label: "مفرّغ (حدود)" },
  { key: "gradient-sunset", label: "تدرّج غروب" },
  { key: "gradient-ocean", label: "تدرّج محيط" },
  { key: "gradient-rainbow", label: "تدرّج قوس قزح" },
  { key: "gold", label: "ذهبي" },
  { key: "emboss", label: "بارز ثلاثي الأبعاد" },
] as const;

function effectCss(effect: string, color: string): string {
  const grad = (g: string) =>
    `background-image:${g};-webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-fill-color:transparent;`;
  switch (effect) {
    case "shadow": return `color:${color};text-shadow:2px 2px 4px rgba(0,0,0,.35);`;
    case "glow": return `color:${color};text-shadow:0 0 6px ${color},0 0 12px ${color};`;
    case "neon": return `color:#fff;text-shadow:0 0 4px #fff,0 0 10px ${color},0 0 20px ${color},0 0 34px ${color};`;
    case "outline": return `color:transparent;-webkit-text-fill-color:transparent;-webkit-text-stroke:1.2px ${color};`;
    case "gradient-sunset": return grad("linear-gradient(90deg,#f97316,#ec4899,#eab308)");
    case "gradient-ocean": return grad("linear-gradient(90deg,#0ea5e9,#14b8a6,#2563eb)");
    case "gradient-rainbow": return grad("linear-gradient(90deg,#ef4444,#f59e0b,#22c55e,#3b82f6,#a855f7)");
    case "gold": return grad("linear-gradient(180deg,#fde68a,#d97706 55%,#92400e)") + "text-shadow:none;";
    case "emboss": return `color:${color};text-shadow:1px 1px 0 #fff,2px 2px 0 rgba(0,0,0,.25),3px 3px 3px rgba(0,0,0,.2);`;
    default: return "";
  }
}

export function setTextEffect(editor: HTMLElement, effect: string, color: string): boolean {
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0 || sel.isCollapsed || !editor.contains(sel.anchorNode)) return false;
  const range = sel.getRangeAt(0);
  const span = document.createElement("span");
  const css = effectCss(effect, color);
  if (css) {
    span.setAttribute("style", css);
    span.dataset.textEffect = effect;
  }
  span.appendChild(range.extractContents());
  span.querySelectorAll<HTMLElement>("[data-text-effect]").forEach((n) => {
    n.replaceWith(...Array.from(n.childNodes));
  });
  range.insertNode(span);
  sel.removeAllRanges();
  const r = document.createRange();
  r.selectNodeContents(span);
  sel.addRange(r);
  return true;
}
