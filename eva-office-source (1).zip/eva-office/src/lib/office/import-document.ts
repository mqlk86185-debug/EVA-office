"use client";

/**
 * Converts an uploaded document into EVA editor HTML, entirely in the browser
 * (nothing is sent to a server). Supported: .docx, .pdf (text), .txt, .md,
 * .html. The result is the same `{ html }` shape every EVA document stores.
 */

import { DEFAULT_PAGE_SETUP } from "./types";

export const IMPORT_ACCEPT = ".docx,.pdf,.txt,.md,.markdown,.html,.htm,text/plain,text/html,text/markdown,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document";
const MAX_BYTES = 40 * 1024 * 1024;

const esc = (v: string) => v.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const P = (inner: string) => `<p dir="auto" style="line-height:1.9;margin:0 0 8px;">${inner || "<br>"}</p>`;

export interface ImportedDocument {
  title: string;
  html: string;
}

export async function importDocument(file: File): Promise<ImportedDocument> {
  if (file.size > MAX_BYTES) throw new Error("حجم الملف كبير جدًا (الحد 40 ميجابايت)");
  const name = file.name;
  const ext = (name.split(".").pop() ?? "").toLowerCase();
  const title = name.replace(/\.[^.]+$/, "").trim() || "مستند مستورد";
  let body: string;
  if (ext === "docx") body = await docxToHtml(await file.arrayBuffer());
  else if (ext === "pdf") body = await pdfToHtml(await file.arrayBuffer());
  else if (ext === "html" || ext === "htm") body = htmlToSafeHtml(await file.text());
  else if (ext === "md" || ext === "markdown") body = markdownToHtml(await file.text());
  else if (ext === "txt" || file.type.startsWith("text/")) body = textToHtml(await file.text());
  else if (ext === "doc") throw new Error("صيغة DOC القديمة غير مدعومة، احفظ الملف بصيغة DOCX ثم أعد المحاولة");
  else throw new Error("صيغة غير مدعومة. المدعوم: DOCX وPDF وTXT وMD وHTML");
  if (!body.replace(/<[^>]+>/g, "").trim() && !/<img|<table/.test(body)) {
    throw new Error("لم يتم العثور على نص قابل للاستيراد في الملف");
  }
  return { title, html: `<div dir="rtl">${body}</div>` };
}

/** Payload for `createFile` — same shape the template system uses. */
export function importedPayload(doc: ImportedDocument) {
  return {
    title: doc.title,
    doc_type: "document",
    app_type: "eva",
    content: JSON.stringify({ html: doc.html }),
    page_setup: JSON.stringify({ ...DEFAULT_PAGE_SETUP }),
  };
}

/* ------------------------------ plain text ------------------------------ */

function textToHtml(text: string): string {
  return text
    .replace(/\r\n?/g, "\n")
    .split(/\n{2,}/)
    .map((block) => P(esc(block).replace(/\n/g, "<br>")))
    .join("");
}

/* ------------------------------- markdown ------------------------------- */

function inlineMd(s: string): string {
  return esc(s)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<em>$2</em>")
    .replace(/~~([^~]+)~~/g, "<s>$1</s>");
}

function markdownToHtml(md: string): string {
  const lines = md.replace(/\r\n?/g, "\n").split("\n");
  const out: string[] = [];
  let list: "ul" | "ol" | null = null;
  let para: string[] = [];
  const flushPara = () => { if (para.length) out.push(P(inlineMd(para.join(" ")))); para = []; };
  const closeList = () => { if (list) { out.push(`</${list}>`); list = null; } };
  for (const raw of lines) {
    const line = raw.trimEnd();
    const h = /^(#{1,6})\s+(.*)$/.exec(line);
    const ul = /^\s*[-*+]\s+(.*)$/.exec(line);
    const ol = /^\s*\d+[.)]\s+(.*)$/.exec(line);
    if (!line.trim()) { flushPara(); closeList(); continue; }
    if (h) {
      flushPara(); closeList();
      const level = h[1]!.length;
      out.push(`<h${level} dir="auto">${inlineMd(h[2]!)}</h${level}>`);
    } else if (/^\s*([-*_])\1{2,}\s*$/.test(line)) {
      flushPara(); closeList(); out.push(`<hr style="border:0;border-top:1px solid #cbd5e1;margin:12px 0;">`);
    } else if (ul || ol) {
      flushPara();
      const kind = ul ? "ul" : "ol";
      if (list !== kind) { closeList(); out.push(`<${kind} dir="auto" style="padding-inline-start:22px;line-height:1.9;">`); list = kind; }
      out.push(`<li>${inlineMd((ul ?? ol)![1]!)}</li>`);
    } else if (/^>\s?/.test(line)) {
      flushPara(); closeList();
      out.push(`<blockquote dir="auto" style="border-inline-start:3px solid #94a3b8;margin:8px 0;padding:2px 12px;color:#475569;">${inlineMd(line.replace(/^>\s?/, ""))}</blockquote>`);
    } else {
      closeList(); para.push(line.trim());
    }
  }
  flushPara(); closeList();
  return out.join("");
}

/* --------------------------------- html --------------------------------- */

const ALLOWED_TAGS = new Set(["P","BR","H1","H2","H3","H4","H5","H6","UL","OL","LI","TABLE","THEAD","TBODY","TR","TH","TD","STRONG","B","EM","I","U","S","SPAN","DIV","BLOCKQUOTE","HR","IMG","A","SUB","SUP","CODE","PRE"]);

/** Keeps formatting but drops scripts, event handlers and unknown tags. */
function htmlToSafeHtml(source: string): string {
  const doc = new DOMParser().parseFromString(source, "text/html");
  const clean = (node: Node): string => {
    if (node.nodeType === Node.TEXT_NODE) return esc(node.textContent ?? "");
    if (node.nodeType !== Node.ELEMENT_NODE) return "";
    const el = node as HTMLElement;
    const tag = el.tagName;
    const inner = Array.from(el.childNodes).map(clean).join("");
    if (!ALLOWED_TAGS.has(tag)) return /^(SCRIPT|STYLE|HEAD|META|LINK|IFRAME|OBJECT|EMBED|NOSCRIPT)$/.test(tag) ? "" : inner;
    const t = tag.toLowerCase();
    if (t === "br" || t === "hr") return `<${t}>`;
    if (t === "img") {
      const src = el.getAttribute("src") ?? "";
      return /^data:image\//i.test(src) ? `<img src="${src}" style="max-width:100%;">` : "";
    }
    const style = (el.getAttribute("style") ?? "").replace(/(expression|javascript:|url\()[^;]*;?/gi, "");
    const attrs = [style ? ` style="${style.replace(/"/g, "'")}"` : "", /^(td|th)$/.test(t) && el.getAttribute("colspan") ? ` colspan="${Number(el.getAttribute("colspan")) || 1}"` : ""].join("");
    return `<${t} dir="auto"${attrs}>${inner}</${t}>`;
  };
  return clean(doc.body);
}

/** Converts PDF bytes (already loaded) into an editable EVA document. */
export async function pdfBytesToDocument(bytes: Uint8Array, title: string): Promise<ImportedDocument> {
  const copy = bytes.slice().buffer as ArrayBuffer;
  const body = await pdfToHtml(copy);
  if (!body.replace(/<[^>]+>/g, "").trim()) throw new Error("لا يحتوي الملف على نص قابل للتحرير (قد يكون صورًا ممسوحة)");
  return { title: title || "مستند محوّل", html: `<div dir="rtl">${body}</div>` };
}

/* --------------------------------- pdf ---------------------------------- */

async function pdfToHtml(buffer: ArrayBuffer): Promise<string> {
  const { loadPdfjs } = await import("./pdfjs");
  const pdfjs = await loadPdfjs();
  const pdf = await pdfjs.getDocument({ data: new Uint8Array(buffer) }).promise;
  const pages: string[] = [];
  for (let n = 1; n <= pdf.numPages; n++) {
    const page = await pdf.getPage(n);
    const content = await page.getTextContent();
    type Item = { str: string; x: number; y: number; h: number };
    const items: Item[] = [];
    for (const it of content.items as { str?: string; transform?: number[]; height?: number }[]) {
      if (typeof it.str !== "string" || !it.transform) continue;
      items.push({ str: it.str, x: it.transform[4] ?? 0, y: it.transform[5] ?? 0, h: it.height || 10 });
    }
    // group into visual lines (top to bottom), then into paragraphs by vertical gap
    const lines: { y: number; h: number; parts: Item[] }[] = [];
    for (const it of items.filter((i) => i.str.trim())) {
      const line = lines.find((l) => Math.abs(l.y - it.y) < Math.max(2, it.h * 0.4));
      if (line) line.parts.push(it); else lines.push({ y: it.y, h: it.h, parts: [it] });
    }
    lines.sort((a, b) => b.y - a.y);
    const rtl = (items.map((i) => i.str).join("").match(/[֐-ࣿ]/g)?.length ?? 0) > items.length;
    let current: string[] = [];
    let prev: (typeof lines)[number] | null = null;
    const flush = () => { if (current.length) pages.push(P(esc(current.join(" ")))); current = []; };
    for (const line of lines) {
      if (prev && prev.y - line.y > Math.max(prev.h, line.h) * 1.8) flush();
      const parts = line.parts.sort((a, b) => (rtl ? b.x - a.x : a.x - b.x));
      current.push(parts.map((p) => p.str).join(" ").replace(/\s+/g, " ").trim());
      prev = line;
    }
    flush();
    if (n < pdf.numPages) pages.push(`<div style="page-break-after:always;"></div>`);
  }
  return pages.join("");
}

/* --------------------------------- docx --------------------------------- */

interface ZipEntry { method: number; compressed: number; offset: number }

/** Minimal ZIP reader (central directory + deflate-raw via the browser's DecompressionStream). */
async function readZip(buffer: ArrayBuffer): Promise<Map<string, () => Promise<Uint8Array>>> {
  const view = new DataView(buffer);
  const bytes = new Uint8Array(buffer);
  let eocd = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
    if (view.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error("الملف ليس مستند DOCX صالحًا");
  const count = view.getUint16(eocd + 10, true);
  let p = view.getUint32(eocd + 16, true);
  const entries = new Map<string, ZipEntry>();
  const td = new TextDecoder();
  for (let i = 0; i < count; i++) {
    if (view.getUint32(p, true) !== 0x02014b50) break;
    const method = view.getUint16(p + 10, true);
    const compressed = view.getUint32(p + 20, true);
    const nameLen = view.getUint16(p + 28, true);
    const extraLen = view.getUint16(p + 30, true);
    const commentLen = view.getUint16(p + 32, true);
    const offset = view.getUint32(p + 42, true);
    entries.set(td.decode(bytes.subarray(p + 46, p + 46 + nameLen)), { method, compressed, offset });
    p += 46 + nameLen + extraLen + commentLen;
  }
  const out = new Map<string, () => Promise<Uint8Array>>();
  for (const [name, e] of entries) {
    out.set(name, async () => {
      const nameLen = view.getUint16(e.offset + 26, true);
      const extraLen = view.getUint16(e.offset + 28, true);
      const start = e.offset + 30 + nameLen + extraLen;
      const raw = bytes.subarray(start, start + e.compressed);
      if (e.method === 0) return raw;
      if (e.method !== 8) throw new Error("طريقة ضغط غير مدعومة في الملف");
      const stream = new Blob([raw as BlobPart]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
      return new Uint8Array(await new Response(stream).arrayBuffer());
    });
  }
  return out;
}

const W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
const R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
const kids = (el: Element, local: string) => Array.from(el.children).filter((c) => c.localName === local);
const kid = (el: Element | null | undefined, local: string) => (el ? kids(el, local)[0] : undefined);
const wAttr = (el: Element | null | undefined, name: string) => el?.getAttributeNS(W_NS, name) ?? el?.getAttribute(`w:${name}`) ?? null;
const isOff = (el: Element | undefined) => !!el && ["0", "false", "off"].includes(wAttr(el, "val") ?? "");

const MIME: Record<string, string> = { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", bmp: "image/bmp", webp: "image/webp", svg: "image/svg+xml" };

async function docxToHtml(buffer: ArrayBuffer): Promise<string> {
  const zip = await readZip(buffer);
  const read = async (name: string) => { const f = zip.get(name); return f ? new TextDecoder().decode(await f()) : null; };
  const docXml = await read("word/document.xml");
  if (!docXml) throw new Error("الملف ليس مستند DOCX صالحًا");
  const parse = (xml: string) => new DOMParser().parseFromString(xml, "application/xml");
  const doc = parse(docXml);
  if (doc.getElementsByTagName("parsererror").length) throw new Error("تعذّر قراءة محتوى المستند");

  // relationships → images
  const rels = new Map<string, string>();
  const relsXml = await read("word/_rels/document.xml.rels");
  if (relsXml) for (const r of Array.from(parse(relsXml).getElementsByTagName("Relationship"))) rels.set(r.getAttribute("Id") ?? "", r.getAttribute("Target") ?? "");
  const imageCache = new Map<string, string>();
  const imageFor = async (rid: string): Promise<string> => {
    if (imageCache.has(rid)) return imageCache.get(rid)!;
    const target = rels.get(rid);
    let result = "";
    if (target && !/^https?:/i.test(target)) {
      const path = target.startsWith("/") ? target.slice(1) : `word/${target}`.replace(/word\/\.\.\//, "");
      const f = zip.get(path);
      const ext = (path.split(".").pop() ?? "").toLowerCase();
      if (f && MIME[ext]) {
        const data = await f();
        let bin = "";
        for (let i = 0; i < data.length; i += 0x8000) bin += String.fromCharCode(...data.subarray(i, i + 0x8000));
        result = `data:${MIME[ext]};base64,${btoa(bin)}`;
      }
    }
    imageCache.set(rid, result);
    return result;
  };

  // numbering → ordered or bullet
  const numKind = new Map<string, "ul" | "ol">();
  const numXml = await read("word/numbering.xml");
  if (numXml) {
    const nd = parse(numXml);
    const abstract = new Map<string, "ul" | "ol">();
    for (const a of Array.from(nd.getElementsByTagNameNS(W_NS, "abstractNum"))) {
      const fmt = wAttr(kid(kids(a, "lvl")[0], "numFmt"), "val");
      abstract.set(wAttr(a, "abstractNumId") ?? "", fmt === "bullet" ? "ul" : "ol");
    }
    for (const n of Array.from(nd.getElementsByTagNameNS(W_NS, "num"))) {
      numKind.set(wAttr(n, "numId") ?? "", abstract.get(wAttr(kid(n, "abstractNumId"), "val") ?? "") ?? "ul");
    }
  }

  // styles → heading detection by style name
  const styleName = new Map<string, string>();
  const styleNum = new Map<string, string>(); // list styles ("List Bullet") carry numbering on the style itself
  const stylesXml = await read("word/styles.xml");
  if (stylesXml) {
    for (const s of Array.from(parse(stylesXml).getElementsByTagNameNS(W_NS, "style"))) {
      const id = wAttr(s, "styleId") ?? "";
      styleName.set(id, (wAttr(kid(s, "name"), "val") ?? "").toLowerCase());
      const sn = wAttr(kid(kid(kid(s, "pPr"), "numPr"), "numId"), "val");
      if (sn) styleNum.set(id, sn);
    }
  }

  const runHtml = async (r: Element): Promise<string> => {
    const rPr = kid(r, "rPr");
    let text = "";
    for (const c of Array.from(r.children)) {
      if (c.localName === "t") text += esc(c.textContent ?? "");
      else if (c.localName === "tab") text += "&emsp;";
      else if (c.localName === "br" || c.localName === "cr") text += wAttr(c, "type") === "page" ? `</p><div style="page-break-after:always;"></div><p dir="auto">` : "<br>";
      else if (c.localName === "drawing" || c.localName === "pict") {
        const blip = c.getElementsByTagNameNS("*", "blip")[0];
        const rid = blip?.getAttributeNS(R_NS, "embed") ?? blip?.getAttribute("r:embed");
        const src = rid ? await imageFor(rid) : "";
        if (src) text += `<img src="${src}" style="max-width:100%;">`;
      }
    }
    if (!text) return "";
    const b = kid(rPr, "b"), i = kid(rPr, "i"), u = kid(rPr, "u"), s = kid(rPr, "strike");
    if (b && !isOff(b)) text = `<strong>${text}</strong>`;
    if (i && !isOff(i)) text = `<em>${text}</em>`;
    if (u && wAttr(u, "val") !== "none") text = `<u>${text}</u>`;
    if (s && !isOff(s)) text = `<s>${text}</s>`;
    const css: string[] = [];
    const color = wAttr(kid(rPr, "color"), "val");
    if (color && /^[0-9a-f]{6}$/i.test(color)) css.push(`color:#${color}`);
    const sz = Number(wAttr(kid(rPr, "sz"), "val"));
    if (sz) css.push(`font-size:${Math.round((sz / 2) * (96 / 72))}px`);
    const va = wAttr(kid(rPr, "vertAlign"), "val");
    if (va === "superscript") text = `<sup>${text}</sup>`;
    if (va === "subscript") text = `<sub>${text}</sub>`;
    return css.length ? `<span style="${css.join(";")}">${text}</span>` : text;
  };

  const inlineChildren = async (p: Element): Promise<string> => {
    let html = "";
    for (const c of Array.from(p.children)) {
      if (c.localName === "r") html += await runHtml(c);
      else if (c.localName === "hyperlink" || c.localName === "smartTag" || c.localName === "sdt" || c.localName === "ins") {
        const target = c.localName === "sdt" ? kid(c, "sdtContent") ?? c : c;
        html += await inlineChildren(target);
      }
    }
    return html;
  };

  let openList: "ul" | "ol" | null = null;
  const parts: string[] = [];
  const closeList = () => { if (openList) { parts.push(`</${openList}>`); openList = null; } };

  const paragraph = async (p: Element) => {
    const pPr = kid(p, "pPr");
    const inner = await inlineChildren(p);
    const numPr = kid(pPr, "numPr");
    const numId = wAttr(kid(numPr, "numId"), "val") ?? styleNum.get(wAttr(kid(pPr, "pStyle"), "val") ?? "") ?? null;
    if (numId && numId !== "0") {
      const kind = numKind.get(numId) ?? "ul";
      if (openList !== kind) { closeList(); parts.push(`<${kind} dir="auto" style="padding-inline-start:22px;line-height:1.9;">`); openList = kind; }
      parts.push(`<li>${inner || "<br>"}</li>`);
      return;
    }
    closeList();
    const jc = wAttr(kid(pPr, "jc"), "val");
    const align = jc === "center" ? "center" : jc === "both" || jc === "distribute" ? "justify" : "";
    const style = `line-height:1.9;margin:0 0 8px;${align ? `text-align:${align};` : ""}`;
    const sid = wAttr(kid(pPr, "pStyle"), "val") ?? "";
    const name = styleName.get(sid) ?? sid.toLowerCase();
    const hm = /heading\s*([1-6])|عنوان\s*([1-6])/.exec(name) ?? /^heading([1-6])$/.exec(sid.toLowerCase());
    if (hm) {
      const level = Number(hm[1] ?? hm[2]);
      parts.push(`<h${level} dir="auto" style="${align ? `text-align:${align};` : ""}">${inner || "<br>"}</h${level}>`);
    } else if (name === "title" || name === "العنوان") {
      parts.push(`<h1 dir="auto" style="text-align:center;">${inner || "<br>"}</h1>`);
    } else {
      parts.push(`<p dir="auto" style="${style}">${inner || "<br>"}</p>`);
    }
  };

  const table = async (tbl: Element) => {
    closeList();
    let html = `<table style="width:100%;border-collapse:collapse;margin:10px 0;">`;
    for (const tr of kids(tbl, "tr")) {
      html += "<tr>";
      for (const tc of kids(tr, "tc")) {
        const span = Number(wAttr(kid(kid(tc, "tcPr"), "gridSpan"), "val")) || 1;
        const saved = parts.splice(0, parts.length);
        const savedList = openList; openList = null;
        for (const c of Array.from(tc.children)) if (c.localName === "p") await paragraph(c);
        closeList();
        const cell = parts.splice(0, parts.length).join("");
        parts.push(...saved); openList = savedList;
        html += `<td${span > 1 ? ` colspan="${span}"` : ""} style="border:1px solid #94a3b8;padding:7px 9px;vertical-align:top;">${cell || "<br>"}</td>`;
      }
      html += "</tr>";
    }
    parts.push(html + "</table>");
  };

  const body = doc.getElementsByTagNameNS(W_NS, "body")[0] ?? doc.documentElement;
  for (const c of Array.from(body.children)) {
    if (c.localName === "p") await paragraph(c);
    else if (c.localName === "tbl") await table(c);
  }
  closeList();
  return parts.join("");
}
