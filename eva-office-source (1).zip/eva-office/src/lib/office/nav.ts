/**
 * Small navigation helpers with the same names the screens already use, backed
 * by TanStack Router.
 */

import { useCallback, useMemo } from "react";
import { useLocation, useParams as useRouterParams, useRouter } from "@tanstack/react-router";

export function splitHref(href: string): { pathname: string; search: Record<string, string> } {
  const [pathname, query = ""] = href.split("?");
  const search: Record<string, string> = {};
  new URLSearchParams(query).forEach((value, key) => {
    search[key] = value;
  });
  return { pathname, search };
}

export function useAppNavigate() {
  const router = useRouter();
  return useCallback(
    (href: string, options?: { replace?: boolean }) => {
      const { pathname, search } = splitHref(href);
      void router.navigate({
        to: pathname,
        search,
        replace: options?.replace,
        // Query strings are dynamic here (view filters, ids), so the typed
        // search params of the target route are not known ahead of time.
      } as never);
    },
    [router],
  );
}

/** Mirrors the previous `useRouter()` surface used across the screens. */
export function useAppRouter() {
  const navigate = useAppNavigate();
  const router = useRouter();
  return useMemo(
    () => ({
      push: (href: string) => navigate(href),
      replace: (href: string) => navigate(href, { replace: true }),
      back: () => router.history.back(),
      refresh: () => void router.invalidate(),
    }),
    [navigate, router],
  );
}

export function usePathname(): string {
  return useLocation({ select: (l) => l.pathname });
}

export function useAppSearchParams(): URLSearchParams {
  const searchStr = useLocation({ select: (l) => l.searchStr });
  return useMemo(() => new URLSearchParams(searchStr ?? ""), [searchStr]);
}

export { useAppRouter as useRouter, useAppSearchParams as useSearchParams };

/** Route params for the current route, mirroring the previous `useParams()`. */
export function useAppParams<T extends Record<string, string>>(): T {
  return useRouterParams({ strict: false } as never) as T;
}

export { useAppParams as useParams };
