"use client";

/**
 * Client-side pagination: flows arbitrary document HTML into fixed-size pages,
 * measuring in a hidden iframe that carries the exact print stylesheet.
 *
 * The resulting page chunks feed BOTH the on-screen preview and the PDF export,
 * so "what you preview" is literally "what you export".
 */

import { contentBoxMm, documentCss, MM_TO_PX } from "./render";
import type { PageSetup } from "./types";

interface Measurer {
  doc: Document;
  host: HTMLElement;
  cleanup: () => void;
  maxHeight: number;
}

async function createMeasurer(setup: PageSetup): Promise<Measurer> {
  const box = contentBoxMm(setup);
  const widthPx = box.width * MM_TO_PX;
  const maxHeight = box.height * MM_TO_PX;

  const iframe = document.createElement("iframe");
  iframe.setAttribute("aria-hidden", "true");
  iframe.style.cssText = `position:fixed;left:-99999px;top:0;width:${widthPx + 40}px;height:${Math.ceil(
    maxHeight
  ) * 3}px;border:0;visibility:hidden;`;
  document.body.appendChild(iframe);

  const doc = iframe.contentDocument;
  if (!doc) {
    iframe.remove();
    throw new Error("تعذّر قياس صفحات المستند");
  }
  doc.open();
  // #mc reproduces `.page-content` exactly (same width, fonts, first-child
  // margin rule) but without the fixed height, so we can see real overflow.
  doc.write(`<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<link href="${(typeof window!=="undefined"?window.location.origin:"")}/fonts/fonts.css" rel="stylesheet">
<style>${documentCss(setup, false)}
html,body{margin:0;padding:0;background:#fff;}
#mc{display:flow-root;position:relative;width:${widthPx}px;font-family:"IBM Plex Sans Arabic","Segoe UI",Tahoma,sans-serif;font-size:12pt;line-height:1.85;color:#111827;}
#mc > *:first-child{margin-top:0;}
</style></head><body><div id="mc"></div></body></html>`);
  doc.close();

  const host = doc.getElementById("mc") as HTMLElement;

  try {
    await Promise.race([
      (doc as any).fonts?.ready ?? Promise.resolve(),
      new Promise((resolve) => setTimeout(resolve, 1500)),
    ]);
  } catch (err) {
    console.error("[paginate] font wait failed, measuring anyway:", err);
  }

  return { doc, host, maxHeight, cleanup: () => iframe.remove() };
}

/** Bottom edge (px from page top) of `el` placed after what's already on the page. */
function bottomOf(m: Measurer, el: HTMLElement): number {
  const top = m.host.getBoundingClientRect().top;
  return el.getBoundingClientRect().bottom - top;
}

/** Would `node` still fit if appended to the current page? (real layout, incl. margins) */
function fits(m: Measurer, node: HTMLElement): boolean {
  const clone = node.cloneNode(true) as HTMLElement;
  m.host.appendChild(clone);
  const ok = bottomOf(m, clone) <= m.maxHeight + 0.5;
  m.host.removeChild(clone);
  return ok;
}

/** Height of a node measured alone on an empty page. */
function measureAlone(m: Measurer, node: HTMLElement): number {
  const saved = Array.from(m.host.childNodes);
  saved.forEach((n) => m.host.removeChild(n));
  const clone = node.cloneNode(true) as HTMLElement;
  m.host.appendChild(clone);
  const h = bottomOf(m, clone);
  m.host.removeChild(clone);
  saved.forEach((n) => m.host.appendChild(n));
  return h;
}

function lineHeightOf(m: Measurer, node: HTMLElement): number {
  const probe = node.cloneNode(false) as HTMLElement;
  probe.textContent = "نص";
  probe.style.margin = "0";
  const h = measureAlone(m, probe);
  return h > 0 ? h : 18;
}

function isPageBreak(node: HTMLElement): boolean {
  return node.classList?.contains("eva-pagebreak") === true;
}

function keepsWithNext(node: HTMLElement): boolean {
  return /^H[1-6]$/.test(node.tagName) || node.classList?.contains("eva-keep") === true;
}

function splitTable(
  m: Measurer,
  table: HTMLTableElement,
  minRows = 1
): [HTMLElement | null, HTMLElement | null] {
  const bodyRows = Array.from(table.querySelectorAll(":scope > tbody > tr, :scope > tr"));
  if (bodyRows.length <= 1) return [null, table];
  const head = table.querySelector(":scope > thead");
  const buildWith = (rows: Element[]) => {
    const t = table.cloneNode(false) as HTMLTableElement;
    if (head) t.appendChild(head.cloneNode(true));
    const tb = m.doc.createElement("tbody");
    rows.forEach((r) => tb.appendChild(r.cloneNode(true)));
    t.appendChild(tb);
    return t;
  };
  let lo = 1, hi = bodyRows.length, best = 0;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (fits(m, buildWith(bodyRows.slice(0, mid)))) { best = mid; lo = mid + 1; } else hi = mid - 1;
  }
  if (best < minRows) return [null, table];
  if (best >= bodyRows.length) return [table, null];
  return [buildWith(bodyRows.slice(0, best)), buildWith(bodyRows.slice(best))];
}

/** Word boundaries across all text nodes of `el` (keeps bold/colour/links intact). */
function wordBoundaries(el: HTMLElement): { node: Text; offset: number }[] {
  const out: { node: Text; offset: number }[] = [];
  const walker = el.ownerDocument.createTreeWalker(el, NodeFilter.SHOW_TEXT);
  let t: Node | null;
  while ((t = walker.nextNode())) {
    const text = (t as Text).data;
    const re = /\s+/g;
    let mm: RegExpExecArray | null;
    while ((mm = re.exec(text))) out.push({ node: t as Text, offset: mm.index + mm[0].length });
  }
  return out;
}

function splitInlineBlock(
  m: Measurer,
  el: HTMLElement,
  minLines = 0
): [HTMLElement | null, HTMLElement | null] {
  // Work on a live copy so Range offsets are valid inside the measuring doc.
  const live = el.cloneNode(true) as HTMLElement;
  m.host.appendChild(live);
  const cuts = wordBoundaries(live);
  const build = (fromStart: boolean, b: { node: Text; offset: number }) => {
    const r = m.doc.createRange();
    if (fromStart) { r.setStart(live, 0); r.setEnd(b.node, b.offset); }
    else { r.setStart(b.node, b.offset); r.setEnd(live, live.childNodes.length); }
    const shell = live.cloneNode(false) as HTMLElement;
    // The range source is hidden during binary search, not its measured copies.
    shell.style.removeProperty("display");
    shell.appendChild(r.cloneContents());
    return shell;
  };
  try {
    if (!cuts.length) return [null, el];
    m.host.removeChild(live);
    let lo = 0, hi = cuts.length - 1, best = -1;
    m.host.appendChild(live); // keep in doc for ranges; hide from layout
    live.style.display = "none";
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (fits(m, build(true, cuts[mid]))) { best = mid; lo = mid + 1; } else hi = mid - 1;
    }
    if (best < 0) return [null, el];
    let head = build(true, cuts[best]);
    let tail = build(false, cuts[best]);
    head.style.removeProperty("display");
    tail.style.removeProperty("display");
    if (!(tail.textContent ?? "").trim() && !tail.querySelector("img,svg,br")) return [el, null];
    if (minLines > 0) {
      const line = lineHeightOf(m, el);
      const minH = line * minLines - line * 0.25;
      if (measureAlone(m, head) < minH || measureAlone(m, tail) < minH) return [null, el];
    }
    // Continuation paragraph should not repeat the first-line indent.
    tail.style.textIndent = "0";
    return [head, tail];
  } finally {
    live.remove();
  }
}

/**
 * Flows `html` into page-sized chunks. Returns an array of inner-HTML strings,
 * one per printed page (always at least one).
 */
export async function paginateHtml(html: string, setup: PageSetup): Promise<string[]> {
  const m = await createMeasurer(setup);
  try {
    const source = m.doc.createElement("div");
    source.innerHTML = html && html.trim() ? html : "<p></p>";

    // Free-floating images/shapes are positioned absolutely over the text, so
    // they don't take part in the flow. Pull them out and drop each one onto
    // the page its top edge falls on.
    const floats = Array.from(source.querySelectorAll<HTMLElement>(".eva-float"));
    floats.forEach((f) => f.remove());

    const pages: string[] = [];
    let current: HTMLElement[] = [];

    const flush = () => {
      pages.push(current.map((n) => n.outerHTML).join(""));
      current = [];
      m.host.innerHTML = "";
    };
    const accept = (n: HTMLElement) => {
      current.push(n);
      m.host.appendChild(n.cloneNode(true));
    };

    const queue: HTMLElement[] = [];
    Array.from(source.childNodes).forEach((node) => {
      if (node.nodeType === Node.ELEMENT_NODE) queue.push(node as HTMLElement);
      else if (node.nodeType === Node.TEXT_NODE && node.textContent?.trim()) {
        const p = m.doc.createElement("p");
        p.textContent = node.textContent;
        queue.push(p);
      }
    });

    const smart = setup.smart_split !== false;
    const minLines = smart ? 2 : 0;

    let guard = 0;
    while (queue.length) {
      if (guard++ > 5000) {
        console.error("[paginate] guard tripped — emitting remaining content as-is");
        queue.forEach((n) => current.push(n));
        break;
      }
      const node = queue.shift();
      if (!node) break;

      if (isPageBreak(node)) {
        flush();
        continue;
      }

      const empty = current.length === 0;

      if (fits(m, node)) {
        if (smart && keepsWithNext(node) && !empty) {
          const next = queue[0];
          if (next && !isPageBreak(next)) {
            // Heading + first two lines of what follows must fit together.
            const probe = node.cloneNode(true) as HTMLElement;
            m.host.appendChild(probe);
            const nextFits = fits(m, next);
            let ok = nextFits;
            if (!nextFits) {
              const lh = lineHeightOf(m, next);
              ok = bottomOf(m, probe) + lh * 2 <= m.maxHeight;
            }
            m.host.removeChild(probe);
            if (!ok) { flush(); queue.unshift(node); continue; }
          }
        }
        accept(node);
        continue;
      }

      let head: HTMLElement | null = null;
      let tail: HTMLElement | null = null;
      const tag = node.tagName;

      if (tag === "TABLE") {
        [head, tail] = splitTable(m, node as HTMLTableElement, empty ? 1 : smart ? 2 : 1);
      } else if (/^(UL|OL|DIV|SECTION|BLOCKQUOTE|ARTICLE)$/.test(tag) && node.children.length > 1 && !node.classList.contains("eva-float")) {
        const kids = Array.from(node.children) as HTMLElement[];
        let lo = 1, hi = kids.length - 1, cut = 0;
        const withKids = (from: number, to: number) => {
          const c = node.cloneNode(false) as HTMLElement;
          kids.slice(from, to).forEach((k) => c.appendChild(k.cloneNode(true)));
          return c;
        };
        while (lo <= hi) {
          const mid = (lo + hi) >> 1;
          if (fits(m, withKids(0, mid))) { cut = mid; lo = mid + 1; } else hi = mid - 1;
        }
        if (cut > 0) {
          head = withKids(0, cut);
          tail = withKids(cut, kids.length);
          if (tag === "OL") tail.setAttribute("start", String((parseInt(node.getAttribute("start") || "1") || 1) + cut));
        }
      } else if (!node.querySelector("img, table, svg, iframe, canvas")) {
        [head, tail] = splitInlineBlock(m, node, empty ? 0 : minLines);
      }

      if (!head && !empty) {
        // Can't place any part here — move the whole block to a fresh page.
        flush();
        queue.unshift(node);
        continue;
      }

      if (!head) {
        // No progress is possible: emit once, never requeue the same tail.
        // Flushing an empty page here used to create thousands of blank pages.
        const height = measureAlone(m, node);
        if (height > m.maxHeight) {
          // Keep an indivisible layout complete rather than clipping its bottom.
          const wrapper = m.doc.createElement("div");
          const scale = m.maxHeight / height;
          wrapper.style.cssText = `height:${m.maxHeight}px;position:relative;overflow:hidden;`;
          node.style.transform = `scale(${scale})`;
          node.style.transformOrigin = "top right";
          node.style.width = `${contentBoxMm(setup).width * MM_TO_PX}px`;
          wrapper.appendChild(node);
          accept(wrapper);
        } else accept(node);
        flush();
        continue;
      }

      if (head) accept(head);
      flush();
      if (tail) queue.unshift(tail);
    }

    if (current.length || pages.length === 0) flush();
    floats.forEach((f) => {
      const top = parseFloat(f.style.top) || 0;
      const idx = Math.max(0, Math.floor(top / m.maxHeight));
      while (pages.length <= idx) pages.push("");
      f.style.top = `${top - idx * m.maxHeight}px`;
      pages[idx] += f.outerHTML;
    });
    console.log(`[paginate] produced ${pages.length} page(s)`);
    return pages;
  } finally {
    m.cleanup();
  }
}
