"use client";

/**
 * Client-side page rasteriser.
 *
 * The paginated chunks produced by `paginateHtml` are laid out off-screen with
 * exactly the same CSS the preview uses, rasterised page by page and packed
 * into a real PDF (or PNG images). Rendering in the browser keeps Arabic
 * shaping, fonts, tables, dividers, images and page geometry pixel-identical
 * to the preview.
 */

import { documentCss, contentBoxMm, MM_TO_PX, PAGE_FRAME_HTML } from "./render";
import { pageHeightMm, pageWidthMm, type PageSetup } from "./types";

const SCOPE = ".eva-export-scope";

function escapeText(value: unknown): string {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

/** Builds the off-screen host that carries the print CSS and one node per page. */
function buildHost(pages: string[], setup: PageSetup, title: string) {
  const box = contentBoxMm(setup);
  const total = Math.max(pages.length, 1);
  const widthPx = Math.round(pageWidthMm(setup) * MM_TO_PX);
  const heightPx = Math.round(pageHeightMm(setup) * MM_TO_PX);

  const host = document.createElement("div");
  host.className = "eva-export-scope";
  host.setAttribute("aria-hidden", "true");
  // Kept in the layout flow (visible to the rasteriser) but invisible to the
  // user: negative-offset/`display:none` hosts rasterise as blank pages.
  host.style.cssText = [
    "position:fixed",
    "top:0",
    "left:0",
    `width:${widthPx}px`,
    "z-index:-2147483647",
    "opacity:0",
    "background:#ffffff",
    "pointer-events:none",
    "overflow:hidden",
  ].join(";");
  host.dir = "rtl";

  const style = document.createElement("style");
  style.textContent = documentCss(setup, false, SCOPE);
  host.appendChild(style);

  const pageNodes: HTMLElement[] = [];
  (pages.length ? pages : [""]).forEach((inner, index) => {
    const page = document.createElement("div");
    page.className = "page";
    page.style.margin = "0";
    page.style.boxShadow = "none";
    page.style.borderRadius = "0";
    page.style.width = `${widthPx}px`;
    page.style.height = `${heightPx}px`;
    page.style.background = "#ffffff";
    page.innerHTML = `
      ${PAGE_FRAME_HTML}
      ${
        box.hasHeader
          ? `<div class="page-header"><span>${escapeText(setup.header)}</span><span>${escapeText(title)}</span></div>`
          : ""
      }
      <div class="page-content">${inner}</div>
      ${
        box.hasFooter
          ? `<div class="page-footer"><span>${escapeText(setup.footer)}</span><span>${
              setup.show_page_numbers ? `صفحة ${index + 1} من ${total}` : ""
            }</span></div>`
          : ""
      }`;
    host.appendChild(page);
    pageNodes.push(page);
  });

  document.body.appendChild(host);
  return { host, pageNodes, widthPx, heightPx };
}

/** Waits for the fonts and any <img> inside the host to be ready before rasterising. */
async function waitForAssets(host: HTMLElement) {
  const images = Array.from(host.querySelectorAll("img"));
  await Promise.all([
    (document as Document & { fonts?: FontFaceSet }).fonts?.ready ?? Promise.resolve(),
    ...images.map((img) =>
      img.complete
        ? Promise.resolve()
        : new Promise<void>((resolve) => {
            img.addEventListener("load", () => resolve(), { once: true });
            img.addEventListener("error", () => resolve(), { once: true });
          })
    ),
  ]);
  // Give the browser one more frame so layout + webfonts are fully applied.
  await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
}

/** Rasterises every page node into a canvas, in order. */
async function rasterise(
  pages: string[],
  setup: PageSetup,
  title: string,
  scale = typeof window !== "undefined" && window.innerWidth < 768 ? 1.5 : 2
): Promise<HTMLCanvasElement[]> {
  const html2canvas = (await import("html2canvas-pro")).default;
  const { host, pageNodes, widthPx } = buildHost(pages, setup, title);

  try {
    await waitForAssets(host);

    // Inline remote images so the canvas is not tainted (blocks toDataURL on phones).
    await Promise.all(
      Array.from(host.querySelectorAll("img")).map(async (img) => {
        const src = img.getAttribute("src") || "";
        if (!/^https?:/i.test(src) || src.startsWith(location.origin)) return;
        try {
          const b = await (await fetch(src, { mode: "cors" })).blob();
          img.src = await new Promise<string>((res, rej) => {
            const r = new FileReader();
            r.onload = () => res(String(r.result));
            r.onerror = () => rej(r.error);
            r.readAsDataURL(b);
          });
        } catch {
          img.remove();
        }
      })
    );
    await waitForAssets(host);
    const canvases: HTMLCanvasElement[] = [];
    for (const node of pageNodes) {
      const canvas = await html2canvas(node, {
        scale,
        backgroundColor: "#ffffff",
        useCORS: true,
        logging: false,
        windowWidth: widthPx,
        scrollX: 0,
        scrollY: 0,
      });
      if (!canvas.width || !canvas.height) {
        throw new Error("تعذّر رسم الصفحة");
      }
      canvases.push(canvas);
    }
    return canvases;
  } finally {
    host.remove();
  }
}

/** Renders paginated HTML into a real PDF Blob entirely in the browser. */
export async function renderPagesToPdfBlob(
  pages: string[],
  setup: PageSetup,
  title: string
): Promise<Blob> {
  const { jsPDF } = await import("jspdf");
  const widthMm = pageWidthMm(setup);
  const heightMm = pageHeightMm(setup);
  const orientation = setup.orientation === "landscape" ? "landscape" : "portrait";

  const canvases = await rasterise(pages, setup, title);

  const pdf = new jsPDF({ orientation, unit: "mm", format: [widthMm, heightMm], compress: true });

  canvases.forEach((canvas, i) => {
    const image = canvas.toDataURL("image/jpeg", 0.95);
    if (i > 0) pdf.addPage([widthMm, heightMm], orientation);
    pdf.addImage(image, "JPEG", 0, 0, widthMm, heightMm, undefined, "FAST");
  });

  console.log("[pdf-render] rendered", canvases.length, "page(s) in the browser");
  // `output("blob")` returns a correctly typed application/pdf blob — building
  // one by hand from raw bytes is what produced unopenable files before.
  return pdf.output("blob");
}

/** Renders each page as a PNG image. */
export async function renderPagesToPngBlobs(
  pages: string[],
  setup: PageSetup,
  title: string
): Promise<Blob[]> {
  const canvases = await rasterise(pages, setup, title);
  return Promise.all(
    canvases.map(
      (canvas) =>
        new Promise<Blob>((resolve, reject) => {
          canvas.toBlob(
            (blob) => (blob ? resolve(blob) : reject(new Error("تعذّر إنشاء الصورة"))),
            "image/png"
          );
        })
    )
  );
}
