"use client";

import workerUrl from "pdfjs-dist/build/pdf.worker.min.mjs?url";

/** Lazily loads pdf.js in the browser with the worker served from /public. */

let pdfjsPromise: Promise<typeof import("pdfjs-dist")> | null = null;

export function loadPdfjs() {
  if (!pdfjsPromise) {
    pdfjsPromise = import("pdfjs-dist").then((mod) => {
      mod.GlobalWorkerOptions.workerSrc = workerUrl;
      console.log("[pdfjs] loaded version", mod.version);
      return mod;
    });
  }
  return pdfjsPromise;
}

/** Local object URLs must stay in the browser; remote URLs can be read directly. */
export function pdfSourceUrl(url: string): string {
  return url;
}

export async function fetchPdfBytes(signedUrl: string): Promise<Uint8Array> {
  const res = await fetch(pdfSourceUrl(signedUrl));
  if (!res.ok) throw new Error(`تعذّر تحميل الملف (${res.status})`);
  return new Uint8Array(await res.arrayBuffer());
}
