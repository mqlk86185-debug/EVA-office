import { wrapPages } from "./render";
import type { PageSetup } from "./types";

/** Print only the physical document pages, not the editor or scaled dialog. */
export async function printPages(pages: string[], setup: PageSetup, title: string) {
  const frame = document.createElement("iframe");
  frame.setAttribute("aria-hidden", "true");
  frame.style.cssText = "position:fixed;left:-10000px;top:0;width:1200px;height:1600px;border:0;";
  document.body.appendChild(frame);
  const doc = frame.contentDocument;
  const win = frame.contentWindow;
  if (!doc || !win) { frame.remove(); throw new Error("الطباعة غير متاحة"); }
  try {
    doc.open();
    doc.write(wrapPages(pages, setup, title));
    doc.close();
    await Promise.race([doc.fonts.ready, new Promise(resolve => setTimeout(resolve, 4000))]);
    await Promise.all(Array.from(doc.images).map(img => img.complete ? Promise.resolve() : new Promise<void>(resolve => {
      img.addEventListener("load", () => resolve(), { once: true });
      img.addEventListener("error", () => resolve(), { once: true });
      setTimeout(resolve, 4000);
    })));
    win.addEventListener("afterprint", () => frame.remove(), { once: true });
    win.focus();
    win.print();
    setTimeout(() => frame.remove(), 120000);
  } catch (error) { frame.remove(); throw error; }
}