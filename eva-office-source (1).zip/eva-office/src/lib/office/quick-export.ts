"use client";

/**
 * تنزيل مباشر لملف PDF من محتوى المستند الحالي، بدون فتح نافذة المعاينة.
 * يستخدم نفس خطوات التقسيم والرسم المستخدمة في المعاينة حتى يكون الناتج مطابقًا.
 */

import { paginateHtml } from "./paginate";
import { exportPdf } from "./client";
import type { PageSetup } from "./types";

export async function downloadPdfNow(
  fileId: string,
  html: string,
  setup: PageSetup,
  title: string,
): Promise<number> {
  const pages = await paginateHtml(html, setup);
  const result = await exportPdf(fileId, pages.length ? pages : [html], setup, title);
  console.log("[quick-export] downloaded", result.pages, "page(s)");
  return result.pages;
}
