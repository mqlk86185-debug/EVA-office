/**
 * Isomorphic renderers shared by the on-screen preview and the PDF exporter.
 * Everything here must produce the SAME markup on client and server so the
 * exported PDF matches what the user saw in the preview.
 */

import {
  PageSetup,
  PageBorderStyle,
  ExamMeta,
  ExamQuestion,
  SheetContent,
  pageHeightMm,
  pageWidthMm,
} from "./types";
import { cellKey, colLabel, displayValue, rangeBounds, rangeMatrix } from "./sheet";

export const HEADER_MM = 12;
export const FOOTER_MM = 12;
export const MM_TO_PX = 96 / 25.4; // CSS px per millimetre at 96dpi

export function contentBoxMm(setup: PageSetup) {
  const hasHeader = Boolean(setup.header?.trim());
  const hasFooter = Boolean(setup.footer?.trim()) || setup.show_page_numbers;
  return {
    width: pageWidthMm(setup) - setup.margin * 2,
    height:
      pageHeightMm(setup) -
      setup.margin * 2 -
      (hasHeader ? HEADER_MM : 0) -
      (hasFooter ? FOOTER_MM : 0),
    hasHeader,
    hasFooter,
  };
}

function esc(value: unknown): string {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** Markup for the decorative page frame — identical in editor, preview and PDF. */
export const PAGE_FRAME_HTML =
  '<div class="page-frame" aria-hidden="true"><span></span><span></span><span></span><span></span></div>';

/**
 * CSS for the decorative page frame. `s` is an already-prefixed scope
 * (e.g. `".eva-print-scope "`). Only borders are used — no shadows or
 * gradients — so html2canvas rasterises the frame exactly as shown.
 */
export function pageFrameCss(setup: PageSetup, s = ""): string {
  const style: PageBorderStyle = setup.border_style ?? "none";
  if (style === "none") return `${s}.page-frame { display: none; }`;

  const color = setup.border_color || "#334155";
  const w = Math.max(1, Number(setup.border_width) || 2);
  const gap = Math.max(0, Number(setup.border_gap ?? 8));

  const shell = `${s}.page-frame { position: absolute; inset: ${gap}mm; pointer-events: none; z-index: 0; }
${s}.page-frame > span { display: none; }`;
  const line = (extra: string) => `${s}.page-frame { ${extra} }`;
  const innerLine = (insetMm: number, width: number, extra = "") =>
    `${s}.page-frame::before { content: ""; position: absolute; inset: ${insetMm}mm; border: ${width}px solid ${color}; ${extra} }`;

  switch (style) {
    case "solid":
      return `${shell}\n${line(`border: ${w}px solid ${color};`)}`;
    case "thick":
      return `${shell}\n${line(`border: ${w * 3}px solid ${color};`)}`;
    case "dashed":
      return `${shell}\n${line(`border: ${w}px dashed ${color};`)}`;
    case "dotted":
      return `${shell}\n${line(`border: ${Math.max(2, w)}px dotted ${color};`)}`;
    case "rounded":
      return `${shell}\n${line(`border: ${w}px solid ${color}; border-radius: 6mm;`)}`;
    case "double":
      return `${shell}\n${line(`border: ${w}px solid ${color};`)}\n${innerLine(1.4, w)}`;
    case "classic":
      return `${shell}\n${line(`border: ${w * 2.5}px solid ${color};`)}\n${innerLine(2.6, Math.max(1, Math.round(w / 2)))}`;
    case "shadow":
      return `${shell}\n${line(`border: ${w}px solid ${color};`)}\n${innerLine(
        0,
        w,
        `inset: 1.6mm -1.6mm -1.6mm 1.6mm; opacity: .4;`
      )}`;
    case "corners": {
      const cw = w * 2;
      const size = 16;
      const corner = (n: number, a: string, b: string, pos: string) =>
        `${s}.page-frame > span:nth-child(${n}) { display: block; position: absolute; width: ${size}mm; height: ${size}mm; ${pos} border-${a}: ${cw}px solid ${color}; border-${b}: ${cw}px solid ${color}; }`;
      return [
        shell,
        corner(1, "top", "right", "top: 0; right: 0;"),
        corner(2, "top", "left", "top: 0; left: 0;"),
        corner(3, "bottom", "right", "bottom: 0; right: 0;"),
        corner(4, "bottom", "left", "bottom: 0; left: 0;"),
      ].join("\n");
    }
    default:
      return shell;
  }
}

/**
 * CSS used both by the on-screen preview and the exported PDF.
 * Pass a `scope` selector to keep the rules from leaking into the app shell.
 */
export function documentCss(setup: PageSetup, forPrint: boolean, scope = ""): string {
  const w = pageWidthMm(setup);
  const h = pageHeightMm(setup);
  const box = contentBoxMm(setup);
  const s = scope ? `${scope} ` : "";
  return `
${forPrint ? `@page { size: ${w}mm ${h}mm; margin: 0; }` : ""}
${s}* { box-sizing: border-box; }
${scope ? `${scope}` : "body"} { margin: 0; background: ${forPrint ? "#fff" : "transparent"}; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
${s}.page {
  width: ${w}mm; height: ${h}mm; padding: ${setup.margin}mm;
  background: ${setup.page_color || "#fff"}; color: #111827; position: relative; overflow: visible;
  display: flex; flex-direction: column;
  font-family: "IBM Plex Sans Arabic", "Segoe UI", Tahoma, sans-serif;
  font-size: 12pt; line-height: 1.85;
  ${forPrint ? "page-break-after: always; break-after: page;" : "margin: 0 auto 18px; box-shadow: 0 1px 2px rgba(16,18,35,.10), 0 18px 45px -22px rgba(16,18,35,.45); border-radius: 2px;"}
}
${forPrint ? `${s}.page:last-child { page-break-after: auto; break-after: auto; }` : ""}
${s}.page-header, ${s}.page-footer { position: relative; z-index: 1; }
${s}.page-header { height: ${HEADER_MM}mm; flex: 0 0 ${HEADER_MM}mm; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #cbd5e1; font-size: 9.5pt; color: #475569; }
${s}.page-footer { height: ${FOOTER_MM}mm; flex: 0 0 ${FOOTER_MM}mm; display: flex; align-items: center; justify-content: space-between; border-top: 1px solid #cbd5e1; font-size: 9.5pt; color: #475569; }
${s}.page-content { flex: 1 1 auto; height: ${box.height}mm; overflow: visible; position: relative; z-index: 1; }
${s}.page-content > *:first-child { margin-top: 0; }
${s}h1 { font-size: 1.9em; font-weight: 800; margin: .55em 0 .35em; }
${s}h2 { font-size: 1.5em; font-weight: 700; margin: .55em 0 .3em; }
${s}h3 { font-size: 1.2em; font-weight: 700; margin: .5em 0 .3em; }
${s}p { margin: 0 0 .55em; }
${s}ul { list-style: disc; padding-inline-start: 1.6em; margin: .4em 0 .7em; }
${s}ol { list-style: decimal; padding-inline-start: 1.6em; margin: .4em 0 .7em; }
${s}li { margin: .18em 0; }
${s}hr { border: none; border-top: 2px solid #111827; margin: 1.1em 0; }
${s}table { border-collapse: collapse; width: 100%; margin: .7em 0; }
${s}td, ${s}th { border: 1px solid #94a3b8; padding: 6px 8px; }
${s}th { background: #f1f5f9; font-weight: 700; }
${s}img { max-width: 100%; height: auto; }
${s}svg { max-width: 100%; }
${s}.eva-textbox { border: 1.5px solid #64748b; border-radius: 8px; padding: 10px 12px; margin: .6em 0; background: #f8fafc; }
${s}.eva-frame { display: block; }
${s}.eva-float { position: absolute; z-index: 3; }
${s}.eva-shape-text { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; text-align: center; padding: 8%; overflow: hidden; line-height: 1.3; font-weight: 600; }
${s}.eva-float > img, ${s}.eva-float > svg { width: 100%; height: 100%; display: block; max-width: none; object-fit: fill; border-radius: 0; }
${s}.eva-pagebreak { display: none; }
${s}.eva-search-hit { background: transparent !important; color: inherit !important; }
${pageFrameCss(setup, s)}
`;
}

/** Wraps already-paginated HTML chunks into a full printable document. */
export function wrapPages(pages: string[], setup: PageSetup, title: string): string {
  const box = contentBoxMm(setup);
  const total = Math.max(pages.length, 1);
  const body = (pages.length ? pages : [""])
    .map((inner, i) => {
      const header = box.hasHeader
        ? `<div class="page-header"><span>${esc(setup.header)}</span><span>${esc(title)}</span></div>`
        : "";
      const footer = box.hasFooter
        ? `<div class="page-footer"><span>${esc(setup.footer ?? "")}</span><span>${
            setup.show_page_numbers ? `صفحة ${i + 1} من ${total}` : ""
          }</span></div>`
        : "";
      return `<div class="page">${PAGE_FRAME_HTML}${header}<div class="page-content">${inner}</div>${footer}</div>`;
    })
    .join("\n");

  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8" />
<title>${esc(title)}</title>
<link href="${(typeof window!=="undefined"?window.location.origin:"")}/fonts/fonts.css" rel="stylesheet" />
<style>${documentCss(setup, true)}</style>
</head>
<body>
${body}
</body>
</html>`;
}

/* ------------------------------------------------------------------ */
/* EVA exam                                                            */
/* ------------------------------------------------------------------ */

const CHOICE_LETTERS = ["A", "B", "C", "D", "E", "F"];

function examHeaderHtml(meta: ExamMeta): string {
  const rows: [string, string][] = [
    ["المدرسة / المؤسسة", meta.school],
    ["المادة", meta.subject],
    ["الصف / المرحلة", meta.grade],
    ["الشعبة", meta.class_section],
    ["اسم الطالب", meta.student_name],
    ["التاريخ", meta.exam_date],
    ["مدة الاختبار", meta.duration],
    ["الدرجة النهائية", meta.total_marks],
  ].filter(([, v]) => String(v ?? "").trim() !== "") as [string, string][];

  const title = meta.exam_title?.trim();
  const info = rows.length
    ? `<table style="margin:0 0 14px;font-size:.92em"><tbody>${chunk(rows, 2)
        .map(
          (pair) =>
            `<tr>${pair
              .map(
                ([k, v]) =>
                  `<td style="background:#f8fafc;font-weight:700;width:22%">${esc(k)}</td><td>${esc(v)}</td>`
              )
              .join("")}${pair.length === 1 ? '<td style="border:none"></td><td style="border:none"></td>' : ""}</tr>`
        )
        .join("")}</tbody></table>`
    : "";

  const instructions = meta.instructions?.trim()
    ? `<div class="eva-textbox" style="font-size:.92em"><strong>تعليمات:</strong> ${esc(
        meta.instructions
      )}</div>`
    : "";

  return `${
    title
      ? `<h1 style="text-align:center;margin:0 0 .5em;font-size:1.7em">${esc(title)}</h1>`
      : ""
  }${info}${instructions}`;
}

function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

function answerLines(count: number): string {
  const n = Math.max(0, count || 0);
  return Array.from({ length: n })
    .map(
      () =>
        `<div style="border-bottom:1px dotted #64748b;height:9mm;margin:0 0 2mm"></div>`
    )
    .join("");
}

export function questionHtml(q: ExamQuestion, number: number): string {
  const marks =
    q.marks != null && q.marks > 0
      ? `<span style="float:left;font-weight:700;color:#334155;font-size:.85em">( ${q.marks} درجة )</span>`
      : "";
  let bodyHtml = "";

  if (q.question_type === "multiple_choice") {
    let choices: string[] = [];
    try {
      choices = q.choices ? (JSON.parse(q.choices) as string[]) : [];
    } catch {
      choices = [];
    }
    bodyHtml = `<div style="margin:4px 0 0">${choices
      .map(
        (choice, i) =>
          `<div style="display:flex;gap:8px;align-items:center;margin:3px 0 3px 0;padding-inline-start:14px">
             <span style="display:inline-block;width:14px;height:14px;border:1.4px solid #334155;border-radius:3px;flex:0 0 auto"></span>
             <span style="font-weight:700">${CHOICE_LETTERS[i] ?? i + 1}.</span>
             <span>${esc(choice)}</span>
           </div>`
      )
      .join("")}</div>`;
  } else if (q.question_type === "true_false") {
    bodyHtml = `<div style="display:flex;gap:26px;margin:6px 0 0;padding-inline-start:14px">
      <span style="display:flex;gap:7px;align-items:center"><span style="display:inline-block;width:14px;height:14px;border:1.4px solid #334155;border-radius:3px"></span> صح</span>
      <span style="display:flex;gap:7px;align-items:center"><span style="display:inline-block;width:14px;height:14px;border:1.4px solid #334155;border-radius:3px"></span> خطأ</span>
    </div>`;
  } else {
    bodyHtml = `<div style="margin:6px 0 0">${answerLines(
      q.answer_lines ?? (q.question_type === "essay" ? 6 : q.question_type === "short_answer" ? 3 : 1)
    )}</div>`;
  }

  return `<div class="exam-question" style="margin:0 0 12px;page-break-inside:avoid">
    <div style="font-weight:600">${marks}<span style="font-weight:800">${number}.</span> ${esc(
    q.question_text
  )}</div>
    ${bodyHtml}
  </div>`;
}

/** Full inner HTML of an exam (header block + numbered questions grouped by section). */
export function examInnerHtml(meta: ExamMeta, questions: ExamQuestion[]): string {
  const ordered = [...questions].sort((a, b) => (a.order_index ?? 0) - (b.order_index ?? 0));
  const parts: string[] = [examHeaderHtml(meta)];

  let currentSection: string | null = null;
  let counter = 0;
  let sectionIndex = 0;
  for (const q of ordered) {
    const section = (q.section_title ?? "").trim();
    if (section && section !== currentSection) {
      currentSection = section;
      sectionIndex += 1;
      parts.push(
        `<h2 style="margin:14px 0 8px;padding:6px 10px;background:#eef2ff;border-inline-start:4px solid #4f46e5;border-radius:6px;font-size:1.12em">القسم ${sectionIndex}: ${esc(
          section
        )}</h2>`
      );
    }
    counter += 1;
    parts.push(questionHtml(q, counter));
  }

  const total = ordered.reduce((sum, q) => sum + (q.marks ?? 0), 0);
  if (total > 0) {
    parts.push(
      `<div style="margin-top:16px;padding-top:8px;border-top:2px solid #111827;text-align:left;font-weight:800">مجموع الدرجات: ${total}</div>`
    );
  }
  if (!ordered.length) {
    parts.push(
      `<p style="color:#64748b;text-align:center;margin-top:28px">لا توجد أسئلة بعد — أضف أول سؤال للاختبار.</p>`
    );
  }
  return parts.join("\n");
}

/* ------------------------------------------------------------------ */
/* GILOX sheet                                                         */
/* ------------------------------------------------------------------ */

function styleAttr(sheet: SheetContent, key: string): string {
  const s = sheet.cells[key]?.s;
  if (!s) return "";
  const css: string[] = [];
  if (s.b) css.push("font-weight:700");
  if (s.i) css.push("font-style:italic");
  if (s.u) css.push("text-decoration:underline");
  if (s.fs) css.push(`font-size:${s.fs}px`);
  if (s.ff) css.push(`font-family:'${s.ff}',sans-serif`);
  if (s.c) css.push(`color:${s.c}`);
  if (s.bg) css.push(`background:${s.bg}`);
  if (s.a) css.push(`text-align:${s.a}`);
  css.push(s.w ? "white-space:normal" : "white-space:nowrap");
  return css.length ? ` style="${css.join(";")}"` : "";
}

/**
 * Renders a spreadsheet range as an HTML table.
 * `showGrid` draws the borders, `showHeaders` adds the A/B/C + 1/2/3 guides.
 */
export function sheetInnerHtml(
  sheet: SheetContent,
  range: string,
  opts: { showHeaders: boolean; title?: string } = { showHeaders: true }
): string {
  const b = rangeBounds(range) ?? { r1: 0, c1: 0, r2: sheet.rows - 1, c2: sheet.cols - 1 };
  const merged = new Map<string, { rs: number; cs: number }>();
  const covered = new Set<string>();
  for (const m of sheet.merges ?? []) {
    const mb = rangeBounds(m);
    if (!mb) continue;
    merged.set(cellKey(mb.r1, mb.c1), { rs: mb.r2 - mb.r1 + 1, cs: mb.c2 - mb.c1 + 1 });
    for (let r = mb.r1; r <= mb.r2; r++)
      for (let c = mb.c1; c <= mb.c2; c++) {
        if (!(r === mb.r1 && c === mb.c1)) covered.add(cellKey(r, c));
      }
  }

  const head = opts.showHeaders
    ? `<thead><tr><th style="background:#e2e8f0;width:34px"></th>${Array.from({
        length: b.c2 - b.c1 + 1,
      })
        .map(
          (_, i) =>
            `<th style="background:#e2e8f0;font-size:.8em">${colLabel(b.c1 + i)}</th>`
        )
        .join("")}</tr></thead>`
    : "";

  const rows: string[] = [];
  for (let r = b.r1; r <= b.r2; r++) {
    const tds: string[] = [];
    if (opts.showHeaders)
      tds.push(`<td style="background:#e2e8f0;text-align:center;font-size:.8em">${r + 1}</td>`);
    for (let c = b.c1; c <= b.c2; c++) {
      const key = cellKey(r, c);
      if (covered.has(key)) continue;
      const span = merged.get(key);
      const spanAttr = span
        ? `${span.rs > 1 ? ` rowspan="${span.rs}"` : ""}${span.cs > 1 ? ` colspan="${span.cs}"` : ""}`
        : "";
      tds.push(`<td${spanAttr}${styleAttr(sheet, key)}>${esc(displayValue(sheet.cells, key))}</td>`);
    }
    rows.push(`<tr>${tds.join("")}</tr>`);
  }

  const title = opts.title
    ? `<h1 style="text-align:center;font-size:1.5em;margin:0 0 .6em">${esc(opts.title)}</h1>`
    : "";

  return `${title}<table style="font-size:10pt">${head}<tbody>${rows.join("")}</tbody></table>`;
}

/** Inline SVG chart, identical on screen and in the exported PDF. */
export function chartSvg(
  sheet: SheetContent,
  chart: { kind: string; title: string; range: string; height: number },
  width = 640
): string {
  const { labels, series } = rangeMatrix(sheet, chart.range);
  const height = chart.height || 260;
  const palette = ["#4f46e5", "#10b981", "#ef4444", "#f59e0b", "#0ea5e9", "#a855f7"];
  const pad = { top: 34, right: 16, bottom: 34, left: 46 };
  const iw = width - pad.left - pad.right;
  const ih = height - pad.top - pad.bottom;

  if (!labels.length || !series.length) {
    return `<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg"><text x="${
      width / 2
    }" y="${height / 2}" text-anchor="middle" font-size="13" fill="#94a3b8">لا توجد بيانات في النطاق</text></svg>`;
  }

  const titleEl = `<text x="${width / 2}" y="20" text-anchor="middle" font-size="14" font-weight="700" fill="#0f172a">${esc(
    chart.title
  )}</text>`;

  if (chart.kind === "pie") {
    const values = series[0].values;
    const total = values.reduce((a, v) => a + Math.abs(v), 0) || 1;
    const cx = width / 2 - 60;
    const cy = pad.top + ih / 2;
    const rad = Math.min(ih, iw) / 2 - 6;
    let angle = -Math.PI / 2;
    const slices = values
      .map((v, i) => {
        const sweep = (Math.abs(v) / total) * Math.PI * 2;
        const x1 = cx + rad * Math.cos(angle);
        const y1 = cy + rad * Math.sin(angle);
        angle += sweep;
        const x2 = cx + rad * Math.cos(angle);
        const y2 = cy + rad * Math.sin(angle);
        const large = sweep > Math.PI ? 1 : 0;
        return `<path d="M ${cx} ${cy} L ${x1.toFixed(2)} ${y1.toFixed(2)} A ${rad} ${rad} 0 ${large} 1 ${x2.toFixed(
          2
        )} ${y2.toFixed(2)} Z" fill="${palette[i % palette.length]}" stroke="#fff" stroke-width="1.5"/>`;
      })
      .join("");
    const legend = labels
      .map(
        (l, i) =>
          `<g transform="translate(${width - 140}, ${pad.top + 6 + i * 20})"><rect width="12" height="12" rx="3" fill="${
            palette[i % palette.length]
          }"/><text x="18" y="10" font-size="11" fill="#334155">${esc(l)}</text></g>`
      )
      .join("");
    return `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">${titleEl}${slices}${legend}</svg>`;
  }

  const allValues = series.flatMap((s) => s.values);
  const maxV = Math.max(0, ...allValues);
  const minV = Math.min(0, ...allValues);
  const span = maxV - minV || 1;
  const y = (v: number) => pad.top + ih - ((v - minV) / span) * ih;
  const stepX = iw / labels.length;

  const gridLines = Array.from({ length: 5 })
    .map((_, i) => {
      const val = minV + (span / 4) * i;
      const yy = y(val);
      return `<line x1="${pad.left}" y1="${yy.toFixed(1)}" x2="${pad.left + iw}" y2="${yy.toFixed(
        1
      )}" stroke="#e2e8f0" stroke-width="1"/><text x="${pad.left - 6}" y="${(yy + 3).toFixed(
        1
      )}" text-anchor="end" font-size="10" fill="#94a3b8">${Math.round(val)}</text>`;
    })
    .join("");

  const xLabels = labels
    .map(
      (l, i) =>
        `<text x="${(pad.left + stepX * (i + 0.5)).toFixed(1)}" y="${
          pad.top + ih + 16
        }" text-anchor="middle" font-size="10" fill="#64748b">${esc(l)}</text>`
    )
    .join("");

  let marks = "";
  if (chart.kind === "line") {
    marks = series
      .map((s, si) => {
        const pts = s.values
          .map((v, i) => `${(pad.left + stepX * (i + 0.5)).toFixed(1)},${y(v).toFixed(1)}`)
          .join(" ");
        const dots = s.values
          .map(
            (v, i) =>
              `<circle cx="${(pad.left + stepX * (i + 0.5)).toFixed(1)}" cy="${y(v).toFixed(
                1
              )}" r="3" fill="${palette[si % palette.length]}"/>`
          )
          .join("");
        return `<polyline points="${pts}" fill="none" stroke="${
          palette[si % palette.length]
        }" stroke-width="2.4" stroke-linejoin="round"/>${dots}`;
      })
      .join("");
  } else {
    const groupW = stepX * 0.72;
    const barW = groupW / series.length;
    marks = series
      .map((s, si) =>
        s.values
          .map((v, i) => {
            const x = pad.left + stepX * (i + 0.5) - groupW / 2 + barW * si;
            const yy = Math.min(y(v), y(0));
            const h = Math.abs(y(v) - y(0));
            return `<rect x="${x.toFixed(1)}" y="${yy.toFixed(1)}" width="${(barW - 2).toFixed(
              1
            )}" height="${Math.max(h, 1).toFixed(1)}" rx="2" fill="${palette[si % palette.length]}"/>`;
          })
          .join("")
      )
      .join("");
  }

  const legend = series
    .map(
      (s, i) =>
        `<g transform="translate(${pad.left + i * 110}, ${height - 10})"><rect width="10" height="10" rx="2" fill="${
          palette[i % palette.length]
        }"/><text x="15" y="9" font-size="10.5" fill="#334155">${esc(s.name)}</text></g>`
    )
    .join("");

  return `<svg width="${width}" height="${height + 14}" viewBox="0 0 ${width} ${
    height + 14
  }" xmlns="http://www.w3.org/2000/svg">${titleEl}${gridLines}${marks}${xLabels}${legend}</svg>`;
}
