/**
 * GILOX spreadsheet engine: cell addressing, formula evaluation and value formatting.
 * Pure and isomorphic — used by the client grid and by the server-side PDF exporter.
 */

import type { Cell, CellStyle, SheetContent } from "./types";

export function colLabel(index: number): string {
  let n = index;
  let out = "";
  while (n >= 0) {
    out = String.fromCharCode(65 + (n % 26)) + out;
    n = Math.floor(n / 26) - 1;
  }
  return out;
}

export function colIndex(label: string): number {
  let n = 0;
  for (const ch of label.toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

export function cellKey(row: number, col: number): string {
  return `${colLabel(col)}${row + 1}`;
}

export function parseKey(key: string): { row: number; col: number } | null {
  const m = /^([A-Za-z]+)(\d+)$/.exec(key.trim());
  if (!m) return null;
  return { col: colIndex(m[1]), row: parseInt(m[2], 10) - 1 };
}

export function expandRange(range: string): string[] {
  const [a, b] = range.split(":");
  const start = parseKey(a);
  const end = parseKey(b ?? a);
  if (!start || !end) return [];
  const keys: string[] = [];
  for (let r = Math.min(start.row, end.row); r <= Math.max(start.row, end.row); r++) {
    for (let c = Math.min(start.col, end.col); c <= Math.max(start.col, end.col); c++) {
      keys.push(cellKey(r, c));
    }
  }
  return keys;
}

export function rangeBounds(range: string) {
  const [a, b] = range.split(":");
  const start = parseKey(a);
  const end = parseKey(b ?? a);
  if (!start || !end) return null;
  return {
    r1: Math.min(start.row, end.row),
    r2: Math.max(start.row, end.row),
    c1: Math.min(start.col, end.col),
    c2: Math.max(start.col, end.col),
  };
}

const FUNCTIONS: Record<string, (values: number[]) => number> = {
  SUM: (v) => v.reduce((a, b) => a + b, 0),
  AVERAGE: (v) => (v.length ? v.reduce((a, b) => a + b, 0) / v.length : 0),
  MIN: (v) => (v.length ? Math.min(...v) : 0),
  MAX: (v) => (v.length ? Math.max(...v) : 0),
  COUNT: (v) => v.length,
  PRODUCT: (v) => v.reduce((a, b) => a * b, 1),
  ABS: (v) => Math.abs(v[0] ?? 0),
  ROUND: (v) => {
    const d = v[1] ?? 0;
    const p = Math.pow(10, d);
    return Math.round((v[0] ?? 0) * p) / p;
  },
};

export const SUPPORTED_FUNCTIONS = Object.keys(FUNCTIONS);

type Ctx = { cells: Record<string, Cell>; visiting: Set<string> };

/** Numeric value of a single cell (recursively resolving formulas). */
function cellNumber(key: string, ctx: Ctx): number {
  const res = evaluateCell(key, ctx);
  if (typeof res === "number") return res;
  const n = Number(String(res).replace(/[^\d.\-]/g, ""));
  return Number.isFinite(n) ? n : 0;
}

/* ---- tokenizer + recursive descent parser for formulas ---- */

type Token = { t: "num" | "op" | "id" | "paren" | "comma" | "range" | "ref"; v: string };

function tokenize(src: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  while (i < src.length) {
    const ch = src[i];
    if (/\s/.test(ch)) {
      i++;
      continue;
    }
    if (/[0-9.]/.test(ch)) {
      let j = i;
      while (j < src.length && /[0-9.]/.test(src[j])) j++;
      tokens.push({ t: "num", v: src.slice(i, j) });
      i = j;
      continue;
    }
    if (/[A-Za-z_]/.test(ch)) {
      let j = i;
      while (j < src.length && /[A-Za-z0-9_]/.test(src[j])) j++;
      let word = src.slice(i, j);
      // range like A1:B5
      if (src[j] === ":" && /^[A-Za-z]+\d+$/.test(word)) {
        let k = j + 1;
        while (k < src.length && /[A-Za-z0-9]/.test(src[k])) k++;
        const second = src.slice(j + 1, k);
        if (/^[A-Za-z]+\d+$/.test(second)) {
          tokens.push({ t: "range", v: `${word}:${second}` });
          i = k;
          continue;
        }
      }
      if (/^[A-Za-z]+\d+$/.test(word)) tokens.push({ t: "ref", v: word });
      else tokens.push({ t: "id", v: word.toUpperCase() });
      i = j;
      continue;
    }
    if (ch === "(" || ch === ")") {
      tokens.push({ t: "paren", v: ch });
      i++;
      continue;
    }
    if (ch === "," || ch === ";") {
      tokens.push({ t: "comma", v: "," });
      i++;
      continue;
    }
    if ("+-*/^%".includes(ch)) {
      tokens.push({ t: "op", v: ch });
      i++;
      continue;
    }
    i++; // skip unknown characters
  }
  return tokens;
}

function parseFormula(tokens: Token[], ctx: Ctx): number {
  let pos = 0;

  const peek = () => tokens[pos];

  function parseExpression(): number {
    let left = parseTerm();
    while (peek() && peek().t === "op" && (peek().v === "+" || peek().v === "-")) {
      const op = tokens[pos++].v;
      const right = parseTerm();
      left = op === "+" ? left + right : left - right;
    }
    return left;
  }

  function parseTerm(): number {
    let left = parsePower();
    while (peek() && peek().t === "op" && (peek().v === "*" || peek().v === "/")) {
      const op = tokens[pos++].v;
      const right = parsePower();
      if (op === "*") left = left * right;
      else left = right === 0 ? 0 : left / right;
    }
    return left;
  }

  function parsePower(): number {
    const base = parseUnary();
    if (peek() && peek().t === "op" && peek().v === "^") {
      pos++;
      return Math.pow(base, parsePower());
    }
    return base;
  }

  function parseUnary(): number {
    if (peek() && peek().t === "op" && (peek().v === "-" || peek().v === "+")) {
      const op = tokens[pos++].v;
      const val = parseUnary();
      return op === "-" ? -val : val;
    }
    return parseAtom();
  }

  /** Values of an argument, flattened (ranges expand to many numbers). */
  function parseArgValues(): number[] {
    if (peek() && peek().t === "range") {
      const range = tokens[pos++].v;
      return expandRange(range).map((k) => cellNumber(k, ctx));
    }
    return [parseExpression()];
  }

  function parseAtom(): number {
    const tk = peek();
    if (!tk) return 0;
    if (tk.t === "num") {
      pos++;
      return parseFloat(tk.v) || 0;
    }
    if (tk.t === "ref") {
      pos++;
      return cellNumber(tk.v, ctx);
    }
    if (tk.t === "range") {
      pos++;
      const values = expandRange(tk.v).map((k) => cellNumber(k, ctx));
      return values.reduce((a, b) => a + b, 0);
    }
    if (tk.t === "id") {
      const name = tk.v;
      pos++;
      const args: number[] = [];
      if (peek() && peek().t === "paren" && peek().v === "(") {
        pos++;
        while (peek() && !(peek().t === "paren" && peek().v === ")")) {
          args.push(...parseArgValues());
          if (peek() && peek().t === "comma") pos++;
          else break;
        }
        if (peek() && peek().t === "paren") pos++; // closing )
      }
      const fn = FUNCTIONS[name];
      if (!fn) throw new Error(`دالة غير مدعومة: ${name}`);
      return fn(args);
    }
    if (tk.t === "paren" && tk.v === "(") {
      pos++;
      const val = parseExpression();
      if (peek() && peek().t === "paren") pos++;
      return val;
    }
    pos++;
    return 0;
  }

  return parseExpression();
}

/** Evaluated value of a cell: number, string, or "#ERROR" / "#REF". */
export function evaluateCell(key: string, ctx: Ctx): number | string {
  const raw = ctx.cells[key]?.v;
  if (raw == null || raw === "") return "";
  if (!raw.startsWith("=")) {
    const n = Number(raw);
    return raw.trim() !== "" && Number.isFinite(n) ? n : raw;
  }
  if (ctx.visiting.has(key)) return "#REF";
  ctx.visiting.add(key);
  try {
    const tokens = tokenize(raw.slice(1));
    const value = parseFormula(tokens, ctx);
    return Number.isFinite(value) ? value : "#ERROR";
  } catch (err) {
    console.error(`[GILOX] formula error in ${key}:`, err);
    return "#ERROR";
  } finally {
    ctx.visiting.delete(key);
  }
}

export function makeCtx(cells: Record<string, Cell>): Ctx {
  return { cells, visiting: new Set() };
}

export function computedValue(cells: Record<string, Cell>, key: string): number | string {
  return evaluateCell(key, makeCtx(cells));
}

const CURRENCY = "ر.س";

export function formatCellValue(value: number | string, style?: CellStyle): string {
  if (value === "" || value == null) return "";
  const fmt = style?.fmt ?? "general";
  if (typeof value !== "number") return String(value);
  const dec = style?.dec;
  switch (fmt) {
    case "number":
      return value.toLocaleString("en-US", {
        minimumFractionDigits: dec ?? 0,
        maximumFractionDigits: dec ?? 2,
      });
    case "currency":
      return `${value.toLocaleString("en-US", {
        minimumFractionDigits: dec ?? 2,
        maximumFractionDigits: dec ?? 2,
      })} ${CURRENCY}`;
    case "percent":
      return `${(value * 100).toLocaleString("en-US", {
        minimumFractionDigits: dec ?? 0,
        maximumFractionDigits: dec ?? 2,
      })}٪`;
    case "date": {
      const d = new Date(value);
      return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleDateString("ar");
    }
    case "time": {
      const d = new Date(value);
      return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleTimeString("ar");
    }
    default:
      if (dec != null) return value.toFixed(dec);
      return String(Math.round(value * 1e10) / 1e10);
  }
}

export function displayValue(cells: Record<string, Cell>, key: string): string {
  const style = cells[key]?.s;
  return formatCellValue(computedValue(cells, key), style);
}

/** Data extracted from a range, used for charts and exports. */
export function rangeMatrix(sheet: SheetContent, range: string): { labels: string[]; series: { name: string; values: number[] }[] } {
  const b = rangeBounds(range);
  if (!b) return { labels: [], series: [] };
  const ctx = makeCtx(sheet.cells);
  const labels: string[] = [];
  const seriesNames: string[] = [];
  const seriesValues: number[][] = [];

  for (let c = b.c1 + 1; c <= b.c2; c++) {
    const head = evaluateCell(cellKey(b.r1, c), ctx);
    seriesNames.push(head === "" ? colLabel(c) : String(head));
    seriesValues.push([]);
  }
  for (let r = b.r1 + 1; r <= b.r2; r++) {
    const label = evaluateCell(cellKey(r, b.c1), ctx);
    labels.push(label === "" ? `${r + 1}` : String(label));
    for (let c = b.c1 + 1; c <= b.c2; c++) {
      const val = evaluateCell(cellKey(r, c), ctx);
      seriesValues[c - b.c1 - 1].push(typeof val === "number" ? val : Number(val) || 0);
    }
  }
  return { labels, series: seriesNames.map((name, i) => ({ name, values: seriesValues[i] })) };
}

export const SHEET_FONTS = [
  { value: "IBM Plex Sans Arabic", label: "IBM Plex عربي" },
  { value: "Readex Pro", label: "Readex Pro" },
  { value: "Amiri", label: "أميري" },
  { value: "Tahoma", label: "Tahoma" },
  { value: "Georgia", label: "Georgia" },
  { value: "Courier New", label: "Courier New" },
];
