/**
 * Shared builders for the ready-made template library.
 *
 * Templates are declared as compact specs in the sibling files and turned into
 * the exact content shapes the editors already read:
 *   - EVA document    -> JSON { html }
 *   - EVA exam        -> JSON { meta } + question records
 *   - GILOX sheet     -> JSON SheetContent
 *   - NOVEL note      -> JSON { text, font_size }
 */

import {
  DEFAULT_EXAM_META,
  DEFAULT_PAGE_SETUP,
  DEFAULT_SHEET,
  type AppType,
  type Cell,
  type CellStyle,
  type DocType,
  type ExamMeta,
  type ExamQuestion,
  type PageSetup,
  type QuestionType,
  type SheetContent,
} from "../types";

export interface TemplatePayload {
  title: string;
  doc_type: DocType;
  app_type: AppType;
  content: string;
  page_setup: string;
  questions?: Partial<ExamQuestion>[];
}

export interface TemplateDef {
  id: string;
  app: AppType;
  doc_type: DocType;
  category: string;
  title: string;
  desc: string;
  build: () => TemplatePayload;
}

/* ------------------------------------------------------------------ */
/* document HTML helpers                                               */
/* ------------------------------------------------------------------ */

const esc = (value: string) =>
  String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const TABLE_STYLE = "width:100%;border-collapse:collapse;margin:10px 0;";
const TH_STYLE =
  "border:1px solid #94a3b8;padding:7px 9px;background:#f1f5f9;font-weight:700;text-align:center;";
const TD_STYLE = "border:1px solid #94a3b8;padding:7px 9px;text-align:center;";

/**
 * Block shorthands used by the document specs:
 *  "h1:..."  main title            "h:..."   section heading
 *  "p:..."   paragraph             "q:..."   quiet / small note
 *  "l:a|b"   bullet list           "n:a|b"   numbered list
 *  "f:a|b"   labelled fields (dotted lines)
 *  "t:H1,H2;c1,c2;c1,c2"           table (first row = header)
 *  "sign:a|b"                      signature columns
 *  "hr"                            divider      "br" spacer
 */
export function blocksToHtml(blocks: string[]): string {
  const out: string[] = [];
  for (const raw of blocks) {
    const [kind, ...rest] = raw.split(":");
    const body = rest.join(":");
    switch (kind) {
      case "h1":
        out.push(
          `<h1 style="text-align:center;margin:0 0 6px;font-size:23px;">${body.startsWith("<span") ? body : esc(body)}</h1>`,
        );
        break;
      case "h":
        out.push(`<h2 style="font-size:18px;margin:16px 0 6px;">${esc(body)}</h2>`);
        break;
      case "p":
        out.push(`<p style="line-height:1.9;margin:0 0 8px;">${esc(body)}</p>`);
        break;
      case "q":
        out.push(
          `<p style="line-height:1.7;margin:0 0 8px;font-size:13px;color:#475569;">${esc(body)}</p>`,
        );
        break;
      case "l":
        out.push(
          `<ul style="margin:0 0 10px;padding-inline-start:22px;line-height:1.9;">${body
            .split("|")
            .map((item) => `<li>${esc(item)}</li>`)
            .join("")}</ul>`,
        );
        break;
      case "n":
        out.push(
          `<ol style="margin:0 0 10px;padding-inline-start:22px;line-height:1.9;">${body
            .split("|")
            .map((item) => `<li>${esc(item)}</li>`)
            .join("")}</ol>`,
        );
        break;
      case "f":
        out.push(
          body
            .split("|")
            .map(
              (label) =>
                `<p style="margin:0 0 9px;line-height:1.9;"><strong>${esc(
                  label,
                )}:</strong> ....................................................</p>`,
            )
            .join(""),
        );
        break;
      case "t": {
        const rows = body.split(";").map((row) => row.split(","));
        const [header, ...rest2] = rows;
        out.push(
          `<table style="${TABLE_STYLE}"><thead><tr>${header
            .map((cell) => `<th style="${TH_STYLE}">${esc(cell)}</th>`)
            .join("")}</tr></thead><tbody>${rest2
            .map(
              (row) =>
                `<tr>${row
                  .map((cell) => `<td style="${TD_STYLE}">${esc(cell)}</td>`)
                  .join("")}</tr>`,
            )
            .join("")}</tbody></table>`,
        );
        break;
      }
      case "sign": {
        const cols = body.split("|");
        out.push(
          `<table style="width:100%;border-collapse:collapse;margin-top:26px;"><tr>${cols
            .map(
              (col) =>
                `<td style="padding:6px;text-align:center;width:${Math.floor(
                  100 / cols.length,
                )}%;">${esc(col)}<br/><br/>................................</td>`,
            )
            .join("")}</tr></table>`,
        );
        break;
      }
      case "hr":
        out.push('<hr style="border:none;border-top:1px solid #cbd5e1;margin:14px 0;" />');
        break;
      case "br":
        out.push("<p><br/></p>");
        break;
      default:
        out.push(`<p style="line-height:1.9;margin:0 0 8px;">${esc(raw)}</p>`);
    }
  }
  return out.join("\n");
}

export interface DocSpec {
  id: string;
  title: string;
  category: string;
  desc: string;
  blocks: string[];
  setup?: Partial<PageSetup>;
}

export function docTemplate(spec: DocSpec): TemplateDef {
  return {
    id: spec.id,
    app: "eva",
    doc_type: "document",
    category: spec.category,
    title: spec.title,
    desc: spec.desc,
    build: () => ({
      title: spec.title,
      doc_type: "document",
      app_type: "eva",
      content: JSON.stringify({ html: blocksToHtml(spec.blocks) }),
      page_setup: JSON.stringify({ ...DEFAULT_PAGE_SETUP, ...(spec.setup ?? {}) }),
    }),
  };
}

/* ------------------------------------------------------------------ */
/* exam templates                                                      */
/* ------------------------------------------------------------------ */

export interface ExamQSpec {
  text: string;
  type: QuestionType;
  choices?: string[];
  answer?: string;
  marks?: number;
  lines?: number;
  section?: string;
}

export interface ExamSpec {
  id: string;
  title: string;
  category: string;
  desc: string;
  meta: Partial<ExamMeta>;
  questions: ExamQSpec[];
  setup?: Partial<PageSetup>;
}

export function examTemplate(spec: ExamSpec): TemplateDef {
  return {
    id: spec.id,
    app: "eva",
    doc_type: "exam",
    category: spec.category,
    title: spec.title,
    desc: spec.desc,
    build: () => ({
      title: spec.title,
      doc_type: "exam",
      app_type: "eva",
      content: JSON.stringify({
        meta: { ...DEFAULT_EXAM_META, exam_title: spec.title, ...spec.meta },
      }),
      page_setup: JSON.stringify({ ...DEFAULT_PAGE_SETUP, ...(spec.setup ?? {}) }),
      questions: spec.questions.map((q, index) => ({
        question_text: q.text,
        question_type: q.type,
        choices: q.choices ? JSON.stringify(q.choices) : null,
        correct_answer: q.answer ?? null,
        marks: q.marks ?? 1,
        answer_lines: q.lines ?? (q.type === "essay" ? 6 : q.type === "short_answer" ? 3 : 0),
        section_title: q.section ?? null,
        order_index: index,
      })),
    }),
  };
}

/* ------------------------------------------------------------------ */
/* sheet templates                                                     */
/* ------------------------------------------------------------------ */

const HEADER_STYLE: CellStyle = {
  b: true,
  a: "center",
  bg: "#e2e8f0",
  c: "#0f172a",
  bd: true,
  w: true,
};
const BODY_STYLE: CellStyle = { a: "center", bd: true };
const TOTAL_STYLE: CellStyle = { b: true, a: "center", bg: "#fef3c7", bd: true };
const TITLE_STYLE: CellStyle = { b: true, fs: 18, a: "center" };

const COL = (index: number) => String.fromCharCode(65 + index);

export interface SheetSpec {
  id: string;
  title: string;
  category: string;
  desc: string;
  headers: string[];
  rows: (string | number)[][];
  /** Column letters that get a SUM row under the data. */
  sumCols?: string[];
  widths?: Record<string, number>;
  chart?: { kind: "bar" | "line" | "pie"; title: string; range: string };
  note?: string;
}

export function sheetTemplate(spec: SheetSpec): TemplateDef {
  return {
    id: spec.id,
    app: "gilox",
    doc_type: "spreadsheet",
    category: spec.category,
    title: spec.title,
    desc: spec.desc,
    build: () => {
      const cells: Record<string, Cell> = {};
      // Row 1: sheet title across the used columns.
      cells["A1"] = { v: spec.title, s: TITLE_STYLE };
      // Row 2: headers.
      spec.headers.forEach((header, i) => {
        cells[`${COL(i)}2`] = { v: header, s: HEADER_STYLE };
      });
      spec.rows.forEach((row, r) => {
        row.forEach((value, c) => {
          cells[`${COL(c)}${r + 3}`] = { v: String(value), s: BODY_STYLE };
        });
      });
      const firstDataRow = 3;
      const lastDataRow = spec.rows.length + 2;
      if (spec.sumCols?.length) {
        const totalRow = lastDataRow + 1;
        cells[`A${totalRow}`] = { v: "الإجمالي", s: TOTAL_STYLE };
        spec.sumCols.forEach((col) => {
          cells[`${col}${totalRow}`] = {
            v: `=SUM(${col}${firstDataRow}:${col}${lastDataRow})`,
            s: TOTAL_STYLE,
          };
        });
      }
      if (spec.note) {
        cells[`A${lastDataRow + 3}`] = { v: spec.note, s: { fs: 12, c: "#475569" } };
      }
      const sheet: SheetContent = {
        ...DEFAULT_SHEET,
        rows: Math.max(DEFAULT_SHEET.rows, lastDataRow + 8),
        cols: Math.max(DEFAULT_SHEET.cols, spec.headers.length + 2),
        cells,
        col_widths: { A: 150, ...(spec.widths ?? {}) },
        merges: [`A1:${COL(Math.max(spec.headers.length - 1, 1))}1`],
        charts: spec.chart
          ? [
              {
                id: `${spec.id}-chart`,
                kind: spec.chart.kind,
                title: spec.chart.title,
                range: spec.chart.range,
                height: 240,
              },
            ]
          : [],
        frozen_header: true,
      };
      return {
        title: spec.title,
        doc_type: "spreadsheet",
        app_type: "gilox",
        content: JSON.stringify(sheet),
        page_setup: JSON.stringify({ ...DEFAULT_PAGE_SETUP, orientation: "landscape" }),
      };
    },
  };
}

/* ------------------------------------------------------------------ */
/* note templates                                                      */
/* ------------------------------------------------------------------ */

export interface NoteSpec {
  id: string;
  title: string;
  category: string;
  desc: string;
  lines: string[];
}

export function noteTemplate(spec: NoteSpec): TemplateDef {
  return {
    id: spec.id,
    app: "novel",
    doc_type: "note",
    category: spec.category,
    title: spec.title,
    desc: spec.desc,
    build: () => ({
      title: spec.title,
      doc_type: "note",
      app_type: "novel",
      content: JSON.stringify({ text: spec.lines.join("\n"), font_size: 17 }),
      page_setup: JSON.stringify(DEFAULT_PAGE_SETUP),
    }),
  };
}
