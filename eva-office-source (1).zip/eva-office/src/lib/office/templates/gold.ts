import type { StationerySpec } from "./stationery";

/**
 * 12 luxury "metallic gold" stationery layouts with no text at all.
 *
 * Each template is plain inline-styled HTML (the same shape as the other
 * stationery templates), so it opens in the EVA editor, paginates, previews
 * and exports to PDF exactly like them. Ornaments are tiny inline SVG
 * data-URIs used as CSS backgrounds (no external files, no extra assets) and
 * the metallic frames are CSS gradients. The writing area is a normal editable
 * empty paragraph block in the middle of every design.
 */

/* ------------------------------------------------------------------ */
/* colour + svg helpers                                                */
/* ------------------------------------------------------------------ */

const GOLD_LINE = "#c9a227";
const GOLD_SHEEN =
  "linear-gradient(135deg,#7a5410 0%,#c99a2e 16%,#f6e08a 34%,#fff6c8 48%,#e0b445 62%,#a37a1c 80%,#6e4a0c 100%)";
const GOLD_SHEEN_H =
  "linear-gradient(90deg,#7a5410 0%,#c99a2e 14%,#f6e08a 32%,#fff6c8 50%,#e0b445 66%,#a37a1c 84%,#6e4a0c 100%)";

/** Shared SVG gradient: metallic gold. Colours are plain hex so the template customizer can recolour them. */
const DEFS =
  "<defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>" +
  "<stop offset='0' stop-color='#7a5410'/><stop offset='.22' stop-color='#d4a937'/>" +
  "<stop offset='.45' stop-color='#fff1a8'/><stop offset='.68' stop-color='#c8961f'/>" +
  "<stop offset='1' stop-color='#7a5410'/></linearGradient></defs>";

const enc = (s: string) =>
  encodeURIComponent(s).replace(/'/g, "%27").replace(/\(/g, "%28").replace(/\)/g, "%29");

/** CSS url() for an SVG string; safe inside a double-quoted style attribute. */
const svgUrl = (w: number, h: number, body: string) =>
  `url('data:image/svg+xml,${enc(`<svg xmlns='http://www.w3.org/2000/svg' width='${w}' height='${h}' viewBox='0 0 ${w} ${h}'>${DEFS}${body}</svg>`)}')`;

const G = "url(#g)";
const stroke = (w = 2) => `fill='none' stroke='${G}' stroke-width='${w}' stroke-linecap='round' stroke-linejoin='round'`;

/* ------------------------------------------------------------------ */
/* ornaments                                                           */
/* ------------------------------------------------------------------ */

/** Acanthus-style leaf, pointing along +x from (0,0). */
const leaf = (x: number, y: number, rot: number, k = 1) =>
  `<path d='M0 0 C6 -9 20 -10 28 0 C20 10 6 9 0 0 Z' transform='translate(${x} ${y}) rotate(${rot}) scale(${k})' fill='${G}'/>`;

/** One scrolling arm running along the top edge (the left arm is its diagonal mirror). */
const ARM = `
<g ${stroke(3)}>
  <path d='M56 30 C88 30 98 58 128 52 C156 46 154 16 130 22 C114 26 116 44 132 42'/>
  <path d='M60 30 C86 14 112 14 132 28' stroke-width='2'/>
  <path d='M150 30 C170 30 184 22 200 22' stroke-width='2'/>
</g>
${leaf(86, 30, -36, 0.9)}${leaf(106, 52, 8, 0.8)}${leaf(150, 26, -8, 0.7)}${leaf(78, 44, 50, 0.7)}
<g fill='${G}'><circle cx='132' cy='42' r='3.4'/><circle cx='214' cy='22' r='3.6'/><circle cx='230' cy='22' r='2.4'/><circle cx='243' cy='22' r='1.6'/></g>`;

const FILIGREE = `
${ARM}
<g transform='matrix(0 1 1 0 0 0)'>${ARM}</g>
<g ${stroke(3)}>
  <path d='M48 48 C70 72 92 72 98 94 C102 112 84 118 78 104 C74 94 86 90 92 98'/>
  <path d='M44 56 C54 76 56 92 46 112' stroke-width='2'/><path d='M56 44 C76 54 92 56 112 46' stroke-width='2'/>
</g>
${leaf(70, 70, 45, 0.9)}${leaf(52, 96, 100, 0.55)}${leaf(96, 52, -10, 0.55)}
<g>
  <circle cx='30' cy='30' r='22' fill='none' stroke='${G}' stroke-width='2.4'/>
  <g fill='${G}'>${Array.from({ length: 8 }, (_, i) => `<ellipse cx='30' cy='${(30 - 15).toFixed(0)}' rx='4.4' ry='9' transform='rotate(${i * 45} 30 30)'/>`).join("")}</g>
  <circle cx='30' cy='30' r='8' fill='#fff1a8' stroke='#8a6a1a' stroke-width='1.4'/><circle cx='30' cy='30' r='3.4' fill='${G}'/>
</g>`;

/** Art-deco fan corner. */
const DECO = `
<g ${stroke(2)}>
  <path d='M18 18 L18 150'/><path d='M18 18 L150 18'/>
  <path d='M18 40 A22 22 0 0 0 40 18'/><path d='M18 64 A46 46 0 0 0 64 18'/>
  <path d='M18 88 A70 70 0 0 0 88 18'/><path d='M18 112 A94 94 0 0 0 112 18'/>
  <path d='M18 18 L84 84'/><path d='M18 18 L70 98'/><path d='M18 18 L98 70'/>
  <path d='M34 168 L34 190'/><path d='M168 34 L190 34'/>
</g>
<g fill='${G}'><path d='M18 18 L36 18 L18 36 Z'/><circle cx='88' cy='88' r='4'/><circle cx='22' cy='170' r='3'/><circle cx='170' cy='22' r='3'/></g>`;

/** Islamic eight-point-star corner. */
const STAR_CORNER = `
<g ${stroke(3)}>
  <path d='M70.0 24.0 L79.9 46.0 L102.5 37.5 L94.0 60.1 L116.0 70.0 L94.0 79.9 L102.5 102.5 L79.9 94.0 L70.0 116.0 L60.1 94.0 L37.5 102.5 L46.0 79.9 L24.0 70.0 L46.0 60.1 L37.5 37.5 L60.1 46.0 Z'/>
  <path d='M70.0 40.0 L76.5 54.3 L91.2 48.8 L85.7 63.5 L100.0 70.0 L85.7 76.5 L91.2 91.2 L76.5 85.7 L70.0 100.0 L63.5 85.7 L48.8 91.2 L54.3 76.5 L40.0 70.0 L54.3 63.5 L48.8 48.8 L63.5 54.3 Z' stroke-width='1.6'/>
  <circle cx='70' cy='70' r='9'/>
  <path d='M118 70 H196 M70 118 V196' stroke-width='2'/>
  <path d='M120 26 H196 M26 120 V196' stroke-width='1.4'/>
</g>
<g fill='${G}'><circle cx='70' cy='70' r='4.4'/>
<path d='M204 70 l6 -6 l6 6 l-6 6 Z'/><path d='M70 204 l6 -6 l6 6 l-6 6 Z'/>
<circle cx='200' cy='26' r='3'/><circle cx='26' cy='200' r='3'/></g>`;

/** Minimal champagne corner. */
const SLIM = `
<g ${stroke(1.6)}><path d='M20 90 V20 H90'/><path d='M32 70 V32 H70'/></g>
<g fill='${G}'><path d='M20 8 L32 20 L20 32 L8 20 Z'/><circle cx='96' cy='20' r='2.6'/><circle cx='20' cy='96' r='2.6'/></g>`;

type Corner = "TL" | "TR" | "BL" | "BR";
const mirror = (c: Corner, n: number) =>
  ({
    TL: "",
    TR: `transform='translate(${n} 0) scale(-1 1)'`,
    BL: `transform='translate(0 ${n}) scale(1 -1)'`,
    BR: `transform='translate(${n} ${n}) scale(-1 -1)'`,
  })[c];
const cornerUrl = (body: string, c: Corner, n: number) => svgUrl(n, n, `<g ${mirror(c, n)}>${body}</g>`);

/** Four corner backgrounds (list order matches CORNER_POS). `n` is the artwork's square size. */
const cornerImages = (body: string, n = body === FILIGREE ? 250 : 200) => (["TL", "TR", "BL", "BR"] as Corner[]).map((c) => cornerUrl(body, c, n));
const CORNER_POS = ["left top", "right top", "left bottom", "right bottom"];

/** Horizontal flourish with a central diamond (300x90). */
const MEDALLION_BODY = `
<g ${stroke(2.4)}>
  <path d='M150 45 C132 45 122 24 100 24 C80 24 76 45 58 45 C42 45 36 32 18 32'/>
  <path d='M150 45 C132 45 122 66 100 66 C80 66 76 45 58 45 C42 45 36 58 18 58'/>
  <path d='M150 45 C134 45 128 45 112 45' stroke-width='1.4'/>
  <g transform='translate(300 0) scale(-1 1)'>
    <path d='M150 45 C132 45 122 24 100 24 C80 24 76 45 58 45 C42 45 36 32 18 32'/>
    <path d='M150 45 C132 45 122 66 100 66 C80 66 76 45 58 45 C42 45 36 58 18 58'/>
  </g>
  <path d='M150 14 L150 76' stroke-width='1.2'/>
</g>
<g fill='${G}'>
  <path d='M150 24 L172 45 L150 66 L128 45 Z'/>
  <circle cx='150' cy='45' r='7' fill='#fff6c8'/><circle cx='150' cy='45' r='3.4'/>
  <circle cx='10' cy='32' r='3'/><circle cx='10' cy='58' r='3'/><circle cx='290' cy='32' r='3'/><circle cx='290' cy='58' r='3'/>
  <circle cx='150' cy='11' r='3.4'/><circle cx='150' cy='79' r='3.4'/>
</g>`;
const medallion = svgUrl(300, 90, MEDALLION_BODY);
const medallionFlip = svgUrl(300, 90, `<g transform='translate(0 90) scale(1 -1)'>${MEDALLION_BODY}</g>`);

/** A small five-point crown (120x84). */
const CROWN = svgUrl(
  120,
  84,
  `<path d='M12 68 L6 22 L34 44 L60 8 L86 44 L114 22 L108 68 Z' fill='${G}' stroke='#6e4a0c' stroke-width='1.2' stroke-linejoin='round'/>
   <rect x='12' y='68' width='96' height='9' rx='2' fill='${G}' stroke='#6e4a0c' stroke-width='1.2'/>
   <circle cx='6' cy='20' r='5' fill='${G}'/><circle cx='60' cy='6' r='6' fill='${G}'/><circle cx='114' cy='20' r='5' fill='${G}'/>
   <circle cx='60' cy='46' r='6' fill='#fff6c8' stroke='#8a6a1a'/><circle cx='34' cy='58' r='3.6' fill='#fff6c8'/><circle cx='86' cy='58' r='3.6' fill='#fff6c8'/>
   <path d='M22 72.5 H98' stroke='#fff6c8' stroke-width='1'/>`,
);

/** Repeating eight-point-star band tile (56x44). */
const STAR_TILE = svgUrl(
  56,
  44,
  `<g ${stroke(1.6)}><path d='M28 6 L34 16 L46 14 L42 24 L50 32 L38 32 L34 40 L28 32 L22 40 L18 32 L6 32 L14 24 L10 14 L22 16 Z' transform='translate(0 -2)'/>
    <circle cx='28' cy='22' r='6'/><path d='M0 2 H56 M0 42 H56' stroke-width='1.2'/></g>
   <circle cx='28' cy='22' r='2.4' fill='${G}'/>`,
);

/** Simple bead/diamond divider tile (30x14). */
const BEAD_TILE = svgUrl(
  30,
  14,
  `<path d='M15 2 L22 7 L15 12 L8 7 Z' fill='${G}'/><circle cx='1.6' cy='7' r='1.6' fill='${G}'/><circle cx='28.4' cy='7' r='1.6' fill='${G}'/>`,
);

/** Seamless damask tile (120x120), kept faint. */
const DAMASK = svgUrl(
  120,
  120,
  `<g opacity='.7'>
    <g fill='none' stroke='${G}' stroke-width='1.6' stroke-linecap='round'>
      <path d='M60 16 C80 38 80 62 60 86 C40 62 40 38 60 16 Z'/>
      <path d='M60 86 C50 98 38 100 30 94 C38 90 46 88 54 84'/><path d='M60 86 C70 98 82 100 90 94 C82 90 74 88 66 84'/>
      <path d='M60 40 C48 34 36 38 30 48 C40 46 50 48 56 54'/><path d='M60 40 C72 34 84 38 90 48 C80 46 70 48 64 54'/>
    </g>
    <path d='M60 26 C70 42 70 58 60 74 C50 58 50 42 60 26 Z' fill='${G}' opacity='.5'/>
    <path d='M0 0 L8 8 L0 16 L-8 8 Z M120 0 L128 8 L120 16 L112 8 Z M0 120 L8 128 L0 136 L-8 128 Z M120 120 L128 128 L120 136 L112 128 Z' fill='${G}'/>
    <path d='M60 -2 C66 6 66 12 60 20 C54 12 54 6 60 -2 Z' fill='${G}'/><path d='M60 100 C66 108 66 114 60 122 C54 114 54 108 60 100 Z' fill='${G}'/>
  </g>`,
);

/** Round wax-style seal with ribbons (170x230). */
const SEAL = (() => {
  const scallops = Array.from({ length: 28 }, (_, i) => {
    const a = (i / 28) * Math.PI * 2;
    return `<circle cx='${(85 + Math.cos(a) * 62).toFixed(1)}' cy='${(85 + Math.sin(a) * 62).toFixed(1)}' r='9' fill='${G}'/>`;
  }).join("");
  const rays = Array.from({ length: 16 }, (_, i) => {
    const a = (i / 16) * Math.PI * 2;
    return `<path d='M${(85 + Math.cos(a) * 24).toFixed(1)} ${(85 + Math.sin(a) * 24).toFixed(1)} L${(85 + Math.cos(a) * 44).toFixed(1)} ${(85 + Math.sin(a) * 44).toFixed(1)}'/>`;
  }).join("");
  return svgUrl(
    170,
    230,
    `<path d='M52 128 L34 224 L62 208 L78 228 L92 140 Z' fill='${G}' stroke='#6e4a0c' stroke-width='1.2'/>
     <path d='M118 128 L136 224 L108 208 L92 228 L78 140 Z' fill='${G}' stroke='#6e4a0c' stroke-width='1.2'/>
     ${scallops}
     <circle cx='85' cy='85' r='60' fill='${G}' stroke='#6e4a0c' stroke-width='1.4'/>
     <circle cx='85' cy='85' r='50' fill='none' stroke='#fff6c8' stroke-width='1.6'/>
     <circle cx='85' cy='85' r='46' fill='none' stroke='#6e4a0c' stroke-width='1'/>
     <g stroke='#6e4a0c' stroke-width='1.3' stroke-linecap='round'>${rays}</g>
     <circle cx='85' cy='85' r='20' fill='#fff1a8' stroke='#8a6a1a' stroke-width='1.4'/>
     <path d='M85 68 L90 80 L103 80 L92.5 88 L96.5 100 L85 93 L73.5 100 L77.5 88 L67 80 L80 80 Z' fill='${G}' stroke='#8a6a1a' stroke-width='1'/>`,
  );
})();

/* ------------------------------------------------------------------ */
/* building blocks                                                     */
/* ------------------------------------------------------------------ */

const para = (n: number) => Array.from({ length: n }, () => `<p style="margin:0 0 8px;"><br></p>`).join("");
const sigLine = (c: string) => `<div style="height:44px;border-bottom:1.5px solid ${c};"></div>`;
const gap = (h: number) => `<div style="height:${h}px;"></div>`;
const row = (cells: string[], spacing: number, widths?: string[]) =>
  `<table style="width:100%;border-collapse:separate;border-spacing:${spacing}px 0;margin:0;"><tr>${cells
    .map((c, i) => `<td style="vertical-align:bottom;padding:0;${widths?.[i] ? `width:${widths[i]};` : ""}">${c}</td>`)
    .join("")}</tr></table>`;

interface Layer { img: string; pos: string; size: string; repeat?: string }

interface Luxe {
  /** page fill behind the ornaments (hex) */
  fill: string;
  /** optional wash (a CSS gradient) painted over the fill */
  wash?: string;
  /** writing colour so typed text stays readable on the fill */
  ink: string;
  corner?: string;
  cornerSize?: number;
  layers?: Layer[];
  radius?: number;
  height?: number;
  pad?: string;
  align?: "right" | "center";
  content?: string;
  /** flow bands placed inside the inner frame, above/below the writing area */
  before?: string;
  after?: string;
}

const bgCss = (layers: Layer[]) =>
  layers.length
    ? `background-image:${layers.map((l) => l.img).join(",")};background-position:${layers.map((l) => l.pos).join(",")};background-size:${layers.map((l) => l.size).join(",")};background-repeat:${layers.map((l) => l.repeat ?? "no-repeat").join(",")};`
    : "";

/**
 * Metallic frame (gold gradient) > fill > gold hairline > ornament surface,
 * then a double gold line and the empty writing area. Heights are min-heights,
 * so typing beyond the page simply makes the design grow.
 */
function luxe(o: Luxe): string {
  const h = o.height ?? 1038;
  const r = o.radius ?? 3;
  const cs = o.cornerSize ?? 230;
  const layers: Layer[] = [
    ...(o.corner ? cornerImages(o.corner).map((img, i) => ({ img, pos: CORNER_POS[i]!, size: `${cs}px ${cs}px` })) : []),
    ...(o.layers ?? []),
    ...(o.wash ? [{ img: o.wash, pos: "center top", size: "100% 100%" }] : []),
  ];
  const body = `<div style="padding:${o.pad ?? "150px 96px"};color:${o.ink};text-align:${o.align ?? "right"};">${o.content ?? para(5)}</div>`;
  return (
    `<div style="box-sizing:border-box;min-height:${h}px;padding:6px;border-radius:${r}px;background:${GOLD_SHEEN};">` +
    `<div style="box-sizing:border-box;padding:6px;background-color:${o.fill};">` +
    `<div style="box-sizing:border-box;padding:2px;background:${GOLD_SHEEN_H};">` +
    `<div style="box-sizing:border-box;padding:12px;min-height:${h - 28}px;background-color:${o.fill};${bgCss(layers)}">` +
    `<div style="box-sizing:border-box;border:3px solid ${GOLD_LINE};padding:8px;min-height:${h - 52}px;">` +
    `<div style="box-sizing:border-box;border:1px solid ${GOLD_LINE};min-height:${h - 74}px;display:flex;flex-direction:column;">${o.before ?? ""}<div style="flex:1 1 auto;">${body}</div>${o.after ?? ""}</div>` +
    `</div></div></div></div></div>`
  );
}

const band = (tile: string, w: number, h: number, inset: number, top: number, bottom: number) =>
  `<div style="height:${h}px;margin:${top}px ${inset}px ${bottom}px;background-image:${tile};background-repeat:repeat-x;background-position:center;background-size:${w}px ${h}px;"></div>`;

const flourishTop = { img: medallion, pos: "center 30px", size: "380px 114px" };
const flourishBottom = { img: medallionFlip, pos: "center calc(100% - 30px)", size: "380px 114px" };
const crown = { img: CROWN, pos: "center 30px", size: "112px 78px" };

/* ------------------------------------------------------------------ */
/* the 12 templates                                                    */
/* ------------------------------------------------------------------ */

const IVORY = "#fffcf3";
const BLACK = "#0c0a07";
const NAVY = "#0b1530";
const WINE = "#4a0e1c";
const EMERALD = "#07382c";
const GLOW = (c: string) => `radial-gradient(ellipse at 50% 0%,${c} 0%,transparent 62%)`;

const NOTE_LIGHT = "#3a2a08";
const NOTE_DARK = "#f1dfa0";

const GOLD_SETUP: StationerySpec["setup"] = { margin: 6, show_page_numbers: false, border_style: "none" };

const SPECS: StationerySpec[] = [
  {
    id: "gl-royal-ivory",
    name: "ملكي عاجي",
    accent: "#c9a227",
    html: luxe({ fill: IVORY, ink: NOTE_LIGHT, corner: FILIGREE, layers: [crown, flourishBottom] }),
  },
  {
    id: "gl-royal-black",
    name: "ذهبي على الأسود الملكي",
    accent: "#c9a227",
    html: luxe({ fill: BLACK, ink: NOTE_DARK, corner: FILIGREE, layers: [flourishTop, flourishBottom] }),
  },
  {
    id: "gl-navy-deco",
    name: "آرت ديكو كحلي",
    accent: "#c9a227",
    html: luxe({
      fill: NAVY, ink: NOTE_DARK, corner: DECO, cornerSize: 190, radius: 0,
      before: band(BEAD_TILE, 30, 14, 200, 34, 0), after: band(BEAD_TILE, 30, 14, 200, 0, 34),
      pad: "90px 96px",
    }),
  },
  {
    id: "gl-burgundy-crown",
    name: "عنابي بالتاج الذهبي",
    accent: "#c9a227",
    html: luxe({ fill: WINE, ink: NOTE_DARK, corner: FILIGREE, layers: [crown, flourishBottom] }),
  },
  {
    id: "gl-emerald-arabesque",
    name: "زمردي أرابيسك",
    accent: "#c9a227",
    html: luxe({
      fill: EMERALD, ink: NOTE_DARK, corner: STAR_CORNER, cornerSize: 190,
      before: band(STAR_TILE, 56, 44, 200, 22, 0), after: band(STAR_TILE, 56, 44, 200, 0, 22),
      pad: "90px 96px",
    }),
  },
  {
    id: "gl-islamic-ivory",
    name: "زخرفة إسلامية عاجية",
    accent: "#c9a227",
    html: luxe({
      fill: IVORY, ink: NOTE_LIGHT, corner: STAR_CORNER, cornerSize: 190,
      before: band(STAR_TILE, 56, 44, 200, 22, 0), after: band(STAR_TILE, 56, 44, 200, 0, 22),
      pad: "90px 96px",
    }),
  },
  {
    id: "gl-certificate",
    name: "شهادة ذهبية بالختم",
    accent: "#c9a227",
    html: luxe({
      fill: IVORY, ink: NOTE_LIGHT, corner: FILIGREE, align: "center",
      layers: [crown, { img: SEAL, pos: "center calc(100% - 38px)", size: "128px 173px" }],
      pad: "170px 96px 0",
      content: para(4) + gap(250) + row([sigLine(GOLD_LINE), "<div></div>", sigLine(GOLD_LINE)], 22, ["34%", "32%", "34%"]) + gap(200),
    }),
  },
  {
    id: "gl-letterhead",
    name: "ورقة رسمية فاخرة",
    accent: "#c9a227",
    html:
      `<div style="box-sizing:border-box;min-height:1038px;padding:6px;background:${GOLD_SHEEN};border-radius:2px;">` +
      `<div style="box-sizing:border-box;min-height:1026px;padding:0 0 0;background:${IVORY};">` +
      `<div style="height:14px;background:${GOLD_SHEEN_H};"></div>` +
      `<div style="height:150px;background-image:${CROWN},${BEAD_TILE},${BEAD_TILE};background-repeat:no-repeat,repeat-x,repeat-x;background-position:center 30px,center 118px,center 138px;background-size:60px 42px,30px 14px,30px 14px;"></div>` +
      `<div style="height:2px;margin:0 70px;background:${GOLD_SHEEN_H};"></div><div style="height:1px;margin:4px 70px 0;background:${GOLD_LINE};"></div>` +
      `<div style="box-sizing:border-box;padding:34px 80px 0;color:${NOTE_LIGHT};min-height:743px;">${para(8)}</div>` +
      `<div style="height:1px;margin:0 70px 4px;background:${GOLD_LINE};"></div><div style="height:2px;margin:0 70px;background:${GOLD_SHEEN_H};"></div>` +
      `<div style="height:90px;background-image:${BEAD_TILE};background-repeat:repeat-x;background-position:center 32px;background-size:30px 14px;"></div>` +
      `<div style="height:14px;background:${GOLD_SHEEN_H};"></div></div></div>`,
  },
  {
    id: "gl-invitation-arch",
    name: "دعوة ملكية بقوس",
    accent: "#c9a227",
    html:
      `<div style="box-sizing:border-box;min-height:1038px;padding:6px;background:${GOLD_SHEEN};">` +
      `<div style="box-sizing:border-box;min-height:1026px;padding:44px 40px;background:${WINE};background-image:${GLOW("#7a1b33")};">` +
      `<div style="box-sizing:border-box;padding:6px;border-radius:260px 260px 6px 6px;background:${GOLD_SHEEN};">` +
      `<div style="box-sizing:border-box;padding:10px;border-radius:254px 254px 3px 3px;background:${WINE};">` +
      `<div style="box-sizing:border-box;min-height:884px;border:1.5px solid ${GOLD_LINE};border-radius:244px 244px 2px 2px;background-image:${CROWN},${flourishBottom.img};background-repeat:no-repeat;background-position:center 64px,center calc(100% - 40px);background-size:92px 64px,300px 90px;">` +
      `<div style="padding:190px 70px 130px;color:${NOTE_DARK};text-align:center;">${para(5)}</div></div></div></div></div></div>`,
  },
  {
    id: "gl-champagne",
    name: "شمبانيا فاخر",
    accent: "#c9a227",
    html: luxe({
      fill: "#f6ecd4", wash: "linear-gradient(180deg,#fcf8ee 0%,#f0e1bd 100%)", ink: NOTE_LIGHT, corner: SLIM, cornerSize: 120, radius: 2,
      layers: [flourishTop, flourishBottom], pad: "150px 96px",
    }),
  },
  {
    id: "gl-damask",
    name: "دمشقي ذهبي",
    accent: "#c9a227",
    html:
      `<div style="box-sizing:border-box;min-height:1038px;padding:6px;background:${GOLD_SHEEN};border-radius:3px;">` +
      `<div style="box-sizing:border-box;min-height:1026px;padding:54px 50px;background-color:#f8f0dc;background-image:${DAMASK};background-size:120px 120px;">` +
      `<div style="box-sizing:border-box;padding:5px;background:${GOLD_SHEEN};">` +
      `<div style="box-sizing:border-box;min-height:910px;padding:60px 52px;background:${IVORY};border:1px solid ${GOLD_LINE};background-image:${cornerImages(SLIM)[0]},${cornerImages(SLIM)[1]},${cornerImages(SLIM)[2]},${cornerImages(SLIM)[3]};background-repeat:no-repeat;background-position:left top,right top,left bottom,right bottom;background-size:90px 90px;color:${NOTE_LIGHT};">${para(8)}</div></div></div></div>`,
  },
  {
    id: "gl-art-deco-black",
    name: "آرت ديكو أسود",
    accent: "#c9a227",
    html: luxe({
      fill: BLACK, ink: NOTE_DARK, corner: DECO, cornerSize: 200, radius: 0,
      wash: GLOW("#2c2210"),
      pad: "140px 100px",
    }),
  },
];

export const GOLD_STATIONERY: StationerySpec[] = SPECS.map((spec) => ({ ...spec, setup: { ...GOLD_SETUP, ...(spec.setup ?? {}) } }));
