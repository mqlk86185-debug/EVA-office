import { DEFAULT_PAGE_SETUP, type PageSetup } from "../types";
import type { TemplateDef } from "./build";

/**
 * 15 blank professional layouts. Each one is pure structure (lines, frames,
 * empty tables, image/heading slots) with no sample text, so the writer fills
 * every area themselves. Only short structural labels are used where a form
 * needs them (e.g. invoice column names).
 */

const box = (h: number, style = "") =>
  `<div style="min-height:${h}px;border:1px dashed #cbd5e1;border-radius:6px;margin:10px 0;${style}"><br></div>`;
const img = (h: number, style = "") =>
  `<div style="height:${h}px;border:1.5px dashed #94a3b8;border-radius:8px;background:#f8fafc;display:flex;align-items:center;justify-content:center;color:#94a3b8;font-size:12px;margin:10px 0;${style}">🖼</div>`;
const line = (color = "#e2e8f0", w = 1, m = 10) => `<div style="border-top:${w}px solid ${color};margin:${m}px 0;"></div>`;
const lines = (n: number, color = "#e2e8f0") =>
  Array.from({ length: n }, () => `<p style="border-bottom:1px solid ${color};margin:0;min-height:30px;"><br></p>`).join("");
const slot = (size: number, color: string, extra = "") =>
  `<h2 style="font-size:${size}px;color:${color};margin:6px 0;min-height:${size + 10}px;border-bottom:1px dotted #cbd5e1;${extra}"><br></h2>`;
const table = (cols: string[], rows: number, head = "#f1f5f9", border = "#cbd5e1", color = "#0f172a") => {
  const th = cols.map((c) => `<th style="border:1px solid ${border};padding:8px;background:${head};color:${color};font-size:13px;">${c}</th>`).join("");
  const tr = Array.from({ length: rows }, () => `<tr>${cols.map(() => `<td style="border:1px solid ${border};padding:8px;height:22px;"><br></td>`).join("")}</tr>`).join("");
  return `<table style="width:100%;border-collapse:collapse;margin:10px 0;"><tr>${th}</tr>${tr}</table>`;
};
const cols = (parts: string[], gap = 14) =>
  `<table style="width:100%;border-collapse:separate;border-spacing:${gap}px 0;margin:8px 0;"><tr>${parts.map((p) => `<td style="vertical-align:top;padding:0;">${p}</td>`).join("")}</tr></table>`;
const band = (bg: string, h: number, inner = "") =>
  `<div style="background:${bg};min-height:${h}px;border-radius:4px;margin:0 0 14px;padding:14px;">${inner}</div>`;
const sign = (n: number, color = "#94a3b8") =>
  cols(Array.from({ length: n }, () => `<div style="height:48px;border-bottom:1.5px solid ${color};"></div>`), 30);

interface ProSpec { id: string; title: string; desc: string; html: string; setup?: Partial<PageSetup> }

const SPECS: ProSpec[] = [
  {
    id: "pro-official-doc", title: "مستند رسمي", desc: "رسمي فاخر بترويسة ذهبية وإطار مزدوج.",
    setup: { border_style: "double", border_color: "#a16207", margin: 14 },
    html: cols([img(60, "width:60px;"), slot(22, "#713f12", "text-align:center;"), img(60, "width:60px;")]) + line("#a16207", 2, 6) + line("#a16207", 1, 2) + box(26, "width:40%;") + lines(14) + sign(2, "#a16207"),
  },
  {
    id: "pro-letter", title: "خطاب رسمي", desc: "كلاسيكي بشريط جانبي وبيانات المرسل والمستلم.",
    setup: { margin: 16 },
    html: `<div style="border-right:5px solid #1e3a8a;padding-right:14px;">${slot(20, "#1e3a8a")}${box(22, "width:55%;")}</div>` + line("#1e3a8a", 1, 14) + cols([box(70), box(70)]) + box(24, "width:35%;margin-right:auto;") + lines(12) + sign(1, "#1e3a8a"),
  },
  {
    id: "pro-report", title: "تقرير احترافي", desc: "شركات حديث بشريط علوي وملخص تنفيذي.",
    html: band("#0f766e", 70, slot(24, "#ffffff", "border-color:#5eead4;")) + cols([box(60, "border-color:#5eead4;"), box(60, "border-color:#5eead4;"), box(60, "border-color:#5eead4;")]) + slot(17, "#0f766e") + lines(6) + slot(17, "#0f766e") + table(["", "", "", ""], 4, "#ccfbf1", "#99f6e4") + lines(4),
  },
  {
    id: "pro-academic", title: "بحث أكاديمي", desc: "أكاديمي بخطوط رفيعة وملخص ومراجع.",
    setup: { margin: 20 },
    html: slot(22, "#111827", "text-align:center;border:none;") + box(22, "width:50%;margin:6px auto;border-style:dotted;") + line("#111827", 1, 12) + `<div style="background:#f9fafb;border-right:3px solid #6b7280;padding:10px;">${lines(4, "#e5e7eb")}</div>` + slot(16, "#374151") + lines(6) + slot(16, "#374151") + lines(5) + line("#111827", 1, 16) + lines(3, "#d1d5db"),
  },
  {
    id: "pro-cv", title: "سيرة ذاتية CV", desc: "إبداعي بعمود جانبي للصورة والمهارات.",
    setup: { margin: 8 },
    html: cols([
      `<div style="background:#1f2937;border-radius:8px;padding:14px;min-height:820px;">${img(120, "border-radius:999px;width:120px;margin:0 auto 14px;background:#374151;border-color:#6b7280;")}${slot(16, "#f9fafb", "border-color:#4b5563;")}${box(90, "border-color:#4b5563;")}${slot(16, "#f9fafb", "border-color:#4b5563;")}${box(140, "border-color:#4b5563;")}</div>`,
      `${slot(28, "#111827")}${box(22, "width:60%;")}${line("#f59e0b", 3)}${slot(16, "#b45309")}${lines(5)}${slot(16, "#b45309")}${lines(5)}${slot(16, "#b45309")}${lines(4)}`,
    ]).replace("<td style=\"vertical-align:top;padding:0;\">", "<td style=\"vertical-align:top;padding:0;width:34%;\">"),
  },
  {
    id: "pro-invoice", title: "فاتورة", desc: "إداري نظيف بجدول بنود ومجاميع.",
    html: cols([img(70, "width:140px;"), `<div style="text-align:left;">${slot(26, "#0369a1", "border:none;text-align:left;")}${box(22, "width:70%;margin-right:auto;")}</div>`]) + line("#0369a1", 2) + cols([box(80), box(80)]) + table(["#", "الوصف", "الكمية", "السعر", "المجموع"], 7, "#0369a1", "#bae6fd", "#ffffff") + `<div style="width:45%;margin-right:auto;">${table(["", ""], 3, "#e0f2fe", "#bae6fd")}</div>` + box(50),
  },
  {
    id: "pro-minutes", title: "محضر اجتماع", desc: "إداري بجداول الحضور والقرارات.",
    setup: { border_style: "solid", border_color: "#475569" },
    html: slot(22, "#334155", "text-align:center;") + table(["", "", "", ""], 2, "#f1f5f9") + slot(15, "#475569") + table(["#", "", ""], 5) + slot(15, "#475569") + lines(5) + slot(15, "#475569") + table(["#", "", "", ""], 4) + sign(3, "#475569"),
  },
  {
    id: "pro-business-plan", title: "خطة عمل", desc: "شركات حديث بغلاف وأقسام مرقمة.",
    html: band("#111827", 220, img(110, "background:#1f2937;border-color:#4b5563;") + slot(28, "#f9fafb", "border-color:#4b5563;")) + [1, 2, 3].map((n) => `<div style="display:flex;gap:12px;align-items:flex-start;margin:12px 0;"><span style="min-width:34px;height:34px;border-radius:8px;background:#f97316;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-weight:700;">${n}</span><div style="flex:1;">${slot(16, "#111827")}${lines(3)}</div></div>`).join("") + table(["", "", "", ""], 4, "#ffedd5", "#fed7aa"),
  },
  {
    id: "pro-project-report", title: "تقرير مشروع", desc: "هندسي بشبكة وبطاقات مؤشرات.",
    html: `<div style="border:2px solid #0f172a;padding:10px;">${cols([slot(22, "#0f172a", "border:none;"), box(40, "width:120px;border-style:solid;border-color:#0f172a;")])}</div>` + cols([0, 1, 2, 3].map(() => `<div style="border:1.5px solid #0f172a;border-top:6px solid #2563eb;min-height:70px;"></div>`), 8) + slot(16, "#2563eb") + `<div style="height:160px;margin:10px 0;background-image:linear-gradient(#e2e8f0 1px,transparent 1px),linear-gradient(90deg,#e2e8f0 1px,transparent 1px);background-size:20px 20px;border:1px solid #cbd5e1;"></div>` + table(["", "", "", "", ""], 5, "#0f172a", "#334155", "#ffffff") + lines(3),
  },
  {
    id: "pro-lesson-note", title: "مذكرة تعليمية", desc: "تعليمي ملوّن بمربعات أهداف وملاحظات.",
    setup: { border_style: "solid", border_color: "#16a34a" },
    html: band("#dcfce7", 60, slot(22, "#166534", "border-color:#86efac;")) + cols([`<div style="border:2px solid #86efac;border-radius:12px;min-height:110px;"></div>`, `<div style="border:2px solid #fde68a;border-radius:12px;min-height:110px;"></div>`]) + slot(16, "#166534") + lines(7, "#bbf7d0") + `<div style="border:2px dashed #fbbf24;background:#fffbeb;border-radius:12px;min-height:90px;margin:12px 0;"></div>` + table(["", "", ""], 3, "#dcfce7", "#86efac"),
  },
  {
    id: "pro-certificate", title: "شهادة تقدير", desc: "فاخر أفقي بإطار ذهبي وختم.",
    setup: { orientation: "landscape", border_style: "double", border_color: "#b45309", border_width: 6, show_page_numbers: false },
    html: `<div style="border:1px solid #d97706;padding:26px;text-align:center;margin:8px;">${line("#d97706", 1, 4)}${slot(36, "#92400e", "text-align:center;border:none;")}${line("#d97706", 1, 4)}<div style="height:40px;"></div>${slot(28, "#111827", "text-align:center;width:60%;margin:0 auto;")}${lines(2, "#fde68a")}<div style="height:30px;"></div>${cols([`<div style="height:46px;border-bottom:1.5px solid #b45309;"></div>`, `<div style="width:90px;height:90px;border-radius:999px;border:3px double #b45309;margin:0 auto;"></div>`, `<div style="height:46px;border-bottom:1.5px solid #b45309;"></div>`], 30)}</div>`,
  },
  {
    id: "pro-book", title: "قالب كتاب", desc: "كلاسيكي بصفحة عنوان وفصل بهوامش واسعة.",
    setup: { size: "a5", margin: 18 },
    html: `<div style="height:120px;"></div>${slot(30, "#1c1917", "text-align:center;border:none;")}<div style="width:60px;border-top:2px solid #1c1917;margin:12px auto;"></div>${box(24, "width:50%;margin:0 auto;border-style:dotted;")}<div style="height:200px;"></div><div style="page-break-after:always;"></div>${slot(14, "#78716c", "text-align:center;border:none;letter-spacing:4px;")}${slot(24, "#1c1917", "text-align:center;")}${lines(12, "#f5f5f4")}`,
  },
  {
    id: "pro-magazine", title: "قالب مجلة", desc: "إبداعي بصورة غلاف وعمودين.",
    setup: { margin: 8 },
    html: cols([slot(34, "#be123c", "border-bottom:4px solid #be123c;"), box(30, "width:90px;border-style:solid;")]) + img(260, "border-radius:0;") + slot(22, "#111827") + cols([lines(10), `${img(120)}${lines(5)}`]) + line("#be123c", 3),
  },
  {
    id: "pro-notes", title: "قالب ملاحظات", desc: "Minimal بسطور هادئة وهامش جانبي.",
    setup: { margin: 12, show_page_numbers: true },
    html: cols([box(22, "border:none;border-bottom:1px solid #111827;"), box(22, "width:120px;border:none;border-bottom:1px solid #111827;")]) + `<div style="border-right:2px solid #fca5a5;padding-right:12px;">${lines(22, "#dbeafe")}</div>`,
  },
  {
    id: "pro-corporate", title: "قالب أعمال وشركات", desc: "فاخر داكن بترويسة سوداء ولمسات ذهبية.",
    html: band("#0b0b0f", 110, cols([img(70, "width:70px;background:#18181b;border-color:#a16207;"), slot(24, "#facc15", "border-color:#3f3f46;")])) + `<div style="border-top:2px solid #ca8a04;width:30%;margin:6px 0 14px;"></div>` + cols([`<div style="background:#18181b;min-height:80px;border-radius:6px;border-bottom:3px solid #ca8a04;"></div>`, `<div style="background:#18181b;min-height:80px;border-radius:6px;border-bottom:3px solid #ca8a04;"></div>`, `<div style="background:#18181b;min-height:80px;border-radius:6px;border-bottom:3px solid #ca8a04;"></div>`]) + slot(17, "#0b0b0f") + lines(6) + table(["", "", ""], 4, "#0b0b0f", "#3f3f46", "#facc15") + band("#0b0b0f", 40),
  },
];

export const PRO_TEMPLATES: TemplateDef[] = SPECS.map((spec) => ({
  id: spec.id,
  app: "eva",
  doc_type: "document",
  category: "احترافية",
  title: spec.title,
  desc: spec.desc,
  build: () => ({
    title: spec.title,
    doc_type: "document",
    app_type: "eva",
    content: JSON.stringify({ html: `<div dir="rtl">${spec.html}</div>` }),
    page_setup: JSON.stringify({ ...DEFAULT_PAGE_SETUP, ...(spec.setup ?? {}) }),
  }),
}));
