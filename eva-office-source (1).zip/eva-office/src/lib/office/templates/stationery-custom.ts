import type { PageBorderStyle } from "../types";
import type { StationerySpec } from "./stationery";

const CUSTOM_KEY = "eva-stationery-custom";

export interface StationeryDesign {
  colors: Record<string, string>; // original hex -> new hex
  font: string;
  border_style: PageBorderStyle;
  border_color: string;
  border_width: number;
}

/** Unique hex colours used by a template, most frequent first. */
export function templateColors(html: string, max = 8): string[] {
  const counts = new Map<string, number>();
  for (const m of html.matchAll(/(?:#|%23)[0-9a-fA-F]{6}\b/g)) {
    const c = `#${m[0].slice(-6).toLowerCase()}`;
    counts.set(c, (counts.get(c) ?? 0) + 1);
  }
  return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, max).map(([c]) => c);
}

export function applyDesign(spec: StationerySpec, d: StationeryDesign): StationerySpec {
  // `%23` is how colours appear inside inline SVG data-URIs (gold templates).
  let html = spec.html.replace(/(#|%23)([0-9a-fA-F]{6})\b/g, (all, pre: string, hex: string) => {
    const next = d.colors[`#${hex.toLowerCase()}`];
    return next ? (pre === "#" ? next : `%23${next.slice(1)}`) : all;
  });
  if (d.font) html = `<div style="font-family:'${d.font.replace(/'/g, "")}',sans-serif;">${html}</div>`;
  return {
    ...spec,
    html,
    setup: { ...(spec.setup ?? {}), border_style: d.border_style, border_color: d.border_color, border_width: d.border_width },
  };
}

export function loadCustom(): StationerySpec[] {
  try {
    const list = JSON.parse(localStorage.getItem(CUSTOM_KEY) ?? "[]");
    return Array.isArray(list) ? list : [];
  } catch { return []; }
}

export function saveCustom(list: StationerySpec[]) {
  localStorage.setItem(CUSTOM_KEY, JSON.stringify(list));
}
