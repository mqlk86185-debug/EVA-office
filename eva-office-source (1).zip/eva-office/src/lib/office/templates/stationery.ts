import { DEFAULT_PAGE_SETUP, type PageSetup } from "../types";
import type { TemplatePayload } from "./build";

/**
 * 15 professional stationery layouts with no text at all: only frames,
 * bands, corners, lines and empty tables. Every area stays editable.
 */

const L = (n: number, c = "#e2e8f0", h = 30) =>
  Array.from({ length: n }, () => `<p style="border-bottom:1px solid ${c};margin:0;min-height:${h}px;"><br></p>`).join("");
const gap = (h: number) => `<p style="min-height:${h}px;margin:0;"><br></p>`;
const rule = (c: string, w = 1, m = 10, width = "100%") => `<div style="border-top:${w}px solid ${c};margin:${m}px auto;width:${width};"></div>`;
const bar = (bg: string, h: number, extra = "") => `<div style="background:${bg};height:${h}px;margin:0;${extra}"></div>`;
const tbl = (cols: number, rows: number, head: string, border: string) => {
  const th = Array.from({ length: cols }, () => `<th style="background:${head};border:1px solid ${border};height:22px;padding:4px;"><br></th>`).join("");
  const tr = Array.from({ length: rows }, () => `<tr>${Array.from({ length: cols }, () => `<td style="border:1px solid ${border};height:24px;padding:4px;"><br></td>`).join("")}</tr>`).join("");
  return `<table style="width:100%;border-collapse:collapse;margin:10px 0;"><tr>${th}</tr>${tr}</table>`;
};
const row = (parts: string[], sp = 14) =>
  `<table style="width:100%;border-collapse:separate;border-spacing:${sp}px 0;margin:8px 0;"><tr>${parts.map((p) => `<td style="vertical-align:top;padding:0;">${p}</td>`).join("")}</tr></table>`;
const corner = (c1: string, c2: string, side: "right" | "left") =>
  `<div style="height:46px;background:linear-gradient(${side === "right" ? "225deg" : "135deg"},${c1} 0 18%,${c2} 18% 22%,transparent 22%);margin:0;"></div>`;
const circle = (d: number, bg: string, extra = "") => `<div style="width:${d}px;height:${d}px;border-radius:999px;background:${bg};margin:8px auto;${extra}"></div>`;
const box = (h: number, style: string) => `<div style="min-height:${h}px;margin:10px 0;${style}"><br></div>`;
const imgSlot = (h: number) => `<div style="height:${h}px;background:linear-gradient(160deg,#e5e7eb,#cbd5e1);border-radius:4px;margin:6px 0;"></div>`;
const frame = (inner: string, style: string) => `<div style="${style}padding:18px;min-height:900px;">${inner}</div>`;

export interface StationerySpec { id: string; name: string; accent: string; html: string; setup?: Partial<PageSetup> }

export const STATIONERY: StationerySpec[] = [
  { id: "st-gold-laurel", name: "ذهبي رسمي", accent: "#b08d3c",
    html: corner("#1e3a5f", "#b08d3c", "right") + circle(44, "transparent", "border:3px double #1e3a5f;") + rule("#1e3a5f", 1, 8) + frame(L(18, "#f1f5f9"), "border-right:1.5px solid #b08d3c;border-left:1.5px solid #b08d3c;min-height:760px;") + rule("#1e3a5f", 1, 10) + row([box(30, "border-bottom:1px solid #cbd5e1;"), box(30, "border-bottom:1px solid #cbd5e1;")]) + corner("#1e3a5f", "#b08d3c", "left") },
  { id: "st-blue-city", name: "أزرق مؤسسي", accent: "#2563eb",
    html: bar("linear-gradient(100deg,#1e3a8a 0 55%,#3b82f6 55% 62%,#bfdbfe 62% 66%,#1e3a8a 66%)", 60) + rule("#1e3a8a", 1, 14) + frame(L(20, "#eef2ff"), "border:1px solid #93c5fd;min-height:780px;") + bar("#1e3a8a", 50, "border-top:4px solid #3b82f6;") },
  { id: "st-graduation", name: "إطار أكاديمي", accent: "#1e3a5f",
    html: frame(circle(56, "#1e3a5f", "border-radius:8px 8px 50% 50%;") + bar("#1e3a5f", 34, "margin:10px 20px;clip-path:polygon(0 0,100% 0,96% 50%,100% 100%,0 100%,4% 50%);") + L(18, "#f1f5f9") + rule("#1e3a5f", 1, 30, "60%"), "border:4px double #1e3a5f;outline:1px solid #94a3b8;outline-offset:-10px;") },
  { id: "st-teal-report", name: "تقرير بياني", accent: "#0f766e",
    html: bar("linear-gradient(110deg,#115e59 0 45%,#14b8a6 45% 52%,#e2e8f0 52%)", 50) + box(40, "background:#e5e7eb;") + row([box(260, "border:1px solid #94a3b8;"), tbl(3, 8, "#115e59", "#94a3b8") + circle(120, "conic-gradient(#115e59 0 35%,#5eead4 35% 60%,#94a3b8 60%)")]) + L(5) + bar("linear-gradient(110deg,#115e59 0 80%,#5eead4 80%)", 36) },
  { id: "st-invoice", name: "فاتورة نظيفة", accent: "#2563eb",
    html: row([circle(50, "#1e3a8a", "margin:0;"), box(24, "background:#1e3a8a;border-radius:4px;") + box(18, "background:#e5e7eb;") + box(18, "background:#e5e7eb;")]) + L(3) + tbl(5, 12, "#1e3a8a", "#94a3b8") + row(["", tbl(1, 3, "#1e3a8a", "#94a3b8")]) + gap(60) + bar("linear-gradient(90deg,#1d4ed8,#60a5fa)", 34, "border-radius:0 0 0 40px;") },
  { id: "st-team", name: "محضر فريق", accent: "#b08d3c",
    html: corner("#1f2937", "#b08d3c", "right") + circle(40, "#1f2937") + rule("#cbd5e1", 1, 8, "40%") + tbl(4, 7, "#1f2937", "#d6c49a") + Array.from({ length: 6 }, () => `<p style="border-bottom:1px solid #e2e8f0;margin:0;min-height:30px;padding-right:20px;background:radial-gradient(circle at 98% 50%,transparent 4px,#1f2937 4px 6px,transparent 6px);"><br></p>`).join("") + gap(30) + row([box(30, "border-bottom:1px solid #94a3b8;"), box(30, "border-bottom:1px solid #94a3b8;")]) + corner("#1f2937", "#b08d3c", "left") },
  { id: "st-green-sections", name: "أقسام خضراء", accent: "#15803d",
    html: corner("#15803d", "#86efac", "left") + rule("#15803d", 1, 10) + box(130, "border:1px solid #86efac;border-top:14px solid #86efac;") + row([box(130, "border:1px solid #86efac;border-top:14px solid #86efac;"), box(130, "border:1px solid #86efac;border-top:14px solid #86efac;")]) + box(160, "border:1px solid #86efac;border-top:14px solid #86efac;") + corner("#86efac", "#15803d", "right") },
  { id: "st-blue-wave", name: "دفتر موجي", accent: "#1d4ed8",
    html: bar("linear-gradient(180deg,#1d4ed8,#60a5fa)", 60, "border-radius:0 0 60% 0;") + `<div style="border-right:6px dotted #1d4ed8;padding-right:16px;">${L(24, "#dbeafe")}</div>` + bar("linear-gradient(0deg,#1d4ed8,#60a5fa)", 50, "border-radius:60% 0 0 0;") },
  { id: "st-newsletter", name: "نشرة صحفية", accent: "#dc2626",
    html: bar("#1f2937", 46, "border-bottom:4px solid #dc2626;") + row([imgSlot(180), L(6, "#cbd5e1", 26)]) + rule("#dc2626", 3, 8) + row([L(9, "#cbd5e1", 26), imgSlot(110)]) + row([imgSlot(100), L(4, "#cbd5e1", 26)]) + bar("#1f2937", 40, "border-top:4px solid #dc2626;") },
  { id: "st-classic-book", name: "ورق كلاسيكي", accent: "#a16207",
    html: frame(circle(40, "#a16207", "border-radius:4px;") + rule("#a16207", 1, 10, "50%") + row([L(22, "#e7dcc0"), L(22, "#e7dcc0")], 24) + rule("#a16207", 1, 16, "30%"), "background:#fbf7ec;border:2px solid #c9a75a;outline:1px solid #c9a75a;outline-offset:-8px;") },
  { id: "st-certificate", name: "شهادة تقدير", accent: "#b08d3c",
    html: frame(circle(70, "radial-gradient(#1e3a5f 55%,#b08d3c 56% 62%,#1e3a5f 63%)") + gap(500) + row([box(30, "border-bottom:1.5px solid #b08d3c;"), circle(46, "radial-gradient(#d4a64a,#a16207)"), box(30, "border-bottom:1.5px solid #b08d3c;")]), "border:3px solid #b08d3c;outline:1px solid #b08d3c;outline-offset:-10px;") },
  { id: "st-pastel", name: "باستيل ناعم", accent: "#f472b6",
    html: bar("linear-gradient(90deg,#fbcfe8,#e0e7ff)", 30) + frame(gap(760), "border:1px solid #c7d2fe;border-right:6px solid #f9a8d4;min-height:780px;") + bar("linear-gradient(90deg,#e0e7ff,#93c5fd)", 24) },
  { id: "st-resume", name: "سيرة عصرية", accent: "#334155",
    html: bar("linear-gradient(100deg,#334155 0 70%,#64748b 70%)", 110) + row([[1, 2, 3, 4].map(() => box(18, "background:#475569;width:70%;") + L(3, "#e2e8f0", 22)).join(""), [1, 2, 3, 4, 5].map(() => `<div style="border-right:2px solid #475569;padding-right:12px;">${box(16, "background:#94a3b8;width:40%;")}${L(3, "#e2e8f0", 22)}</div>`).join("")]) },
  { id: "st-gradient-wave", name: "موجة ملونة", accent: "#06b6d4",
    html: bar("linear-gradient(120deg,#2563eb,#8b5cf6 40%,#14b8a6 70%,transparent 70%)", 120, "border-radius:0 0 100% 0;") + gap(640) + bar("linear-gradient(300deg,#14b8a6,#2563eb 40%,#a78bfa 70%,transparent 70%)", 120, "border-radius:100% 0 0 0;") },
  { id: "st-black-gold", name: "أسود ذهبي", accent: "#b08d3c",
    html: frame(gap(820), "background:#111111;border:1px solid #b08d3c;outline:1px solid #b08d3c;outline-offset:-14px;"), setup: { border_style: "none" } },
];

export function stationeryPayload(spec: StationerySpec, title: string): TemplatePayload {
  return {
    title,
    doc_type: "document",
    app_type: "eva",
    content: JSON.stringify({ html: `<div dir="rtl">${spec.html}</div>` }),
    page_setup: JSON.stringify({ ...DEFAULT_PAGE_SETUP, margin: 8, ...(spec.setup ?? {}) }),
  };
}
