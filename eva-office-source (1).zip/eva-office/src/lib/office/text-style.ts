/**
 * Shared text-appearance presets: font families, sizes and colour palettes.
 * Used by the EVA document toolbar, the GILOX sheet toolbar and the PDF
 * annotation style bar so every app offers the same choices.
 */

export const TEXT_FONTS = [
  { value: "IBM Plex Sans Arabic", label: "IBM Plex عربي" },
  { value: "Readex Pro", label: "ريدكس" },
  { value: "Amiri", label: "أميري" },
  { value: "Cairo", label: "القاهرة" },
  { value: "Tahoma", label: "Tahoma" },
  { value: "Georgia", label: "Georgia" },
  { value: "Courier New", label: "Courier" },
];

export const TEXT_SIZES = [10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 40, 48];

/** Quick text colours (dark → vivid), tuned for readable print. */
export const TEXT_COLORS = [
  "#111827",
  "#374151",
  "#7f1d1d",
  "#dc2626",
  "#c2410c",
  "#b45309",
  "#15803d",
  "#0f766e",
  "#1d4ed8",
  "#4f46e5",
  "#7e22ce",
  "#be185d",
];

/** Quick background / highlight colours, light enough to keep text legible. */
export const BG_COLORS = [
  "transparent",
  "#ffffff",
  "#fef9c3",
  "#fde68a",
  "#fecaca",
  "#fed7aa",
  "#d9f99d",
  "#bbf7d0",
  "#a5f3fc",
  "#bfdbfe",
  "#ddd6fe",
  "#fbcfe8",
];

export function fontStack(family?: string | null): string | undefined {
  return family ? `'${family}', 'IBM Plex Sans Arabic', Tahoma, sans-serif` : undefined;
}
