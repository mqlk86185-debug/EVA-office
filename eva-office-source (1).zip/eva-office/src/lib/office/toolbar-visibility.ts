"use client";

import { useCallback, useEffect, useState } from "react";

const STORAGE_KEY = "eva-toolbar-hidden-tools";

/**
 * Remembers which toolbar tools the user chose to hide, so the "smart
 * toolbar" only shows what each person actually uses. Persisted per-browser
 * in localStorage — it's a personal display preference, not document data.
 */
export function useToolbarVisibility() {
  const [hidden, setHidden] = useState<Set<string>>(() => new Set());

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setHidden(new Set(JSON.parse(raw) as string[]));
    } catch (err) {
      console.error("[toolbar-visibility] failed to read preferences:", err);
    }
  }, []);

  const persist = useCallback((next: Set<string>) => {
    setHidden(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify([...next]));
    } catch (err) {
      console.error("[toolbar-visibility] failed to save preferences:", err);
    }
  }, []);

  const toggle = useCallback(
    (id: string) => {
      const next = new Set(hidden);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      persist(next);
    },
    [hidden, persist]
  );

  const showAll = useCallback(() => persist(new Set()), [persist]);
  const isVisible = useCallback((id: string) => !hidden.has(id), [hidden]);

  return { isVisible, toggle, showAll, hiddenCount: hidden.size };
}
