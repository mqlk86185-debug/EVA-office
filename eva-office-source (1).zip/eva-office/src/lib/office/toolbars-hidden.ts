"use client";

import { useCallback, useEffect, useState } from "react";

const STORAGE_KEY = "eva-all-toolbars-hidden";

/** Hides every editing toolbar at once; a single restore button always stays visible. */
export function useToolbarsHidden() {
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    try {
      setHidden(localStorage.getItem(STORAGE_KEY) === "1");
    } catch {
      /* ignore */
    }
  }, []);

  const setAndSave = useCallback((next: boolean) => {
    setHidden(next);
    try {
      localStorage.setItem(STORAGE_KEY, next ? "1" : "0");
    } catch {
      /* ignore */
    }
  }, []);

  return { hidden, setHidden: setAndSave, toggle: () => setAndSave(!hidden) };
}
