/**
 * Shared EVA Office domain types.
 * Safe to import from client components (no SDK, no secrets).
 */

export type AppType = "eva" | "pdf" | "gilox" | "novel";
export type DocType = "document" | "exam" | "spreadsheet" | "pdf" | "note";
export type YesNo = "yes" | "no";

export type PageSize = "a4" | "a5" | "letter" | "custom";
export type Orientation = "portrait" | "landscape";

/** Decorative frame drawn around the whole page (editor, preview and PDF). */
export type PageBorderStyle =
  | "none"
  | "solid"
  | "thick"
  | "double"
  | "classic"
  | "dashed"
  | "dotted"
  | "rounded"
  | "shadow"
  | "corners";

export const PAGE_BORDER_STYLES: { key: PageBorderStyle; label: string }[] = [
  { key: "none", label: "بدون إطار" },
  { key: "solid", label: "خط مفرد" },
  { key: "thick", label: "خط عريض" },
  { key: "double", label: "خط مزدوج" },
  { key: "classic", label: "كلاسيكي" },
  { key: "dashed", label: "متقطع" },
  { key: "dotted", label: "منقّط" },
  { key: "rounded", label: "حواف مستديرة" },
  { key: "shadow", label: "ظل بارز" },
  { key: "corners", label: "زوايا فقط" },
];

export interface PageSetup {
  size: PageSize;
  orientation: Orientation;
  margin: number; // millimetres
  header: string;
  footer: string;
  show_page_numbers: boolean;
  border_style: PageBorderStyle;
  border_color: string;
  border_width: number; // px
  border_gap: number; // millimetres between the page edge and the frame
  /** Smart pagination: keep headings with their text, avoid orphan/widow lines. */
  smart_split?: boolean;
  /** Never leave a table header alone at the bottom of a page. */
  keep_table_header?: boolean;
  /** Custom page width in millimetres (used when size === "custom"). */
  custom_w?: number;
  /** Custom page height in millimetres (used when size === "custom"). */
  custom_h?: number;
  /** Page background colour. */
  page_color?: string;
}

export const DEFAULT_PAGE_SETUP: PageSetup = {
  size: "a4",
  orientation: "portrait",
  margin: 10,
  header: "",
  footer: "",
  show_page_numbers: true,
  border_style: "none",
  border_color: "#334155",
  border_width: 2,
  border_gap: 8,
  smart_split: true,
  keep_table_header: true,
};

/** Page dimensions in millimetres, portrait orientation. */
export const PAGE_DIMENSIONS: Record<PageSize, { w: number; h: number; label: string }> = {
  a4: { w: 210, h: 297, label: "A4" },
  a5: { w: 148, h: 210, label: "A5" },
  letter: { w: 216, h: 279, label: "Letter" },
  custom: { w: 210, h: 297, label: "مخصص" },
};

/** Allowed range for a custom page, in millimetres. */
export const CUSTOM_PAGE_MIN = 50;
export const CUSTOM_PAGE_MAX = 1200;

function clampMm(value: number | undefined, fallback: number): number {
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return fallback;
  return Math.min(CUSTOM_PAGE_MAX, Math.max(CUSTOM_PAGE_MIN, Math.round(n)));
}

function baseDims(setup: PageSetup): { w: number; h: number } {
  if (setup.size === "custom") {
    return { w: clampMm(setup.custom_w, 210), h: clampMm(setup.custom_h, 297) };
  }
  const d = PAGE_DIMENSIONS[setup.size] ?? PAGE_DIMENSIONS.a4;
  return { w: d.w, h: d.h };
}

export function pageWidthMm(setup: PageSetup): number {
  const d = baseDims(setup);
  return setup.orientation === "landscape" ? d.h : d.w;
}

export function pageHeightMm(setup: PageSetup): number {
  const d = baseDims(setup);
  return setup.orientation === "landscape" ? d.w : d.h;
}

export interface TotalumFile {
  name: string;
  url: string;
}

export interface OfficeFile {
  _id: string;
  title: string;
  app_type: AppType;
  doc_type: DocType;
  content?: string | null;
  page_setup?: string | null;
  pdf_file?: TotalumFile | null;
  thumbnail?: TotalumFile | null;
  is_favorite?: YesNo;
  is_trashed?: YesNo;
  last_opened_at?: string | null;
  page_count?: number | null;
  last_page_read?: number | null;
  accent_color?: string | null;
  folder?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface OfficeFolder {
  _id: string;
  name: string;
  color?: string | null;
  createdAt: string;
}

/* ---------------- EVA document ---------------- */

export interface DocumentContent {
  html: string;
}

/* ---------------- EVA exam ---------------- */

export type QuestionType =
  | "multiple_choice"
  | "true_false"
  | "fill_blank"
  | "short_answer"
  | "essay";

export const QUESTION_TYPE_LABELS: Record<QuestionType, string> = {
  multiple_choice: "اختيار من متعدد",
  true_false: "صح أو خطأ",
  fill_blank: "أكمل الفراغ",
  short_answer: "سؤال قصير",
  essay: "سؤال مقالي",
};

export interface ExamQuestion {
  _id: string;
  question_text: string;
  question_type: QuestionType;
  choices?: string | null; // JSON string array
  correct_answer?: string | null;
  marks?: number | null;
  answer_lines?: number | null;
  section_title?: string | null;
  order_index?: number | null;
  office_file?: string | null;
}

export interface ExamMeta {
  exam_title: string;
  subject: string;
  school: string;
  student_name: string;
  grade: string;
  class_section: string;
  exam_date: string;
  duration: string;
  total_marks: string;
  instructions: string;
}

export const DEFAULT_EXAM_META: ExamMeta = {
  exam_title: "",
  subject: "",
  school: "",
  student_name: "",
  grade: "",
  class_section: "",
  exam_date: "",
  duration: "",
  total_marks: "",
  instructions: "",
};

/* ---------------- GILOX spreadsheet ---------------- */

export interface CellStyle {
  b?: boolean; // bold
  i?: boolean; // italic
  u?: boolean; // underline
  st?: boolean; // strike-through
  va?: "top" | "middle" | "bottom"; // vertical alignment
  fs?: number; // font size (px)
  ff?: string; // font family
  c?: string; // text colour
  bg?: string; // background colour
  a?: "right" | "center" | "left"; // horizontal alignment
  w?: boolean; // wrap text
  bd?: boolean; // bordered
  fmt?: "general" | "number" | "currency" | "percent" | "date" | "time";
  dec?: number; // decimals
}

export interface Cell {
  v?: string; // raw entered value ("=SUM(A1:A5)" for formulas)
  s?: CellStyle;
}

export type ChartKind = "bar" | "line" | "pie";

export interface ChartDef {
  id: string;
  kind: ChartKind;
  title: string;
  range: string; // e.g. "A1:B6"
  height: number;
}

export interface SheetContent {
  rows: number;
  cols: number;
  cells: Record<string, Cell>; // key = "A1"
  col_widths: Record<string, number>;
  row_heights: Record<string, number>;
  merges: string[]; // "A1:B2"
  charts: ChartDef[];
  frozen_header: boolean;
}

export const DEFAULT_SHEET: SheetContent = {
  rows: 40,
  cols: 12,
  cells: {},
  col_widths: {},
  row_heights: {},
  merges: [],
  charts: [],
  frozen_header: true,
};

/* ---------------- PDF annotations ---------------- */

export type AnnotationType = "highlight" | "note" | "draw" | "arrow" | "textbox";

export interface PdfAnnotation {
  _id: string;
  label?: string | null;
  annotation_type: AnnotationType;
  page_number: number;
  color?: string | null;
  note_text?: string | null;
  geometry?: string | null; // JSON
  office_file?: string | null;
}

export interface AnnotationGeometry {
  x: number; // 0..1 relative to page width
  y: number; // 0..1 relative to page height
  w?: number;
  h?: number;
  points?: { x: number; y: number }[];
  stroke?: number;
  ff?: string; // font family (notes / text boxes)
  fs?: number; // font size in px
  tc?: string; // text colour
  bg?: string; // background colour
}

/* ---------------- helpers ---------------- */

export const APP_META: Record<
  AppType,
  { name: string; tagline: string; color: string; softClass: string; textClass: string; href: string }
> = {
  eva: {
    name: "EVA",
    tagline: "محرر المستندات والأسئلة",
    color: "var(--eva)",
    softClass: "bg-eva-soft",
    textClass: "text-eva",
    href: "/eva",
  },
  pdf: {
    name: "PDF",
    tagline: "قارئ وإدارة ملفات PDF",
    color: "var(--pdfapp)",
    softClass: "bg-pdfapp-soft",
    textClass: "text-pdfapp",
    href: "/pdf",
  },
  gilox: {
    name: "GILOX",
    tagline: "الجداول والبيانات والحسابات",
    color: "var(--gilox)",
    softClass: "bg-gilox-soft",
    textClass: "text-gilox",
    href: "/gilox",
  },
  novel: {
    name: "NOVEL",
    tagline: "مفكرة وحافظة نصوص",
    color: "var(--novel)",
    softClass: "bg-novel-soft",
    textClass: "text-novel",
    href: "/novel",
  },
};

export const DOC_TYPE_LABELS: Record<DocType, string> = {
  document: "مستند",
  exam: "اختبار",
  spreadsheet: "جدول بيانات",
  pdf: "ملف PDF",
  note: "مذكرة",
};

export function fileHref(file: Pick<OfficeFile, "_id" | "doc_type">): string {
  switch (file.doc_type) {
    case "exam":
      return `/eva/exam/${file._id}`;
    case "spreadsheet":
      return `/gilox/${file._id}`;
    case "pdf":
      return `/pdf/${file._id}`;
    case "note":
      return `/novel/${file._id}`;
    default:
      return `/eva/${file._id}`;
  }
}

export function safeJson<T>(raw: unknown, fallback: T): T {
  if (raw == null) return fallback;
  if (typeof raw === "object") return raw as T;
  if (typeof raw !== "string" || raw.trim() === "") return fallback;
  try {
    return { ...fallback, ...(JSON.parse(raw) as object) } as T;
  } catch {
    return fallback;
  }
}

export function formatRelativeArabic(iso?: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  const diff = Date.now() - d.getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "الآن";
  if (m < 60) return `قبل ${m} دقيقة`;
  const h = Math.floor(m / 60);
  if (h < 24) return `قبل ${h} ساعة`;
  const days = Math.floor(h / 24);
  if (days === 1) return "أمس";
  if (days < 30) return `قبل ${days} يوم`;
  return d.toLocaleDateString("ar", { year: "numeric", month: "long", day: "numeric" });
}
