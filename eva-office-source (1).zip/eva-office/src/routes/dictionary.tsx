import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { useDeferredValue, useMemo, useState } from "react";
import { BookOpen, ChevronRight, ChevronLeft, Search, X, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "@/components/office/Link";
import { BottomNav } from "@/components/office/BottomNav";
import { ThemeToggle } from "@/components/office/ThemeToggle";
import { loadDictionary, searchEntries } from "@/lib/dictionary/search";

const dictionaryQuery = queryOptions({ queryKey: ["offline-dictionary"], queryFn: loadDictionary, staleTime: Infinity, gcTime: Infinity });
const PAGE_SIZE = 40;

export const Route = createFileRoute("/dictionary")({
  ssr: false,
  loader: ({ context }) => context.queryClient.ensureQueryData(dictionaryQuery),
  pendingComponent: () => <p className="p-8 text-center text-muted-foreground" role="status">جارٍ فتح القاموس…</p>,
  head: () => ({ meta: [
    { title: "مُعجمي — قاموس EVA Office" },
    { name: "description", content: "قاموس عربي إنجليزي يضم 29,899 كلمة ومعانيها وأمثلتها، يعمل دون إنترنت داخل EVA Office." },
    { property: "og:title", content: "مُعجمي — قاموس EVA Office" },
    { property: "og:description", content: "ابحث بالعربية والإنجليزية في 29,899 كلمة ومعانيها وأمثلتها دون إنترنت." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: Dictionary,
});

function Dictionary() {
  const { data: entries } = useSuspenseQuery(dictionaryQuery);
  const [term, setTerm] = useState("");
  const [category, setCategory] = useState("all");
  const [page, setPage] = useState(0);
  const deferredTerm = useDeferredValue(term);
  const categories = useMemo(() => [...new Set(entries.map((entry) => entry.categoryAr).filter((value): value is string => Boolean(value)))].sort((a, b) => a.localeCompare(b, "ar")), [entries]);
  const results = useMemo(() => searchEntries(entries, deferredTerm, category), [entries, deferredTerm, category]);
  const pageCount = Math.ceil(results.length / PAGE_SIZE);
  const currentPage = Math.min(page, Math.max(0, pageCount - 1));
  const visible = results.slice(currentPage * PAGE_SIZE, (currentPage + 1) * PAGE_SIZE);

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-4xl flex-col px-4 pt-4">
      <header className="flex items-center gap-3 border-b border-border pb-5">
        <Button asChild variant="ghost" size="icon"><Link href="/" aria-label="رجوع للرئيسية"><ChevronRight /></Link></Button>
        <BookOpen className="size-8 shrink-0 text-gilox" />
        <div className="min-w-0 flex-1"><h1 className="font-display text-2xl font-semibold">مُعجمي</h1><p className="mt-1 text-sm text-muted-foreground">عربي · English <span className="mx-2">/</span> {entries.length.toLocaleString("en-US")} كلمة</p></div>
        <ThemeToggle />
      </header>
      <div className="sticky top-0 z-10 space-y-3 bg-background py-5">
        <div className="relative">
          <Search className="pointer-events-none absolute right-3 top-3.5 size-5 text-muted-foreground" />
          <Input aria-label="بحث في القاموس" value={term} maxLength={200} onChange={(event) => { setTerm(event.target.value); setPage(0); }} placeholder="ابحث بالعربية أو الإنجليزية…" className="h-12 pr-11 pl-12" />
          {term && <Button size="icon" variant="ghost" className="absolute left-1.5 top-1.5" aria-label="مسح البحث" onClick={() => { setTerm(""); setPage(0); }}><X /></Button>}
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <select aria-label="تصنيف الكلمات" value={category} onChange={(event) => { setCategory(event.target.value); setPage(0); }} className="h-10 max-w-full rounded-md border border-input bg-background px-3 text-sm text-foreground">
            <option value="all">جميع التصنيفات</option>{categories.map((value) => <option key={value} value={value}>{value}</option>)}
          </select>
          <p role="status" className="text-sm text-muted-foreground">{results.length.toLocaleString("en-US")} نتيجة</p>
        </div>
      </div>
      <section aria-label="كلمات القاموس" className="flex-1">
        {visible.length === 0 ? <p className="py-16 text-center text-muted-foreground">لا توجد كلمات مطابقة</p> :
          <div className="divide-y divide-border border-y border-border">{visible.map((entry, index) => (
            <details key={`${entry.id}-${index}`} className="group py-1">
              <summary className="flex cursor-pointer list-none items-center gap-3 rounded-md px-2 py-4 hover:bg-accent">
                <div className="min-w-0 flex-1"><h2 dir="ltr" className="break-words text-left text-lg font-semibold">{entry.en}</h2><p className="mt-1 break-words text-base">{entry.ar}</p></div>
                <Button size="icon" variant="ghost" aria-label={`نطق ${entry.en}`} onClick={(event) => { event.preventDefault(); speak(entry.en); }}><Volume2 /></Button><span className="shrink-0 text-xs text-muted-foreground">{entry.level}</span><ChevronLeft className="size-4 shrink-0 text-muted-foreground transition-transform group-open:-rotate-90" />
              </summary>
              <div className="space-y-3 px-2 pb-5 text-sm">
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-muted-foreground"><span>{entry.partOfSpeechAr}</span><span>{entry.categoryAr}</span><span dir="ltr">{entry.phonetic}</span></div>
                {entry.exampleEn && <p dir="ltr" className="flex items-start gap-2 break-words text-left leading-relaxed"><Button size="icon" variant="ghost" className="size-7 shrink-0" aria-label="نطق المثال" onClick={() => { if (entry.exampleEn) speak(entry.exampleEn); }}><Volume2 /></Button>{entry.exampleEn}</p>}
                {entry.exampleAr && <p className="break-words leading-relaxed">{entry.exampleAr}</p>}
                {Boolean(entry.synonyms?.length) && <p className="break-words"><span className="text-muted-foreground">مرادفات: </span><span dir="ltr">{entry.synonyms?.join(" · ")}</span></p>}
              </div>
            </details>
          ))}</div>}
      </section>
      {pageCount > 0 && <nav aria-label="صفحات القاموس" className="flex items-center justify-center gap-5 py-6">
        <Button variant="outline" size="icon" aria-label="الصفحة السابقة" disabled={currentPage === 0} onClick={() => { setPage(currentPage - 1); window.scrollTo({ top: 0 }); }}><ChevronRight /></Button>
        <span className="min-w-24 text-center text-sm tabular-nums">{currentPage + 1} / {pageCount}</span>
        <Button variant="outline" size="icon" aria-label="الصفحة التالية" disabled={currentPage + 1 >= pageCount} onClick={() => { setPage(currentPage + 1); window.scrollTo({ top: 0 }); }}><ChevronLeft /></Button>
      </nav>}
      <BottomNav />
    </div>
  );
}
function speak(text: string) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) { alert("النطق غير مدعوم على هذا الجهاز"); return; }
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = "en-US"; u.rate = 0.9;
  const voice = window.speechSynthesis.getVoices().find((v) => v.lang.startsWith("en"));
  if (voice) u.voice = voice;
  window.speechSynthesis.speak(u);
}
