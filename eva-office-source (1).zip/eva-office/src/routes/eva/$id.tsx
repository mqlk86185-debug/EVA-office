import { SlidersHorizontal } from "lucide-react";
import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "@/lib/office/nav";
import { toast } from "sonner";
import { Search, X, ChevronUp, ChevronDown, Replace, MoreVertical, FileDown, Settings2, ZoomIn, ZoomOut } from "lucide-react";
import { EditorShell, type SaveState } from "@/components/office/EditorShell";
import { DocToolbar } from "@/components/office/eva/DocToolbar";
import { PageSetupSheet } from "@/components/office/PageSetupSheet";
import { PreviewDialog } from "@/components/office/PreviewDialog";
import { DownloadPdfMenuItem } from "@/components/office/DownloadPdfMenuItem";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { getFile, updateFile } from "@/lib/office/client";
import * as ed from "@/lib/office/editor-commands";
import { useDocumentZoom } from "@/hooks/use-document-zoom";
import { DocumentViewControls } from "@/components/office/DocumentViewControls";
import { MM_TO_PX, contentBoxMm, pageFrameCss } from "@/lib/office/render";
import {
  DEFAULT_PAGE_SETUP,
  pageHeightMm,
  pageWidthMm,
  safeJson,
  type OfficeFile,
  type PageSetup,
} from "@/lib/office/types";

function DocumentEditorPage() {
  const params = useParams<{ id: string }>();
  const fileId = params.id;

  const editorRef = useRef<HTMLDivElement>(null);
  const sheetRef = useRef<HTMLDivElement>(null);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const dirtyRef = useRef(false);
  const selectedFloatRef = useRef<HTMLElement | null>(null);
  const floatGestureRef = useRef<{
    el: HTMLElement; mode: "move" | "resize"; dir: string; startX: number; startY: number;
    x: number; y: number; width: number; height: number;
  } | null>(null);

  const [shapeSel, setShapeSel] = useState<HTMLElement | null>(null);
  const [shapeColorVal, setShapeColorVal] = useState("#6366f1");
  const [file, setFile] = useState<OfficeFile | null>(null);
  const [title, setTitle] = useState("");
  const [setup, setSetup] = useState<PageSetup>(DEFAULT_PAGE_SETUP);
  const [saveState, setSaveState] = useState<SaveState>("idle");
  const [setupOpen, setSetupOpen] = useState(false);
  const [setupFocus, setSetupFocus] = useState<"border" | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);

  const [findOpen, setFindOpen] = useState(false);
  const [findTerm, setFindTerm] = useState("");
  const [replaceTerm, setReplaceTerm] = useState("");
  const [hitCount, setHitCount] = useState(0);
  const [hitIndex, setHitIndex] = useState(0);

  const [cellSelectMode, setCellSelectMode] = useState(false);
  const [selectedCells, setSelectedCells] = useState<HTMLTableCellElement[]>([]);
  const [pageCount, setPageCount] = useState(1);
  const [toolsMenuOpen, setToolsMenuOpen] = useState(false);
  const [freeTextMode, setFreeTextMode] = useState(false);

  /* ------------------------- load ------------------------- */
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await getFile(fileId);
        if (cancelled) return;
        setFile(data);
        setTitle(data.title);
        setSetup(safeJson<PageSetup>(data.page_setup, DEFAULT_PAGE_SETUP));
        const content = safeJson<{ html: string }>(data.content, { html: "" });
        if (editorRef.current) editorRef.current.innerHTML = content.html || "<p><br></p>";
        console.log("[EVA] document loaded:", data._id);
        void updateFile(fileId, { last_opened_at: new Date().toISOString() }).catch((err) =>
          console.error("[EVA] failed to stamp last_opened_at:", err)
        );
      } catch (err) {
        console.error("[EVA] failed to load document:", err);
        toast.error("تعذّر فتح المستند", { description: (err as Error).message });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [fileId]);

  /* ------------------------- autosave ------------------------- */
  const persist = useCallback(
    async (payload: Record<string, unknown>) => {
      setSaveState("saving");
      try {
        await updateFile(fileId, payload);
        setSaveState("saved");
        dirtyRef.current = false;
        setTimeout(() => setSaveState((s) => (s === "saved" ? "idle" : s)), 1600);
      } catch (err) {
        console.error("[EVA] save failed:", err);
        setSaveState("error");
        toast.error("تعذّر حفظ المستند", { description: (err as Error).message });
      }
    },
    [fileId]
  );

  const scheduleSave = useCallback(() => {
    dirtyRef.current = true;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      const el = editorRef.current;
      if (!el) return;
      const clone = el.cloneNode(true) as HTMLElement;
      clone.querySelectorAll(".eva-search-hit").forEach((hit) => {
        hit.replaceWith(document.createTextNode(hit.textContent ?? ""));
      });
      clone.querySelectorAll(".sel").forEach((c) => c.classList.remove("sel"));
      clone.querySelectorAll(".eva-resize-handle").forEach((c) => c.remove());
      clone.querySelectorAll(".eva-float-selected").forEach((c) => c.classList.remove("eva-float-selected"));
      void persist({ content: JSON.stringify({ html: clone.innerHTML }) });
    }, 900);
  }, [persist]);

  useEffect(() => {
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
  }, []);

  const handleTitleChange = (value: string) => {
    setTitle(value);
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => void persist({ title: value || "بدون عنوان" }), 700);
  };

  const handleSetupChange = (next: PageSetup) => {
    setSetup(next);
    void persist({ page_setup: JSON.stringify(next) });
  };

  const toggleFavorite = () => {
    if (!file) return;
    const next = file.is_favorite === "yes" ? "no" : "yes";
    setFile({ ...file, is_favorite: next });
    void persist({ is_favorite: next });
  };

  /* ------------------------- zoom to fit ------------------------- */
  const pageWpx = pageWidthMm(setup) * MM_TO_PX;

  const { viewportRef, zoom, minimum, maximum, changeZoom, resetZoom } = useDocumentZoom(pageWpx);

  /* ------------------------- table cell selection ------------------------- */
  useEffect(() => {
    const el = editorRef.current;
    if (!el) return;

    const paint = (cells: HTMLTableCellElement[]) => {
      el.querySelectorAll(".sel").forEach((c) => c.classList.remove("sel"));
      cells.forEach((c) => c.classList.add("sel"));
    };

    if (!cellSelectMode) {
      paint([]);
      setSelectedCells([]);
      return;
    }

    let anchor: HTMLTableCellElement | null = null;
    let dragging = false;

    const cellFrom = (target: EventTarget | null) =>
      (target as HTMLElement | null)?.closest?.("td, th") as HTMLTableCellElement | null;

    const rectSelect = (a: HTMLTableCellElement, b: HTMLTableCellElement) => {
      const table = ed.tableOf(a);
      if (!table || ed.tableOf(b) !== table) return [a];
      const matrix = ed.cellMatrix(table);
      const pos: Record<"a" | "b", { r: number; c: number } | null> = { a: null, b: null };
      matrix.forEach((row, r) =>
        row.forEach((cell, c) => {
          if (cell === a && !pos.a) pos.a = { r, c };
          if (cell === b && !pos.b) pos.b = { r, c };
        })
      );
      if (!pos.a || !pos.b) return [a];
      const r1 = Math.min(pos.a.r, pos.b.r);
      const r2 = Math.max(pos.a.r, pos.b.r);
      const c1 = Math.min(pos.a.c, pos.b.c);
      const c2 = Math.max(pos.a.c, pos.b.c);
      const out = new Set<HTMLTableCellElement>();
      for (let r = r1; r <= r2; r++)
        for (let c = c1; c <= c2; c++) if (matrix[r]?.[c]) out.add(matrix[r][c]);
      return Array.from(out);
    };

    const onDown = (e: PointerEvent) => {
      const cell = cellFrom(e.target);
      if (!cell) return;
      e.preventDefault();
      anchor = cell;
      dragging = true;
      const next = [cell];
      paint(next);
      setSelectedCells(next);
    };
    const onMove = (e: PointerEvent) => {
      if (!dragging || !anchor) return;
      const cell = cellFrom(document.elementFromPoint(e.clientX, e.clientY));
      if (!cell) return;
      const next = rectSelect(anchor, cell);
      paint(next);
      setSelectedCells(next);
    };
    const onUp = () => {
      dragging = false;
    };

    el.addEventListener("pointerdown", onDown);
    el.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    return () => {
      el.removeEventListener("pointerdown", onDown);
      el.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      paint([]);
    };
  }, [cellSelectMode]);

  /* ------------------------- find & replace ------------------------- */
  const runFind = (term: string) => {
    const el = editorRef.current;
    if (!el) return;
    const count = ed.highlightAll(el, term);
    setHitCount(count);
    setHitIndex(0);
    if (count) ed.focusHit(el, 0);
  };

  const stepHit = (delta: number) => {
    const el = editorRef.current;
    if (!el || !hitCount) return;
    const next = (hitIndex + delta + hitCount) % hitCount;
    setHitIndex(next);
    ed.focusHit(el, next);
  };

  const doReplace = (all: boolean) => {
    const el = editorRef.current;
    if (!el) return;
    const n = ed.replaceHits(el, replaceTerm, !all);
    toast.success(`تم استبدال ${n} نتيجة`);
    ed.clearHighlights(el);
    setHitCount(0);
    scheduleSave();
    if (findTerm) runFind(findTerm);
  };

  const closeFind = () => {
    const el = editorRef.current;
    if (el) ed.clearHighlights(el);
    setFindOpen(false);
    setHitCount(0);
  };

  const getHtml = useCallback(() => {
    const el = editorRef.current;
    if (!el) return "";
    const clone = el.cloneNode(true) as HTMLElement;
    clone.querySelectorAll(".eva-search-hit").forEach((hit) => {
      hit.replaceWith(document.createTextNode(hit.textContent ?? ""));
    });
    clone.querySelectorAll(".sel").forEach((c) => c.classList.remove("sel"));
    clone.querySelectorAll(".eva-resize-handle").forEach((c) => c.remove());
    clone.querySelectorAll(".eva-float-selected").forEach((c) => c.classList.remove("eva-float-selected"));
    return clone.innerHTML;
  }, []);

  const selectFloat = (el: HTMLElement | null) => {
    const previous = selectedFloatRef.current;
    if (previous && previous !== el) {
      previous.classList.remove("eva-float-selected");
      previous.querySelectorAll(".eva-resize-handle").forEach((h) => h.remove());
    }
    selectedFloatRef.current = el;
    const isShape = el?.dataset.kind === "shape" ? el : null;
    setShapeSel(isShape);
    if (isShape) setShapeColorVal(ed.getShapeColor(isShape));
    if (el) {
      el.classList.add("eva-float-selected");
      if (!el.querySelector(".eva-resize-handle")) {
        for (const dir of ["nw", "n", "ne", "e", "se", "s", "sw", "w"]) {
          const handle = document.createElement("span");
          handle.className = "eva-resize-handle";
          handle.dataset.dir = dir;
          handle.contentEditable = "false";
          handle.setAttribute("aria-label", "تغيير حجم العنصر");
          el.appendChild(handle);
        }
      }
    }
  };

  const onFloatPointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    const target = event.target as HTMLElement;
    const editor = editorRef.current;
    if (freeTextMode && editor) {
      const rect = editor.getBoundingClientRect();
      const scale = rect.width / (editor.offsetWidth || 1);
      event.preventDefault();
      event.stopPropagation();
      ed.insertFreeText(editor, (event.clientX - rect.left) / scale - 90, (event.clientY - rect.top) / scale - 24);
      setFreeTextMode(false);
      scheduleSave();
      return;
    }
    const el = target.closest<HTMLElement>(".eva-float");
    if (!el || !editorRef.current?.contains(el)) {
      selectFloat(null);
      const editor = editorRef.current;
      if (editor && target === editor && !cellSelectMode) {
        const children = Array.from(editor.children).filter((child) => !(child as HTMLElement).classList.contains("eva-float"));
        const last = children.at(-1) as HTMLElement | undefined;
        const rect = editor.getBoundingClientRect();
        const scale = rect.width / (editor.offsetWidth || 1);
        const lastBottom = last ? (last.getBoundingClientRect().bottom - rect.top) / scale : 0;
        const clickedY = (event.clientY - rect.top) / scale;
        if (clickedY > lastBottom + 18) {
          event.preventDefault();
          const lineHeight = parseFloat(getComputedStyle(editor).lineHeight) || 30;
          const lines = Math.min(120, Math.max(1, Math.floor((clickedY - lastBottom) / lineHeight)));
          let paragraph: HTMLParagraphElement | null = null;
          for (let i = 0; i < lines; i++) {
            paragraph = document.createElement("p");
            paragraph.appendChild(document.createElement("br"));
            editor.appendChild(paragraph);
          }
          if (paragraph) {
            const range = document.createRange();
            range.setStart(paragraph, 0);
            range.collapse(true);
            const selection = window.getSelection();
            selection?.removeAllRanges();
            selection?.addRange(range);
            editor.focus();
            editor.dispatchEvent(new Event("input", { bubbles: true }));
          }
        }
      }
      return;
    }
    if (target.closest(".eva-free-text-content, .eva-shape-text")) {
      selectFloat(el);
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    selectFloat(el);
    floatGestureRef.current = {
      el, mode: target.closest(".eva-resize-handle") ? "resize" : "move",
      dir: target.closest<HTMLElement>(".eva-resize-handle")?.dataset.dir ?? "se",
      startX: event.clientX, startY: event.clientY,
      x: parseFloat(el.style.left) || 0, y: parseFloat(el.style.top) || 0,
      width: el.offsetWidth, height: el.offsetHeight,
    };
    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const onFloatPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const gesture = floatGestureRef.current;
    const editor = editorRef.current;
    if (!gesture || !editor) return;
    const scale = editor.getBoundingClientRect().width / (editor.offsetWidth || 1);
    const dx = (event.clientX - gesture.startX) / scale;
    const dy = (event.clientY - gesture.startY) / scale;
    if (gesture.mode === "move") {
      // Free movement: shapes may extend past the page edges on every side.
      gesture.el.style.left = `${Math.round(gesture.x + dx)}px`;
      gesture.el.style.top = `${Math.round(gesture.y + dy)}px`;
    } else {
      const d = gesture.dir;
      let { x, y, width: w, height: h } = gesture;
      if (d.includes("e")) w = Math.max(20, w + dx);
      if (d.includes("w")) { const nw = Math.max(20, w - dx); x = x + (w - nw); w = nw; }
      if (d.includes("s")) h = Math.max(14, h + dy);
      if (d.includes("n")) { const nh = Math.max(14, h - dy); y = y + (h - nh); h = nh; }
      gesture.el.style.left = `${Math.round(x)}px`;
      gesture.el.style.top = `${Math.round(y)}px`;
      gesture.el.style.width = `${Math.round(Math.max(20, w))}px`;
      gesture.el.style.height = `${Math.round(Math.max(14, h))}px`;
    }
  };

  const onFloatPointerUp = () => {
    if (!floatGestureRef.current) return;
    floatGestureRef.current = null;
    editorRef.current?.dispatchEvent(new Event("input", { bubbles: true }));
  };

  /* ------------------------- live page flow ------------------------- */
  // The live sheet grows one whole A4 (or A5/Letter) page at a time: as soon as
  // the text passes the printable height, a new page appears with a visible
  // break, matching what the preview and the exported PDF will split.
  const marginPx = setup.margin * MM_TO_PX;
  const pageHpx = pageHeightMm(setup) * MM_TO_PX;
  const contentHpx = Math.max(80, contentBoxMm(setup).height * MM_TO_PX);

  useEffect(() => {
    const el = editorRef.current;
    if (!el) return;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let run = 0;
    // Uses the very same paginator as the preview and PDF export, so the
    // number of pages while writing always equals the exported page count.
    const update = () => {
      clearTimeout(timer);
      timer = setTimeout(async () => {
        const id = ++run;
        try {
          const { paginateHtml } = await import("@/lib/office/paginate");
          const pages = await paginateHtml(el.innerHTML, setup);
          if (id === run) setPageCount(Math.max(1, pages.length));
        } catch (err) {
          console.error("[eva] live pagination failed:", err);
        }
      }, 500);
    };
    update();
    const mo = new MutationObserver(update);
    mo.observe(el, { childList: true, subtree: true, characterData: true, attributes: true });
    el.addEventListener("input", update);
    return () => {
      run++;
      clearTimeout(timer);
      mo.disconnect();
      el.removeEventListener("input", update);
    };
  }, [setup, file]);

  const sheetStyle = useMemo(
    () => ({
      width: pageWpx,
      minHeight: pageCount * pageHpx,
      padding: `${marginPx}px`,
      background: setup.page_color || "#ffffff",
      transform: `scale(${zoom})`,
      transformOrigin: "top left",
    }),
    [pageWpx, pageCount, pageHpx, marginPx, zoom, setup.page_color]
  );

  // Same frame CSS the preview and the PDF use, scoped to the live paper sheet
  // so the editor is a faithful WYSIWYG of the exported page.
  const frameCss = useMemo(() => pageFrameCss(setup, ".eva-sheet "), [setup]);

  return (
    <>
      <EditorShell
        backHref="/eva"
        title={title}
        onTitleChange={handleTitleChange}
        saveState={saveState}
        favorite={file?.is_favorite === "yes"}
        onToggleFavorite={toggleFavorite}
        actions={
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                aria-label="المزيد"
                className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-accent"
              >
                <MoreVertical className="h-4.5 w-4.5" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setPreviewOpen(true)}>
                <FileDown className="h-4 w-4" />
                معاينة وتصدير PDF
              </DropdownMenuItem>
              <DownloadPdfMenuItem
                fileId={fileId}
                getHtml={getHtml}
                setup={setup}
                title={title}
              />
              <DropdownMenuItem onClick={() => setSetupOpen(true)}>
                <Settings2 className="h-4 w-4" />
                إعداد الصفحة
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFindOpen(true)}>
                <Search className="h-4 w-4" />
                بحث واستبدال
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setToolsMenuOpen(true)}>
                <SlidersHorizontal className="h-4 w-4" />
                تخصيص الأدوات
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        }
        toolbar={
          <>
            <DocToolbar
              editorRef={editorRef}
              sync={scheduleSave}
              selectedCells={selectedCells}
              cellSelectMode={cellSelectMode}
              setCellSelectMode={setCellSelectMode}
              onOpenSetup={() => {
                setSetupFocus(null);
                setSetupOpen(true);
              }}
              onOpenPageBorder={() => {
                setSetupFocus("border");
                setSetupOpen(true);
              }}
              onPreview={() => setPreviewOpen(true)}
              onFind={() => setFindOpen(true)}
              freeTextMode={freeTextMode}
              onToggleFreeText={() => setFreeTextMode((value) => !value)}
              toolsMenuOpen={toolsMenuOpen}
              setToolsMenuOpen={setToolsMenuOpen}
            />
            {findOpen && (
              <div className="flex flex-wrap items-center gap-1.5 border-t border-border bg-muted/40 px-2 py-2">
                <Input
                  value={findTerm}
                  onChange={(e) => {
                    setFindTerm(e.target.value);
                    runFind(e.target.value);
                  }}
                  placeholder="بحث في المستند"
                  className="h-9 w-40 flex-1"
                />
                <span className="shrink-0 text-xs tabular-nums text-muted-foreground">
                  {hitCount ? `${hitIndex + 1}/${hitCount}` : "0"}
                </span>
                <button
                  type="button"
                  aria-label="السابق"
                  onClick={() => stepHit(-1)}
                  className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-secondary hover:bg-accent"
                >
                  <ChevronUp className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  aria-label="التالي"
                  onClick={() => stepHit(1)}
                  className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-secondary hover:bg-accent"
                >
                  <ChevronDown className="h-4 w-4" />
                </button>
                <Input
                  value={replaceTerm}
                  onChange={(e) => setReplaceTerm(e.target.value)}
                  placeholder="استبدال بـ"
                  className="h-9 w-32 flex-1"
                />
                <button
                  type="button"
                  onClick={() => doReplace(false)}
                  disabled={!hitCount}
                  className="inline-flex h-9 items-center gap-1 rounded-lg bg-secondary px-2.5 text-[13px] hover:bg-accent disabled:opacity-40"
                >
                  <Replace className="h-3.5 w-3.5" /> استبدال
                </button>
                <button
                  type="button"
                  onClick={() => doReplace(true)}
                  disabled={!hitCount}
                  className="inline-flex h-9 items-center rounded-lg bg-secondary px-2.5 text-[13px] hover:bg-accent disabled:opacity-40"
                >
                  الكل
                </button>
                <button
                  type="button"
                  aria-label="إغلاق البحث"
                  onClick={closeFind}
                  className="inline-flex h-9 w-9 items-center justify-center rounded-lg hover:bg-accent"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}
          </>
        }
      >
        <div ref={viewportRef} className="document-viewport relative bg-muted/40 px-3 py-4 pb-24">
          <DocumentViewControls zoom={zoom} minimum={minimum} maximum={maximum} changeZoom={changeZoom} resetZoom={resetZoom} />
          <div id="eva-document">
          <style dangerouslySetInnerHTML={{ __html: frameCss }} />
          <div className="document-paper-space mx-auto" dir="ltr" style={{ width: pageWpx * zoom, minHeight: pageCount * pageHpx * zoom }}>
          <div
            ref={sheetRef}
            className="paper-sheet eva-sheet mx-auto rounded-[3px]"
            style={sheetStyle}
            dir="rtl"
          >
            <div className="page-frame" aria-hidden="true">
              <span />
              <span />
              <span />
              <span />
            </div>
            {/* page separators: one per extra page, drawn where the print
                page really ends so the writer sees the break live */}
            {Array.from({ length: pageCount - 1 }, (_, i) => (
              <div
                key={i}
                aria-hidden="true"
                className="pointer-events-none absolute z-[8] flex items-center justify-center bg-muted shadow-[inset_0_10px_12px_-8px_hsl(0_0%_0%/0.35),inset_0_-10px_12px_-8px_hsl(0_0%_0%/0.35)]"
                style={{ top: marginPx + (i + 1) * contentHpx - 20, left: -18, right: -18, height: 40 }}
              >
                <span className="rounded-full border border-border bg-background px-3 py-0.5 text-[11px] font-semibold text-muted-foreground shadow-sm">
                  صفحة {i + 2}
                </span>
              </div>
            ))}
            <div
              ref={editorRef}
              className={`eva-doc relative z-[1] ${freeTextMode ? "cursor-crosshair" : ""}`}
              contentEditable={!cellSelectMode}
              suppressContentEditableWarning
              data-placeholder="ابدأ الكتابة…"
              dir="rtl"
              onInput={scheduleSave}
              onPointerDown={onFloatPointerDown}
              onDoubleClick={(event) => {
                const editor = editorRef.current;
                const shape = (event.target as HTMLElement).closest<HTMLElement>('.eva-float[data-kind="shape"]');
                if (shape) {
                  event.preventDefault();
                  const t = ed.ensureShapeText(shape);
                  t.focus();
                  return;
                }
                const img = (event.target as HTMLElement).closest<HTMLElement>('.eva-float[data-kind="image"]');
                if (!editor || !img) return;
                event.preventDefault();
                const rect = editor.getBoundingClientRect();
                const scale = rect.width / (editor.offsetWidth || 1);
                const box = ed.insertFreeText(editor, (event.clientX - rect.left) / scale - 90, (event.clientY - rect.top) / scale - 24);
                box.classList.add("eva-on-image");
                scheduleSave();
              }}
              onPointerMove={onFloatPointerMove}
              onPointerUp={onFloatPointerUp}
              onPointerCancel={onFloatPointerUp}
              style={{ minHeight: pageCount * pageHpx - 2 * marginPx }}
            />
          </div>
          </div>

          {shapeSel && (
            <div dir="rtl" className="fixed bottom-4 left-1/2 z-50 flex max-w-[96vw] -translate-x-1/2 flex-col gap-2 rounded-2xl border border-border bg-card p-2 shadow-lg">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="px-1 text-xs font-medium text-muted-foreground">اللون</span>
                <input
                  type="color"
                  aria-label="لون الشكل"
                  value={shapeColorVal}
                  onChange={(e) => { setShapeColorVal(e.target.value); ed.setShapeColor(shapeSel, e.target.value); scheduleSave(); }}
                  className="h-6 w-8 cursor-pointer border-0 bg-transparent p-0"
                />
                {ed.SHAPE_PALETTE.map((c) => (
                  <button key={c} type="button" aria-label={`لون ${c}`} onClick={() => { setShapeColorVal(c); ed.setShapeColor(shapeSel, c); scheduleSave(); }}
                    className="h-6 w-6 rounded-full border border-border" style={{ background: c }} />
                ))}
              </div>
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="px-1 text-xs font-medium text-muted-foreground">تأثير</span>
                {ed.SHAPE_EFFECTS.map((fx) => (
                  <button key={fx.key} type="button"
                    className={`rounded-lg border px-2 py-1 text-xs hover:bg-muted ${(shapeSel.dataset.effect ?? "none") === fx.key ? "border-primary bg-muted" : "border-border"}`}
                    onClick={() => { ed.setShapeEffect(shapeSel, fx.key); setShapeSel(shapeSel); setShapeColorVal(ed.getShapeColor(shapeSel)); scheduleSave(); setShapeSel(null); requestAnimationFrame(() => setShapeSel(shapeSel)); }}>
                    {fx.label}
                  </button>
                ))}
                <button type="button" className="rounded-lg border border-border px-2 py-1 text-xs hover:bg-muted"
                  onClick={() => { const t = ed.ensureShapeText(shapeSel); t.focus(); scheduleSave(); }}>
                  كتابة نص
                </button>
                <span className="px-1 text-xs font-medium text-muted-foreground">موضع النص</span>
                <div className="grid grid-cols-3 gap-0.5 rounded-lg border border-border p-0.5">
                  {ed.SHAPE_TEXT_POSITIONS.map((p) => (
                    <button key={p.key} type="button" title={p.title} aria-label={p.title}
                      className={`h-5 w-5 rounded text-[11px] leading-none hover:bg-muted ${(shapeSel.dataset.textPos ?? "c") === p.key ? "bg-primary text-primary-foreground" : ""}`}
                      onClick={() => { ed.setShapeTextPosition(shapeSel, p.key); scheduleSave(); setShapeSel(null); requestAnimationFrame(() => setShapeSel(shapeSel)); }}>
                      {p.label}
                    </button>
                  ))}
                </div>
                <button type="button" className="rounded-lg border border-border px-2 py-1 text-xs text-destructive hover:bg-muted"
                  onClick={() => { const el = shapeSel; selectFloat(null); el.remove(); scheduleSave(); }}>
                  حذف
                </button>
              </div>
            </div>
          )}

          <p className="mt-3 text-center text-xs text-muted-foreground">
            {pageCount} صفحة — يتم تقسيم النص تلقائيًا عند تجاوز حدّ الصفحة
          </p>

          </div>

        </div>
      </EditorShell>

      <PageSetupSheet
        open={setupOpen}
        onOpenChange={setSetupOpen}
        setup={setup}
        onChange={handleSetupChange}
        focus={setupFocus}
      />
      <PreviewDialog
        open={previewOpen}
        onOpenChange={setPreviewOpen}
        getHtml={getHtml}
        setup={setup}
        title={title}
        fileId={fileId}
      />
    </>
  );
}

export const Route = createFileRoute("/eva/$id")({
  head: () => ({
    meta: [
      { title: "محرر المستند — EVA Office" },
      { name: "description", content: "اكتب مستندك وأدرج الصور والأشكال ونظم صفحاته في EVA Office." },
      { property: "og:title", content: "محرر المستند — EVA Office" },
      { property: "og:description", content: "اكتب مستندك وأدرج الصور والأشكال ونظم صفحاته في EVA Office." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DocumentEditorPage,
});
