import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "@/lib/office/nav";
import { toast } from "sonner";
import {
  Plus, Trash2, ChevronDown, ChevronUp, GripVertical, FileDown, Settings2,
  MoreVertical, ListChecks, Loader2, Info,
} from "lucide-react";
import { EditorShell, type SaveState } from "@/components/office/EditorShell";
import { PageSetupSheet } from "@/components/office/PageSetupSheet";
import { PreviewDialog } from "@/components/office/PreviewDialog";
import { DownloadPdfMenuItem } from "@/components/office/DownloadPdfMenuItem";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  createQuestion, deleteQuestion, getFile, listQuestions, updateFile, updateQuestion,
} from "@/lib/office/client";
import { examInnerHtml } from "@/lib/office/render";
import {
  DEFAULT_EXAM_META, DEFAULT_PAGE_SETUP, QUESTION_TYPE_LABELS, safeJson,
  type ExamMeta, type ExamQuestion, type OfficeFile, type PageSetup, type QuestionType,
} from "@/lib/office/types";

const META_FIELDS: { key: keyof ExamMeta; label: string; type?: string; full?: boolean }[] = [
  { key: "exam_title", label: "اسم الاختبار", full: true },
  { key: "subject", label: "اسم المادة" },
  { key: "school", label: "المدرسة / المؤسسة" },
  { key: "student_name", label: "اسم الطالب" },
  { key: "grade", label: "الصف أو المرحلة" },
  { key: "class_section", label: "الشعبة" },
  { key: "exam_date", label: "التاريخ", type: "date" },
  { key: "duration", label: "مدة الاختبار" },
  { key: "total_marks", label: "الدرجة النهائية" },
];

const TYPES = Object.keys(QUESTION_TYPE_LABELS) as QuestionType[];

const DEFAULT_LINES: Record<QuestionType, number> = {
  multiple_choice: 0,
  true_false: 0,
  fill_blank: 1,
  short_answer: 3,
  essay: 6,
};

function ExamBuilderPage() {
  const params = useParams<{ id: string }>();
  const fileId = params.id;

  const [file, setFile] = useState<OfficeFile | null>(null);
  const [title, setTitle] = useState("");
  const [meta, setMeta] = useState<ExamMeta>(DEFAULT_EXAM_META);
  const [questions, setQuestions] = useState<ExamQuestion[]>([]);
  const [setup, setSetup] = useState<PageSetup>(DEFAULT_PAGE_SETUP);
  const [saveState, setSaveState] = useState<SaveState>("idle");
  const [metaOpen, setMetaOpen] = useState(true);
  const [setupOpen, setSetupOpen] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [adding, setAdding] = useState(false);
  const [loading, setLoading] = useState(true);

  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const questionTimers = useRef<Record<string, ReturnType<typeof setTimeout>>>({});

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [data, qs] = await Promise.all([getFile(fileId), listQuestions(fileId)]);
        if (cancelled) return;
        setFile(data);
        setTitle(data.title);
        setSetup(safeJson<PageSetup>(data.page_setup, DEFAULT_PAGE_SETUP));
        setMeta(safeJson<{ meta: ExamMeta }>(data.content, { meta: DEFAULT_EXAM_META }).meta ?? DEFAULT_EXAM_META);
        setQuestions(qs);
        console.log("[EVA exam] loaded", data._id, qs.length, "questions");
        void updateFile(fileId, { last_opened_at: new Date().toISOString() }).catch((err) =>
          console.error("[EVA exam] stamp failed:", err)
        );
      } catch (err) {
        console.error("[EVA exam] load failed:", err);
        toast.error("تعذّر فتح الاختبار", { description: (err as Error).message });
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [fileId]);

  const persist = useCallback(
    async (payload: Record<string, unknown>) => {
      setSaveState("saving");
      try {
        await updateFile(fileId, payload);
        setSaveState("saved");
        setTimeout(() => setSaveState((s) => (s === "saved" ? "idle" : s)), 1500);
      } catch (err) {
        console.error("[EVA exam] save failed:", err);
        setSaveState("error");
        toast.error("تعذّر الحفظ", { description: (err as Error).message });
      }
    },
    [fileId]
  );

  const scheduleMetaSave = useCallback(
    (next: ExamMeta) => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(() => void persist({ content: JSON.stringify({ meta: next }) }), 800);
    },
    [persist]
  );

  const patchMeta = (key: keyof ExamMeta, value: string) => {
    const next = { ...meta, [key]: value };
    setMeta(next);
    scheduleMetaSave(next);
  };

  const handleTitleChange = (value: string) => {
    setTitle(value);
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => void persist({ title: value || "اختبار جديد" }), 700);
  };

  const addQuestion = async (type: QuestionType) => {
    setAdding(true);
    try {
      const created = await createQuestion(fileId, {
        question_type: type,
        question_text: "",
        choices: JSON.stringify(type === "multiple_choice" ? ["", "", "", ""] : []),
        marks: 1,
        answer_lines: DEFAULT_LINES[type],
        section_title: questions[questions.length - 1]?.section_title ?? "",
        order_index: questions.length,
      });
      setQuestions((prev) => [...prev, created]);
      console.log("[EVA exam] question added", created._id, type);
    } catch (err) {
      console.error("[EVA exam] add question failed:", err);
      toast.error("تعذّر إضافة السؤال", { description: (err as Error).message });
    } finally {
      setAdding(false);
    }
  };

  const patchQuestion = (id: string, patch: Partial<ExamQuestion>) => {
    setQuestions((prev) => prev.map((q) => (q._id === id ? { ...q, ...patch } : q)));
    if (questionTimers.current[id]) clearTimeout(questionTimers.current[id]);
    questionTimers.current[id] = setTimeout(() => {
      setSaveState("saving");
      updateQuestion(id, patch)
        .then(() => {
          setSaveState("saved");
          setTimeout(() => setSaveState((s) => (s === "saved" ? "idle" : s)), 1200);
        })
        .catch((err) => {
          console.error("[EVA exam] question save failed:", err);
          setSaveState("error");
          toast.error("تعذّر حفظ السؤال");
        });
    }, 700);
  };

  const removeQuestion = async (id: string) => {
    const backup = questions;
    setQuestions((prev) => prev.filter((q) => q._id !== id));
    try {
      await deleteQuestion(id);
      toast.success("تم حذف السؤال");
    } catch (err) {
      console.error("[EVA exam] delete failed:", err);
      toast.error("تعذّر حذف السؤال");
      setQuestions(backup);
    }
  };

  const move = async (index: number, delta: number) => {
    const target = index + delta;
    if (target < 0 || target >= questions.length) return;
    const next = [...questions];
    [next[index], next[target]] = [next[target], next[index]];
    const reindexed = next.map((q, i) => ({ ...q, order_index: i }));
    setQuestions(reindexed);
    try {
      await Promise.all(
        [index, target].map((i) => updateQuestion(reindexed[i]._id, { order_index: reindexed[i].order_index }))
      );
    } catch (err) {
      console.error("[EVA exam] reorder failed:", err);
      toast.error("تعذّر إعادة الترتيب");
    }
  };

  const totalMarks = useMemo(
    () => questions.reduce((sum, q) => sum + (Number(q.marks) || 0), 0),
    [questions]
  );

  const getHtml = useCallback(() => examInnerHtml(meta, questions), [meta, questions]);

  const toggleFavorite = () => {
    if (!file) return;
    const next = file.is_favorite === "yes" ? "no" : "yes";
    setFile({ ...file, is_favorite: next });
    void persist({ is_favorite: next });
  };

  return (
    <>
      <EditorShell
        backHref="/eva"
        title={title}
        onTitleChange={handleTitleChange}
        saveState={saveState}
        accent="#f59e0b"
        favorite={file?.is_favorite === "yes"}
        onToggleFavorite={toggleFavorite}
        actions={
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                aria-label="المزيد"
                className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-accent"
              >
                <MoreVertical className="h-4.5 w-4.5" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setPreviewOpen(true)}>
                <FileDown className="h-4 w-4" />
                معاينة وتصدير PDF
              </DropdownMenuItem>
              <DownloadPdfMenuItem
                fileId={fileId}
                getHtml={getHtml}
                setup={setup}
                title={title}
              />
              <DropdownMenuItem onClick={() => setSetupOpen(true)}>
                <Settings2 className="h-4 w-4" />
                إعداد الصفحة
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        }
      >
        <div className="mx-auto w-full max-w-3xl px-3 pb-28 pt-4">
          {/* exam information */}
          <section className="rounded-2xl border border-border bg-card">
            <button
              type="button"
              onClick={() => setMetaOpen((v) => !v)}
              className="flex w-full items-center gap-2 px-4 py-3 text-right"
            >
              <Info className="h-4 w-4 text-amber-500" />
              <span className="flex-1 font-display font-medium">بيانات الاختبار</span>
              {metaOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </button>
            {metaOpen && (
              <div className="grid grid-cols-2 gap-3 border-t border-border p-4">
                {META_FIELDS.map((field) => (
                  <div key={field.key} className={`space-y-1.5 ${field.full ? "col-span-2" : ""}`}>
                    <Label htmlFor={`m-${field.key}`} className="text-xs">
                      {field.label}
                    </Label>
                    <Input
                      id={`m-${field.key}`}
                      type={field.type ?? "text"}
                      value={meta[field.key]}
                      onChange={(e) => patchMeta(field.key, e.target.value)}
                      className="h-10"
                    />
                  </div>
                ))}
                <div className="col-span-2 space-y-1.5">
                  <Label htmlFor="m-instructions" className="text-xs">
                    تعليمات الاختبار
                  </Label>
                  <Textarea
                    id="m-instructions"
                    value={meta.instructions}
                    onChange={(e) => patchMeta("instructions", e.target.value)}
                    rows={2}
                  />
                </div>
              </div>
            )}
          </section>

          {/* summary */}
          <div className="mt-3 flex items-center gap-3 rounded-2xl border border-border bg-card px-4 py-3 text-sm">
            <ListChecks className="h-4 w-4 text-amber-500" />
            <span className="font-medium">{questions.length} سؤال</span>
            <span className="text-muted-foreground">·</span>
            <span className="text-muted-foreground">مجموع الدرجات: {totalMarks}</span>
          </div>

          {/* questions */}
          <div className="mt-3 space-y-3">
            {loading ? (
              <div className="flex items-center justify-center gap-2 py-10 text-muted-foreground">
                <Loader2 className="h-5 w-5 animate-spin" /> جارٍ التحميل…
              </div>
            ) : questions.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-border p-8 text-center">
                <p className="font-medium">لا توجد أسئلة بعد</p>
                <p className="mt-1 text-sm text-muted-foreground">اختر نوع السؤال من الأسفل لإضافته.</p>
              </div>
            ) : (
              questions.map((q, i) => (
                <QuestionCard
                  key={q._id}
                  question={q}
                  index={i}
                  onPatch={patchQuestion}
                  onRemove={removeQuestion}
                  onMove={move}
                  isFirst={i === 0}
                  isLast={i === questions.length - 1}
                />
              ))
            )}
          </div>
        </div>

        {/* add question bar */}
        <div className="no-print fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 backdrop-blur-xl">
          <div className="no-scrollbar mx-auto flex max-w-3xl gap-2 overflow-x-auto px-3 py-2.5">
            {TYPES.map((type) => (
              <button
                key={type}
                type="button"
                disabled={adding}
                onClick={() => addQuestion(type)}
                className="inline-flex shrink-0 items-center gap-1.5 rounded-xl border border-border bg-card px-3 py-2 text-[13px] font-medium transition-colors hover:bg-accent disabled:opacity-60"
              >
                <Plus className="h-3.5 w-3.5" />
                {QUESTION_TYPE_LABELS[type]}
              </button>
            ))}
          </div>
          <div className="h-[env(safe-area-inset-bottom)]" />
        </div>
      </EditorShell>

      <PageSetupSheet
        open={setupOpen}
        onOpenChange={setSetupOpen}
        setup={setup}
        onChange={(next) => {
          setSetup(next);
          void persist({ page_setup: JSON.stringify(next) });
        }}
      />
      <PreviewDialog
        open={previewOpen}
        onOpenChange={setPreviewOpen}
        getHtml={getHtml}
        setup={setup}
        title={title}
        fileId={fileId}
      />
    </>
  );
}

/* ------------------------------------------------------------------ */

function QuestionCard({
  question,
  index,
  onPatch,
  onRemove,
  onMove,
  isFirst,
  isLast,
}: {
  question: ExamQuestion;
  index: number;
  onPatch: (id: string, patch: Partial<ExamQuestion>) => void;
  onRemove: (id: string) => void;
  onMove: (index: number, delta: number) => void;
  isFirst: boolean;
  isLast: boolean;
}) {
  const choices: string[] = useMemo(() => {
    try {
      return question.choices ? (JSON.parse(question.choices) as string[]) : [];
    } catch {
      return [];
    }
  }, [question.choices]);

  const setChoices = (next: string[]) => onPatch(question._id, { choices: JSON.stringify(next) });
  const letters = ["A", "B", "C", "D", "E", "F"];

  return (
    <article className="rounded-2xl border border-border bg-card p-3.5">
      <header className="mb-2.5 flex items-center gap-2">
        <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-500/15 text-[13px] font-bold text-amber-600">
          {index + 1}
        </span>
        <select
          value={question.question_type}
          onChange={(e) => {
            const type = e.target.value as QuestionType;
            onPatch(question._id, {
              question_type: type,
              answer_lines: DEFAULT_LINES[type],
              choices: JSON.stringify(type === "multiple_choice" ? choices.length ? choices : ["", "", "", ""] : []),
            });
          }}
          aria-label="نوع السؤال"
          className="h-9 flex-1 rounded-lg border border-border bg-background px-2 text-[13px] outline-none"
        >
          {TYPES.map((t) => (
            <option key={t} value={t}>
              {QUESTION_TYPE_LABELS[t]}
            </option>
          ))}
        </select>
        <button
          type="button"
          aria-label="تحريك لأعلى"
          disabled={isFirst}
          onClick={() => onMove(index, -1)}
          className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground hover:bg-accent disabled:opacity-30"
        >
          <ChevronUp className="h-4 w-4" />
        </button>
        <button
          type="button"
          aria-label="تحريك لأسفل"
          disabled={isLast}
          onClick={() => onMove(index, 1)}
          className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground hover:bg-accent disabled:opacity-30"
        >
          <ChevronDown className="h-4 w-4" />
        </button>
        <button
          type="button"
          aria-label="حذف السؤال"
          onClick={() => onRemove(question._id)}
          className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-destructive hover:bg-destructive/10"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </header>

      <Textarea
        value={question.question_text}
        onChange={(e) => onPatch(question._id, { question_text: e.target.value })}
        placeholder="نص السؤال…"
        rows={2}
        className="mb-2.5"
      />

      {question.question_type === "multiple_choice" && (
        <div className="mb-2.5 space-y-2">
          {choices.map((choice, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-secondary text-[13px] font-bold">
                {letters[i] ?? i + 1}
              </span>
              <Input
                value={choice}
                placeholder={`الخيار ${letters[i] ?? i + 1}`}
                onChange={(e) => {
                  const next = [...choices];
                  next[i] = e.target.value;
                  setChoices(next);
                }}
                className="h-9"
              />
              <button
                type="button"
                aria-label="حذف الخيار"
                onClick={() => setChoices(choices.filter((_, ci) => ci !== i))}
                className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-muted-foreground hover:bg-accent"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={() => setChoices([...choices, ""])}
            className="inline-flex items-center gap-1.5 rounded-lg bg-secondary px-2.5 py-1.5 text-[13px] hover:bg-accent"
          >
            <Plus className="h-3.5 w-3.5" /> خيار
          </button>
        </div>
      )}

      <div className="grid grid-cols-3 gap-2">
        <div className="space-y-1">
          <Label className="text-[11px] text-muted-foreground">الدرجة</Label>
          <Input
            type="number"
            min={0}
            step={0.5}
            value={question.marks ?? ""}
            onChange={(e) =>
              onPatch(question._id, { marks: e.target.value === "" ? 0 : Number(e.target.value) })
            }
            className="h-9"
          />
        </div>
        <div className="space-y-1">
          <Label className="text-[11px] text-muted-foreground">أسطر الإجابة</Label>
          <Input
            type="number"
            min={0}
            value={question.answer_lines ?? ""}
            onChange={(e) =>
              onPatch(question._id, { answer_lines: e.target.value === "" ? 0 : Number(e.target.value) })
            }
            className="h-9"
          />
        </div>
        <div className="space-y-1">
          <Label className="text-[11px] text-muted-foreground">القسم</Label>
          <Input
            value={question.section_title ?? ""}
            placeholder="اختياري"
            onChange={(e) => onPatch(question._id, { section_title: e.target.value })}
            className="h-9"
          />
        </div>
      </div>
    </article>
  );
}

export const Route = createFileRoute("/eva/exam/$id")({
  head: () => ({
    meta: [
      { title: "محرر الاختبار — EVA Office" },
      { name: "description", content: "أنشئ الأسئلة ونظم اختباراتك في EVA Office." },
      { property: "og:title", content: "محرر الاختبار — EVA Office" },
      { property: "og:description", content: "أنشئ الأسئلة ونظم اختباراتك في EVA Office." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ExamBuilderPage,
});
