import { createFileRoute } from "@tanstack/react-router";
import { AppLibrary } from "@/components/office/AppLibrary";

function EvaLibraryPage() {
  return (
    <AppLibrary
      app="eva"
      description="محرر مستندات احترافي للهاتف واللوحي: كتابة وتنسيق كامل، جداول وصور وأشكال، ونظام متخصص لإنشاء الأسئلة والاختبارات ثم تصديرها PDF."
      createOptions={[
        { label: "مستند جديد", doc_type: "document", title: "مستند جديد" },
        { label: "اختبار جديد", doc_type: "exam", title: "اختبار جديد" },
      ]}
    />
  );
}

export const Route = createFileRoute("/eva/")({
  head: () => ({
    meta: [
      { title: "مستندات EVA — EVA Office" },
      { name: "description", content: "أنشئ مستندات واختبارات ونسق صفحاتك في EVA Office." },
      { property: "og:title", content: "مستندات EVA — EVA Office" },
      { property: "og:description", content: "أنشئ مستندات واختبارات ونسق صفحاتك في EVA Office." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: EvaLibraryPage,
});
