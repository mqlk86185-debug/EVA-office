import { createFileRoute } from "@tanstack/react-router";
import { Suspense, useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "@/components/office/Link";
import { useSearchParams } from "@/lib/office/nav";
import { toast } from "sonner";
import { ChevronRight, Search, Plus, Star, Trash2, FolderOpen, Loader2 } from "lucide-react";
import { BottomNav } from "@/components/office/BottomNav";
import { FileCard } from "@/components/office/FileCard";
import { NewFileDialog } from "@/components/office/NewFileDialog";
import { ThemeToggle } from "@/components/office/ThemeToggle";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  deleteFileForever, listFiles, shareUrl, updateFile,
} from "@/lib/office/client";
import { APP_META, fileHref, type AppType, type OfficeFile } from "@/lib/office/types";

type View = "all" | "favorites" | "trash";

const VIEWS: { key: View; label: string; icon: typeof Star }[] = [
  { key: "all", label: "كل الملفات", icon: FolderOpen },
  { key: "favorites", label: "المفضلة", icon: Star },
  { key: "trash", label: "سلة المحذوفات", icon: Trash2 },
];

const APPS: (AppType | "all")[] = ["all", "eva", "pdf", "gilox"];

function FilesManager() {
  const searchParams = useSearchParams();
  const initialView = (searchParams.get("view") as View) ?? "all";

  const [view, setView] = useState<View>(VIEWS.some((v) => v.key === initialView) ? initialView : "all");
  const [appFilter, setAppFilter] = useState<AppType | "all">("all");
  const [search, setSearch] = useState("");
  const [files, setFiles] = useState<OfficeFile[] | null>(null);
  const [newOpen, setNewOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setFiles(null);
    try {
      const data = await listFiles({
        trashed: view === "trash",
        favorite: view === "favorites",
        limit: 300,
      });
      setFiles(data);
      console.log("[Files] loaded", data.length, "for view", view);
    } catch (err) {
      console.error("[Files] load failed:", err);
      toast.error("تعذّر تحميل الملفات");
      setFiles([]);
    }
  }, [view]);

  useEffect(() => {
    void load();
  }, [load]);

  const visible = useMemo(() => {
    let list = files ?? [];
    if (appFilter !== "all") list = list.filter((f) => f.app_type === appFilter);
    const term = search.trim().toLowerCase();
    if (term) list = list.filter((f) => f.title.toLowerCase().includes(term));
    return list;
  }, [files, appFilter, search]);

  const mutate = async (file: OfficeFile, payload: Record<string, unknown>, message: string) => {
    setBusy(true);
    setFiles((prev) => prev?.filter((f) => f._id !== file._id) ?? null);
    try {
      await updateFile(file._id, payload);
      toast.success(message);
    } catch (err) {
      console.error("[Files] update failed:", err);
      toast.error("تعذّر تنفيذ العملية");
      void load();
    } finally {
      setBusy(false);
    }
  };

  const toggleFavorite = async (file: OfficeFile) => {
    const next = file.is_favorite === "yes" ? "no" : "yes";
    if (view === "favorites" && next === "no") {
      await mutate(file, { is_favorite: next }, "أُزيل من المفضلة");
      return;
    }
    setFiles((prev) => prev?.map((f) => (f._id === file._id ? { ...f, is_favorite: next } : f)) ?? null);
    try {
      await updateFile(file._id, { is_favorite: next });
    } catch (err) {
      console.error("[Files] favorite failed:", err);
      toast.error("تعذّر تحديث المفضلة");
      void load();
    }
  };

  const removeForever = async (file: OfficeFile) => {
    setBusy(true);
    setFiles((prev) => prev?.filter((f) => f._id !== file._id) ?? null);
    try {
      await deleteFileForever(file._id);
      toast.success("تم الحذف نهائيًا");
    } catch (err) {
      console.error("[Files] permanent delete failed:", err);
      toast.error("تعذّر الحذف");
      void load();
    } finally {
      setBusy(false);
    }
  };

  const share = async (file: OfficeFile) => {
    try {
      const how = await shareUrl(file.title, fileHref(file));
      toast.success(how === "copied" ? "تم نسخ الرابط" : "تمت المشاركة");
    } catch (err) {
      console.error("[Files] share failed:", err);
      toast.error("تعذّرت المشاركة");
    }
  };

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-4xl flex-col px-4 pt-4">
      <header className="flex items-center gap-2">
        <Link
          href="/"
          aria-label="رجوع"
          className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-muted-foreground hover:bg-accent hover:text-foreground"
        >
          <ChevronRight className="h-5 w-5" />
        </Link>
        <h1 className="flex-1 font-display text-lg font-semibold tracking-tight">إدارة الملفات</h1>
        {busy && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
        <ThemeToggle />
      </header>

      <div className="mt-4 grid grid-cols-3 gap-2">
        {VIEWS.map((v) => {
          const Icon = v.icon;
          return (
            <button
              key={v.key}
              type="button"
              onClick={() => setView(v.key)}
              className={`flex flex-col items-center gap-1.5 rounded-2xl border px-2 py-3 text-xs font-medium transition-colors ${
                view === v.key ? "border-foreground bg-foreground text-background" : "border-border bg-card hover:bg-accent"
              }`}
            >
              <Icon className="h-4.5 w-4.5" />
              {v.label}
            </button>
          );
        })}
      </div>

      <div className="relative mt-3">
        <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="ابحث بالاسم…"
          className="h-11 pr-9"
        />
      </div>

      <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto pb-1">
        {APPS.map((app) => (
          <button
            key={app}
            type="button"
            onClick={() => setAppFilter(app)}
            className={`shrink-0 rounded-xl border px-3.5 py-1.5 text-sm transition-colors ${
              appFilter === app ? "border-foreground bg-foreground text-background" : "border-border bg-card hover:bg-accent"
            }`}
          >
            {app === "all" ? "الكل" : APP_META[app].name}
          </button>
        ))}
      </div>

      <section className="mt-4 flex-1 pb-24">
        {files === null ? (
          <div className="space-y-2">
            {[0, 1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-[68px] rounded-2xl" />
            ))}
          </div>
        ) : visible.length === 0 ? (
          <div className="rounded-3xl border border-dashed border-border p-10 text-center">
            <p className="font-medium">
              {view === "trash" ? "سلة المحذوفات فارغة" : view === "favorites" ? "لا توجد ملفات مفضلة" : "لا توجد ملفات"}
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              {view === "all" ? "أنشئ ملفًا جديدًا للبدء." : "ستظهر الملفات هنا عند إضافتها."}
            </p>
          </div>
        ) : (
          <div className="grid gap-2 sm:grid-cols-2">
            {visible.map((file) =>
              view === "trash" ? (
                <FileCard
                  key={file._id}
                  file={file}
                  onRestore={(f) => mutate(f, { is_trashed: "no" }, "تمت الاستعادة")}
                  onDeleteForever={removeForever}
                />
              ) : (
                <FileCard
                  key={file._id}
                  file={file}
                  onToggleFavorite={toggleFavorite}
                  onTrash={(f) => mutate(f, { is_trashed: "yes" }, "تم النقل إلى سلة المحذوفات")}
                  onShare={share}
                />
              )
            )}
          </div>
        )}
      </section>

      <button
        type="button"
        onClick={() => setNewOpen(true)}
        aria-label="ملف جديد"
        className="no-print fixed bottom-20 left-4 z-40 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-foreground text-background shadow-[0_14px_35px_-12px_rgba(16,18,35,.7)] md:bottom-8"
      >
        <Plus className="h-6 w-6" />
      </button>

      <NewFileDialog open={newOpen} onOpenChange={(o) => { setNewOpen(o); if (!o) void load(); }} />
      <BottomNav />
    </div>
  );
}

function FilesPage() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-screen items-center justify-center text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
        </div>
      }
    >
      <FilesManager />
    </Suspense>
  );
}

export const Route = createFileRoute("/files")({
  head: () => ({
    meta: [
      { title: "ملفاتي — EVA Office" },
      { name: "description", content: "استعرض ملفاتك ومستنداتك المحفوظة في EVA Office." },
      { property: "og:title", content: "ملفاتي — EVA Office" },
      { property: "og:description", content: "استعرض ملفاتك ومستنداتك المحفوظة في EVA Office." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: FilesPage,
});
