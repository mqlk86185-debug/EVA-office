import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "@/lib/office/nav";
import { toast } from "sonner";
import { MoreVertical, FileDown, Settings2, X, Trash2, Pencil, Search, Filter } from "lucide-react";
import { EditorShell, type SaveState } from "@/components/office/EditorShell";
import { SheetToolbar } from "@/components/office/gilox/SheetToolbar";
import { PageSetupSheet } from "@/components/office/PageSetupSheet";
import { PreviewDialog } from "@/components/office/PreviewDialog";
import { DownloadPdfMenuItem } from "@/components/office/DownloadPdfMenuItem";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getFile, updateFile } from "@/lib/office/client";
import {
  cellKey, colLabel, computedValue, displayValue, formatCellValue, rangeBounds, SUPPORTED_FUNCTIONS,
} from "@/lib/office/sheet";
import { chartSvg, sheetInnerHtml } from "@/lib/office/render";
import {
  DEFAULT_PAGE_SETUP, DEFAULT_SHEET, safeJson,
  type Cell, type CellStyle, type ChartDef, type OfficeFile, type PageSetup, type SheetContent,
} from "@/lib/office/types";

const DEFAULT_COL_W = 104;
const DEFAULT_ROW_H = 34;

interface SelectionRect {
  r1: number;
  c1: number;
  r2: number;
  c2: number;
}

function SheetEditorPage() {
  const params = useParams<{ id: string }>();
  const fileId = params.id;

  const [file, setFile] = useState<OfficeFile | null>(null);
  const [title, setTitle] = useState("");
  const [sheet, setSheet] = useState<SheetContent>(DEFAULT_SHEET);
  const [setup, setSetup] = useState<PageSetup>(DEFAULT_PAGE_SETUP);
  const [saveState, setSaveState] = useState<SaveState>("idle");
  const [setupOpen, setSetupOpen] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);

  const [sel, setSel] = useState<SelectionRect>({ r1: 0, c1: 0, r2: 0, c2: 0 });
  const [editing, setEditing] = useState(false);
  const [barValue, setBarValue] = useState("");
  const [findOpen, setFindOpen] = useState(false);
  const [findTerm, setFindTerm] = useState("");
  const [replaceTerm, setReplaceTerm] = useState("");
  const [filterOpen, setFilterOpen] = useState(false);
  const [filterTerm, setFilterTerm] = useState("");
  const [filterCol, setFilterCol] = useState<number | null>(null);
  const [editChart, setEditChart] = useState<ChartDef | null>(null);

  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const dragging = useRef(false);
  const anchor = useRef<{ r: number; c: number }>({ r: 0, c: 0 });
  const inlineRef = useRef<HTMLInputElement>(null);

  /* ---------------- load ---------------- */
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await getFile(fileId);
        if (cancelled) return;
        setFile(data);
        setTitle(data.title);
        setSetup(safeJson<PageSetup>(data.page_setup, DEFAULT_PAGE_SETUP));
        setSheet(safeJson<SheetContent>(data.content, DEFAULT_SHEET));
        console.log("[GILOX] sheet loaded:", data._id);
        void updateFile(fileId, { last_opened_at: new Date().toISOString() }).catch((err) =>
          console.error("[GILOX] stamp failed:", err)
        );
      } catch (err) {
        console.error("[GILOX] load failed:", err);
        toast.error("تعذّر فتح الجدول", { description: (err as Error).message });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [fileId]);

  /* ---------------- persistence ---------------- */
  const persist = useCallback(
    async (payload: Record<string, unknown>) => {
      setSaveState("saving");
      try {
        await updateFile(fileId, payload);
        setSaveState("saved");
        setTimeout(() => setSaveState((s) => (s === "saved" ? "idle" : s)), 1400);
      } catch (err) {
        console.error("[GILOX] save failed:", err);
        setSaveState("error");
        toast.error("تعذّر حفظ الجدول", { description: (err as Error).message });
      }
    },
    [fileId]
  );

  const commitSheet = useCallback(
    (next: SheetContent) => {
      setSheet(next);
      if (saveTimer.current) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(() => void persist({ content: JSON.stringify(next) }), 800);
    },
    [persist]
  );

  const handleTitleChange = (value: string) => {
    setTitle(value);
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => void persist({ title: value || "جدول بيانات" }), 700);
  };

  /* ---------------- selection helpers ---------------- */
  const activeKey = cellKey(sel.r1, sel.c1);
  const selectedKeys = useMemo(() => {
    const keys: string[] = [];
    for (let r = Math.min(sel.r1, sel.r2); r <= Math.max(sel.r1, sel.r2); r++)
      for (let c = Math.min(sel.c1, sel.c2); c <= Math.max(sel.c1, sel.c2); c++)
        keys.push(cellKey(r, c));
    return keys;
  }, [sel]);

  useEffect(() => {
    setBarValue(sheet.cells[activeKey]?.v ?? "");
  }, [activeKey, sheet.cells]);

  const inSelection = (r: number, c: number) =>
    r >= Math.min(sel.r1, sel.r2) &&
    r <= Math.max(sel.r1, sel.r2) &&
    c >= Math.min(sel.c1, sel.c2) &&
    c <= Math.max(sel.c1, sel.c2);

  /* ---------------- cell mutations ---------------- */
  const setCellValue = (key: string, value: string) => {
    const cells = { ...sheet.cells };
    const existing = cells[key] ?? {};
    if (value === "") {
      if (existing.s) cells[key] = { s: existing.s };
      else delete cells[key];
    } else {
      cells[key] = { ...existing, v: value };
    }
    commitSheet({ ...sheet, cells });
  };

  const applyStyle = (patch: CellStyle) => {
    const cells = { ...sheet.cells };
    selectedKeys.forEach((key) => {
      const existing = cells[key] ?? {};
      const style: CellStyle = { ...(existing.s ?? {}), ...patch };
      Object.keys(style).forEach((k) => {
        if ((style as any)[k] === undefined || (style as any)[k] === false) delete (style as any)[k];
      });
      cells[key] = { ...existing, s: Object.keys(style).length ? style : undefined };
    });
    commitSheet({ ...sheet, cells });
  };

  const currentStyle: CellStyle = sheet.cells[activeKey]?.s ?? {};

  /* ---------------- structural ops ---------------- */
  const shiftCells = (mode: "row" | "col", at: number, delta: number) => {
    const cells: Record<string, Cell> = {};
    Object.entries(sheet.cells).forEach(([key, cell]) => {
      const m = /^([A-Z]+)(\d+)$/.exec(key);
      if (!m) return;
      const c = colLabel;
      const col = key.replace(/\d+/g, "");
      const row = Number(m[2]) - 1;
      let colIdx = 0;
      for (const ch of col) colIdx = colIdx * 26 + (ch.charCodeAt(0) - 64);
      colIdx -= 1;

      let nr = row;
      let nc = colIdx;
      if (mode === "row" && row >= at) nr = row + delta;
      if (mode === "col" && colIdx >= at) nc = colIdx + delta;
      if (nr < 0 || nc < 0) return;
      cells[`${c(nc)}${nr + 1}`] = cell;
    });
    return cells;
  };

  const insertRow = (after: boolean) => {
    const at = Math.min(sel.r1, sel.r2) + (after ? 1 : 0);
    commitSheet({ ...sheet, rows: sheet.rows + 1, cells: shiftCells("row", at, 1) });
    console.log("[GILOX] row inserted at", at);
  };

  const insertCol = (after: boolean) => {
    const at = Math.min(sel.c1, sel.c2) + (after ? 1 : 0);
    commitSheet({ ...sheet, cols: sheet.cols + 1, cells: shiftCells("col", at, 1) });
  };

  const deleteRow = () => {
    const at = Math.min(sel.r1, sel.r2);
    const cells = { ...sheet.cells };
    for (let c = 0; c < sheet.cols; c++) delete cells[cellKey(at, c)];
    const shifted: Record<string, Cell> = {};
    Object.entries(cells).forEach(([key, cell]) => {
      const m = /^([A-Z]+)(\d+)$/.exec(key);
      if (!m) return;
      const row = Number(m[2]) - 1;
      shifted[row > at ? `${m[1]}${row}` : key] = cell;
    });
    commitSheet({ ...sheet, rows: Math.max(1, sheet.rows - 1), cells: shifted });
  };

  const deleteCol = () => {
    const at = Math.min(sel.c1, sel.c2);
    const cells: Record<string, Cell> = {};
    Object.entries(sheet.cells).forEach(([key, cell]) => {
      const m = /^([A-Z]+)(\d+)$/.exec(key);
      if (!m) return;
      let colIdx = 0;
      for (const ch of m[1]) colIdx = colIdx * 26 + (ch.charCodeAt(0) - 64);
      colIdx -= 1;
      if (colIdx === at) return;
      const nc = colIdx > at ? colIdx - 1 : colIdx;
      cells[`${colLabel(nc)}${m[2]}`] = cell;
    });
    commitSheet({ ...sheet, cols: Math.max(1, sheet.cols - 1), cells });
  };

  const mergeSelection = () => {
    const r1 = Math.min(sel.r1, sel.r2);
    const r2 = Math.max(sel.r1, sel.r2);
    const c1 = Math.min(sel.c1, sel.c2);
    const c2 = Math.max(sel.c1, sel.c2);
    if (r1 === r2 && c1 === c2) {
      // Un-merge if the active cell is already part of a merge.
      const next = (sheet.merges ?? []).filter((m) => {
        const b = rangeBounds(m);
        return !(b && r1 >= b.r1 && r1 <= b.r2 && c1 >= b.c1 && c1 <= b.c2);
      });
      if (next.length !== (sheet.merges ?? []).length) {
        commitSheet({ ...sheet, merges: next });
        toast.success("تم إلغاء الدمج");
      } else {
        toast.info("حدّد أكثر من خلية للدمج");
      }
      return;
    }
    const range = `${cellKey(r1, c1)}:${cellKey(r2, c2)}`;
    const cleaned = (sheet.merges ?? []).filter((m) => {
      const b = rangeBounds(m);
      return !(b && b.r1 <= r2 && b.r2 >= r1 && b.c1 <= c2 && b.c2 >= c1);
    });
    commitSheet({ ...sheet, merges: [...cleaned, range] });
    toast.success("تم دمج الخلايا");
  };

  const setColWidth = (w: number) => {
    const widths = { ...sheet.col_widths };
    for (let c = Math.min(sel.c1, sel.c2); c <= Math.max(sel.c1, sel.c2); c++) widths[String(c)] = w;
    commitSheet({ ...sheet, col_widths: widths });
  };

  const setRowHeight = (h: number) => {
    const heights = { ...sheet.row_heights };
    for (let r = Math.min(sel.r1, sel.r2); r <= Math.max(sel.r1, sel.r2); r++) heights[String(r)] = h;
    commitSheet({ ...sheet, row_heights: heights });
  };

  /* ---------------- sorting / filtering / find ---------------- */
  const sortByColumn = (dir: "asc" | "desc") => {
    const col = Math.min(sel.c1, sel.c2);
    const startRow = Math.min(sel.r1, sel.r2) === Math.max(sel.r1, sel.r2) ? 1 : Math.min(sel.r1, sel.r2);
    const endRow = Math.min(sel.r1, sel.r2) === Math.max(sel.r1, sel.r2) ? sheet.rows - 1 : Math.max(sel.r1, sel.r2);

    const rows: { values: Record<number, Cell | undefined>; sortKey: number | string }[] = [];
    for (let r = startRow; r <= endRow; r++) {
      const values: Record<number, Cell | undefined> = {};
      for (let c = 0; c < sheet.cols; c++) values[c] = sheet.cells[cellKey(r, c)];
      rows.push({ values, sortKey: computedValue(sheet.cells, cellKey(r, col)) });
    }
    rows.sort((a, b) => {
      const av = a.sortKey;
      const bv = b.sortKey;
      if (av === "" && bv !== "") return 1;
      if (bv === "" && av !== "") return -1;
      if (typeof av === "number" && typeof bv === "number") return dir === "asc" ? av - bv : bv - av;
      return dir === "asc"
        ? String(av).localeCompare(String(bv), "ar")
        : String(bv).localeCompare(String(av), "ar");
    });

    const cells = { ...sheet.cells };
    rows.forEach((row, i) => {
      const r = startRow + i;
      for (let c = 0; c < sheet.cols; c++) {
        const key = cellKey(r, c);
        if (row.values[c]) cells[key] = row.values[c] as Cell;
        else delete cells[key];
      }
    });
    commitSheet({ ...sheet, cells });
    toast.success(dir === "asc" ? "تم الترتيب تصاعديًا" : "تم الترتيب تنازليًا");
  };

  const replaceAll = () => {
    if (!findTerm) return;
    const cells = { ...sheet.cells };
    let count = 0;
    Object.entries(cells).forEach(([key, cell]) => {
      if (cell.v && cell.v.includes(findTerm)) {
        cells[key] = { ...cell, v: cell.v.split(findTerm).join(replaceTerm) };
        count += 1;
      }
    });
    commitSheet({ ...sheet, cells });
    toast.success(`تم الاستبدال في ${count} خلية`);
  };

  const hiddenRows = useMemo(() => {
    if (filterCol == null || !filterTerm.trim()) return new Set<number>();
    const hidden = new Set<number>();
    for (let r = 1; r < sheet.rows; r++) {
      const value = displayValue(sheet.cells, cellKey(r, filterCol));
      if (!value.toLowerCase().includes(filterTerm.trim().toLowerCase())) hidden.add(r);
    }
    return hidden;
  }, [filterCol, filterTerm, sheet]);

  const matchesFind = (key: string) => {
    if (!findOpen || !findTerm.trim()) return false;
    const raw = sheet.cells[key]?.v ?? "";
    return raw.toLowerCase().includes(findTerm.trim().toLowerCase());
  };

  /* ---------------- charts ---------------- */
  const usedRange = useMemo(() => {
    let maxR = 0;
    let maxC = 0;
    Object.keys(sheet.cells).forEach((key) => {
      const m = /^([A-Z]+)(\d+)$/.exec(key);
      if (!m) return;
      let colIdx = 0;
      for (const ch of m[1]) colIdx = colIdx * 26 + (ch.charCodeAt(0) - 64);
      maxC = Math.max(maxC, colIdx - 1);
      maxR = Math.max(maxR, Number(m[2]) - 1);
    });
    return `A1:${cellKey(maxR, maxC)}`;
  }, [sheet.cells]);

  const addChart = (kind: "bar" | "line" | "pie") => {
    const r1 = Math.min(sel.r1, sel.r2);
    const r2 = Math.max(sel.r1, sel.r2);
    const c1 = Math.min(sel.c1, sel.c2);
    const c2 = Math.max(sel.c1, sel.c2);
    const range = r1 === r2 && c1 === c2 ? usedRange : `${cellKey(r1, c1)}:${cellKey(r2, c2)}`;
    const chart: ChartDef = {
      id: `ch_${Date.now()}`,
      kind,
      title: kind === "pie" ? "توزيع البيانات" : "مخطط البيانات",
      range,
      height: 260,
    };
    commitSheet({ ...sheet, charts: [...(sheet.charts ?? []), chart] });
    toast.success("تمت إضافة المخطط");
  };

  const patchChart = (id: string, patch: Partial<ChartDef>) => {
    commitSheet({
      ...sheet,
      charts: (sheet.charts ?? []).map((c) => (c.id === id ? { ...c, ...patch } : c)),
    });
  };

  const removeChart = (id: string) => {
    commitSheet({ ...sheet, charts: (sheet.charts ?? []).filter((c) => c.id !== id) });
  };

  /* ---------------- export ---------------- */
  const [printRange, setPrintRange] = useState("");
  const getHtml = useCallback(() => {
    const range = printRange.trim() || usedRange;
    const table = sheetInnerHtml(sheet, range, { showHeaders: false, title });
    const charts = (sheet.charts ?? [])
      .map(
        (c) =>
          `<div style="margin:14px 0;page-break-inside:avoid;text-align:center">${chartSvg(sheet, c, 620)}</div>`
      )
      .join("");
    return `${table}${charts}`;
  }, [sheet, printRange, usedRange, title]);

  const toggleFavorite = () => {
    if (!file) return;
    const next = file.is_favorite === "yes" ? "no" : "yes";
    setFile({ ...file, is_favorite: next });
    void persist({ is_favorite: next });
  };

  /* ---------------- grid interactions ---------------- */
  const cellFromEvent = (target: EventTarget | null) => {
    const el = (target as HTMLElement | null)?.closest?.("[data-cell]") as HTMLElement | null;
    if (!el) return null;
    const [r, c] = (el.dataset.cell ?? "").split(",").map(Number);
    return Number.isFinite(r) && Number.isFinite(c) ? { r, c } : null;
  };

  const onPointerDown = (e: React.PointerEvent) => {
    const pos = cellFromEvent(e.target);
    if (!pos) return;
    const isSame = pos.r === sel.r1 && pos.c === sel.c1 && sel.r1 === sel.r2 && sel.c1 === sel.c2;
    if (isSame) {
      setEditing(true);
      setTimeout(() => inlineRef.current?.focus(), 0);
      return;
    }
    setEditing(false);
    anchor.current = pos;
    dragging.current = true;
    setSel({ r1: pos.r, c1: pos.c, r2: pos.r, c2: pos.c });
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!dragging.current) return;
    const pos = cellFromEvent(document.elementFromPoint(e.clientX, e.clientY));
    if (!pos) return;
    setSel({ r1: anchor.current.r, c1: anchor.current.c, r2: pos.r, c2: pos.c });
  };

  useEffect(() => {
    const up = () => {
      dragging.current = false;
    };
    window.addEventListener("pointerup", up);
    return () => window.removeEventListener("pointerup", up);
  }, []);

  const commitInline = (value: string, moveDown: boolean) => {
    setCellValue(activeKey, value);
    setEditing(false);
    if (moveDown) {
      const r = Math.min(sel.r1 + 1, sheet.rows - 1);
      setSel({ r1: r, c1: sel.c1, r2: r, c2: sel.c1 });
    }
  };

  const merges = useMemo(() => {
    const anchors = new Map<string, { rs: number; cs: number }>();
    const covered = new Set<string>();
    (sheet.merges ?? []).forEach((m) => {
      const b = rangeBounds(m);
      if (!b) return;
      anchors.set(cellKey(b.r1, b.c1), { rs: b.r2 - b.r1 + 1, cs: b.c2 - b.c1 + 1 });
      for (let r = b.r1; r <= b.r2; r++)
        for (let c = b.c1; c <= b.c2; c++)
          if (!(r === b.r1 && c === b.c1)) covered.add(cellKey(r, c));
    });
    return { anchors, covered };
  }, [sheet.merges]);

  const activePreview = formatCellValue(computedValue(sheet.cells, activeKey), currentStyle);

  return (
    <>
      <EditorShell
        backHref="/gilox"
        title={title}
        onTitleChange={handleTitleChange}
        saveState={saveState}
        accent="var(--gilox)"
        favorite={file?.is_favorite === "yes"}
        onToggleFavorite={toggleFavorite}
        actions={
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                aria-label="المزيد"
                className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-accent"
              >
                <MoreVertical className="h-4.5 w-4.5" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setPreviewOpen(true)}>
                <FileDown className="h-4 w-4" />
                معاينة وتصدير PDF
              </DropdownMenuItem>
              <DownloadPdfMenuItem
                fileId={fileId}
                getHtml={getHtml}
                setup={setup}
                title={title}
              />
              <DropdownMenuItem onClick={() => setSetupOpen(true)}>
                <Settings2 className="h-4 w-4" />
                إعداد الصفحة
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        }
        toolbar={
          <>
            <SheetToolbar
              style={currentStyle}
              onStyle={applyStyle}
              onInsertRow={insertRow}
              onInsertCol={insertCol}
              onDeleteRow={deleteRow}
              onDeleteCol={deleteCol}
              onMerge={mergeSelection}
              onColWidth={setColWidth}
              onRowHeight={setRowHeight}
              onSort={sortByColumn}
              onFilter={() => {
                setFilterCol(Math.min(sel.c1, sel.c2));
                setFilterOpen((v) => !v);
              }}
              onFind={() => setFindOpen((v) => !v)}
              onAddChart={addChart}
              onOpenSetup={() => setSetupOpen(true)}
              onPreview={() => setPreviewOpen(true)}
            />

            {/* formula bar */}
            <div className="flex items-center gap-2 border-t border-border bg-muted/40 px-2 py-2">
              <span className="w-16 shrink-0 rounded-lg bg-background px-2 py-1.5 text-center text-[13px] font-semibold tabular-nums">
                {activeKey}
              </span>
              <span className="shrink-0 text-muted-foreground">ƒ</span>
              <Input
                value={barValue}
                onChange={(e) => setBarValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    setCellValue(activeKey, barValue);
                    (e.target as HTMLInputElement).blur();
                  }
                }}
                onBlur={() => {
                  if (barValue !== (sheet.cells[activeKey]?.v ?? "")) setCellValue(activeKey, barValue);
                }}
                placeholder={`اكتب قيمة أو معادلة مثل =SUM(A1:A5)`}
                className="h-9 flex-1 font-mono text-[13px]"
                dir="ltr"
              />
            </div>

            {findOpen && (
              <div className="flex items-center gap-1.5 border-t border-border bg-muted/40 px-2 py-2">
                <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
                <Input
                  value={findTerm}
                  onChange={(e) => setFindTerm(e.target.value)}
                  placeholder="بحث في الخلايا"
                  className="h-9 flex-1"
                />
                <Input
                  value={replaceTerm}
                  onChange={(e) => setReplaceTerm(e.target.value)}
                  placeholder="استبدال بـ"
                  className="h-9 flex-1"
                />
                <button
                  type="button"
                  onClick={replaceAll}
                  className="inline-flex h-9 shrink-0 items-center rounded-lg bg-secondary px-3 text-[13px] hover:bg-accent"
                >
                  استبدال الكل
                </button>
                <button
                  type="button"
                  aria-label="إغلاق"
                  onClick={() => setFindOpen(false)}
                  className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg hover:bg-accent"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}

            {filterOpen && (
              <div className="flex items-center gap-1.5 border-t border-border bg-muted/40 px-2 py-2">
                <Filter className="h-4 w-4 shrink-0 text-muted-foreground" />
                <span className="shrink-0 text-[13px] text-muted-foreground">
                  العمود {filterCol != null ? colLabel(filterCol) : "-"}
                </span>
                <Input
                  value={filterTerm}
                  onChange={(e) => setFilterTerm(e.target.value)}
                  placeholder="أظهر الصفوف التي تحتوي على…"
                  className="h-9 flex-1"
                />
                <button
                  type="button"
                  aria-label="إغلاق التصفية"
                  onClick={() => {
                    setFilterOpen(false);
                    setFilterTerm("");
                  }}
                  className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg hover:bg-accent"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}
          </>
        }
      >
        {/* grid */}
        <div className="thin-scroll overflow-auto bg-background pb-4" style={{ maxHeight: "calc(100vh - 250px)" }}>
          <table
            className="border-collapse select-none"
            style={{ touchAction: "pan-x pan-y" }}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
          >
            <thead className="sticky top-0 z-20">
              <tr>
                <th className="gx-cell sticky right-0 z-30 w-11 bg-muted text-[11px] text-muted-foreground" />
                {Array.from({ length: sheet.cols }).map((_, c) => (
                  <th
                    key={c}
                    className={`gx-cell bg-muted px-1 py-1.5 text-[11px] font-medium text-muted-foreground ${
                      c >= Math.min(sel.c1, sel.c2) && c <= Math.max(sel.c1, sel.c2) ? "bg-primary/15 text-primary" : ""
                    }`}
                    style={{ width: sheet.col_widths[String(c)] ?? DEFAULT_COL_W, minWidth: sheet.col_widths[String(c)] ?? DEFAULT_COL_W }}
                  >
                    {colLabel(c)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {Array.from({ length: sheet.rows }).map((_, r) => {
                if (hiddenRows.has(r)) return null;
                return (
                  <tr key={r} style={{ height: sheet.row_heights[String(r)] ?? DEFAULT_ROW_H }}>
                    <th
                      className={`gx-cell sticky right-0 z-10 bg-muted px-1 text-[11px] font-medium text-muted-foreground ${
                        r >= Math.min(sel.r1, sel.r2) && r <= Math.max(sel.r1, sel.r2) ? "bg-primary/15 text-primary" : ""
                      }`}
                    >
                      {r + 1}
                    </th>
                    {Array.from({ length: sheet.cols }).map((_, c) => {
                      const key = cellKey(r, c);
                      if (merges.covered.has(key)) return null;
                      const span = merges.anchors.get(key);
                      const style = sheet.cells[key]?.s ?? {};
                      const selected = inSelection(r, c);
                      const isActive = r === sel.r1 && c === sel.c1;
                      const hit = matchesFind(key);
                      return (
                        <td
                          key={key}
                          data-cell={`${r},${c}`}
                          rowSpan={span?.rs}
                          colSpan={span?.cs}
                          className={`gx-cell relative px-1.5 text-[13px] ${selected ? "bg-primary/10" : ""} ${
                            hit ? "ring-2 ring-amber-400 ring-inset" : ""
                          } ${isActive ? "outline outline-2 -outline-offset-2 outline-primary" : ""}`}
                          style={{
                            width: sheet.col_widths[String(c)] ?? DEFAULT_COL_W,
                            minWidth: sheet.col_widths[String(c)] ?? DEFAULT_COL_W,
                            fontWeight: style.b ? 700 : undefined,
                            fontStyle: style.i ? "italic" : undefined,
                            textDecoration: style.u ? "underline" : undefined,
                            fontSize: style.fs ? `${style.fs}px` : undefined,
                            fontFamily: style.ff ? `'${style.ff}', sans-serif` : undefined,
                            color: style.c,
                            background: selected ? undefined : style.bg,
                            textAlign: style.a ?? "right",
                            whiteSpace: style.w ? "normal" : "nowrap",
                            overflow: "hidden",
                            border: style.bd ? "1.5px solid var(--foreground)" : undefined,
                          }}
                        >
                          {isActive && editing ? (
                            <input
                              ref={inlineRef}
                              defaultValue={sheet.cells[key]?.v ?? ""}
                              dir="auto"
                              onKeyDown={(e) => {
                                if (e.key === "Enter") commitInline((e.target as HTMLInputElement).value, true);
                                if (e.key === "Escape") setEditing(false);
                              }}
                              onBlur={(e) => commitInline(e.target.value, false)}
                              className="absolute inset-0 w-full bg-background px-1.5 text-[13px] outline-none"
                            />
                          ) : (
                            displayValue(sheet.cells, key)
                          )}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* status + charts */}
        <div className="border-t border-border bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
          <span className="font-medium text-foreground">{activeKey}</span>
          {activePreview !== "" && <span> = {activePreview}</span>}
          <span className="mr-3">الدوال المدعومة: {SUPPORTED_FUNCTIONS.join("، ")}</span>
        </div>

        {(sheet.charts ?? []).length > 0 && (
          <section className="space-y-3 px-3 py-4">
            <h2 className="font-display text-sm font-semibold">الرسوم البيانية</h2>
            {(sheet.charts ?? []).map((chart) => (
              <div key={chart.id} className="rounded-2xl border border-border bg-card p-3">
                <div className="mb-2 flex items-center gap-2">
                  <span className="flex-1 truncate text-sm font-medium">{chart.title}</span>
                  <span className="rounded-md bg-secondary px-1.5 py-0.5 font-mono text-[11px]" dir="ltr">
                    {chart.range}
                  </span>
                  <button
                    type="button"
                    aria-label="تعديل المخطط"
                    onClick={() => setEditChart(chart)}
                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg hover:bg-accent"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    aria-label="حذف المخطط"
                    onClick={() => removeChart(chart.id)}
                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div
                  className="overflow-x-auto rounded-xl bg-white p-2"
                  dangerouslySetInnerHTML={{ __html: chartSvg(sheet, chart, 620) }}
                />
              </div>
            ))}
          </section>
        )}

        {/* print range */}
        <div className="px-3 pb-24">
          <Label htmlFor="print-range" className="text-xs text-muted-foreground">
            نطاق الطباعة (اتركه فارغًا لطباعة كل البيانات)
          </Label>
          <Input
            id="print-range"
            value={printRange}
            onChange={(e) => setPrintRange(e.target.value)}
            placeholder={usedRange}
            dir="ltr"
            className="mt-1.5 h-10 font-mono"
          />
        </div>
      </EditorShell>

      {/* chart editor */}
      {editChart && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-0 sm:items-center sm:p-4">
          <div className="w-full max-w-md rounded-t-3xl border border-border bg-background p-4 sm:rounded-3xl">
            <h3 className="mb-3 font-display font-semibold">تعديل المخطط</h3>
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="ch-title" className="text-xs">عنوان المخطط</Label>
                <Input
                  id="ch-title"
                  value={editChart.title}
                  onChange={(e) => setEditChart({ ...editChart, title: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ch-range" className="text-xs">نطاق البيانات</Label>
                <Input
                  id="ch-range"
                  dir="ltr"
                  className="font-mono"
                  value={editChart.range}
                  onChange={(e) => setEditChart({ ...editChart, range: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ch-height" className="text-xs">ارتفاع المخطط</Label>
                <Input
                  id="ch-height"
                  type="number"
                  value={editChart.height}
                  onChange={(e) =>
                    setEditChart({ ...editChart, height: e.target.value === "" ? 200 : Number(e.target.value) })
                  }
                />
              </div>
              <div className="grid grid-cols-3 gap-2">
                {(["bar", "line", "pie"] as const).map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => setEditChart({ ...editChart, kind: k })}
                    className={`rounded-xl border px-3 py-2 text-sm ${
                      editChart.kind === k ? "border-primary bg-primary/10 text-primary" : "border-border"
                    }`}
                  >
                    {k === "bar" ? "أعمدة" : k === "line" ? "خطي" : "دائري"}
                  </button>
                ))}
              </div>
            </div>
            <div className="mt-4 flex gap-2">
              <button
                type="button"
                onClick={() => {
                  patchChart(editChart.id, editChart);
                  setEditChart(null);
                }}
                className="flex-1 rounded-xl bg-foreground py-2.5 text-sm font-medium text-background"
              >
                حفظ
              </button>
              <button
                type="button"
                onClick={() => setEditChart(null)}
                className="rounded-xl border border-border px-4 py-2.5 text-sm"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      <PageSetupSheet
        open={setupOpen}
        onOpenChange={setSetupOpen}
        setup={setup}
        onChange={(next) => {
          setSetup(next);
          void persist({ page_setup: JSON.stringify(next) });
        }}
      />
      <PreviewDialog
        open={previewOpen}
        onOpenChange={setPreviewOpen}
        getHtml={getHtml}
        setup={setup}
        title={title}
        fileId={fileId}
      />
    </>
  );
}

export const Route = createFileRoute("/gilox/$id")({
  head: () => ({
    meta: [
      { title: "محرر الجداول — EVA Office" },
      { name: "description", content: "حرر جداول بياناتك ومعادلاتك في GILOX." },
      { property: "og:title", content: "محرر الجداول — EVA Office" },
      { property: "og:description", content: "حرر جداول بياناتك ومعادلاتك في GILOX." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SheetEditorPage,
});
