import { createFileRoute } from "@tanstack/react-router";
import { AppLibrary } from "@/components/office/AppLibrary";

function GiloxLibraryPage() {
  return (
    <AppLibrary
      app="gilox"
      description="جداول بيانات بتجربة مكتبية مبسّطة للمس: تنسيق كامل للخلايا، معادلات SUM وAVERAGE وMIN وMAX وCOUNT، فرز وتصفية، رسوم بيانية، وتصدير جاهز للطباعة."
      createOptions={[{ label: "جدول جديد", doc_type: "spreadsheet", title: "جدول بيانات جديد" }]}
    />
  );
}

export const Route = createFileRoute("/gilox/")({
  head: () => ({
    meta: [
      { title: "جداول GILOX — EVA Office" },
      { name: "description", content: "أنشئ الجداول واحسب بياناتك في EVA Office." },
      { property: "og:title", content: "جداول GILOX — EVA Office" },
      { property: "og:description", content: "أنشئ الجداول واحسب بياناتك في EVA Office." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: GiloxLibraryPage,
});
