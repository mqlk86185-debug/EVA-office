import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { Link } from "@/components/office/Link";
import { toast } from "sonner";
import { Plus, Search, Star, Trash2, FolderOpen, ArrowLeft, Sparkles, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AppMark, OfficeWordmark } from "@/components/office/AppMark";
import { BottomNav } from "@/components/office/BottomNav";
import { ThemeToggle } from "@/components/office/ThemeToggle";
import { FileCard } from "@/components/office/FileCard";
import { NewFileDialog } from "@/components/office/NewFileDialog";
import { Skeleton } from "@/components/ui/skeleton";
import { listFiles, updateFile, shareUrl } from "@/lib/office/client";
import { APP_META, fileHref, type AppType, type OfficeFile } from "@/lib/office/types";

const APPS: { app: AppType; blurb: string }[] = [
  { app: "eva", blurb: "أنشئ المستندات والاختبارات، نسّقها، ثم صدّرها PDF بدقة." },
  { app: "pdf", blurb: "اقرأ، ابحث، علّق، وأعد ترتيب صفحات ملفاتك بسرعة." },
  { app: "gilox", blurb: "جداول ومعادلات ورسوم بيانية جاهزة للطباعة." },
  { app: "novel", blurb: "مفكرة وحافظة نصوص: دوّن، احفظ، ابحث وانسخ بسرعة." },
];

function Home() {
  const [files, setFiles] = useState<OfficeFile[] | null>(null);
  const [newOpen, setNewOpen] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await listFiles({ limit: 12 });
      setFiles(data);
      console.log("[Home] loaded", data.length, "recent files");
    } catch (err) {
      console.error("[Home] failed to load recent files:", err);
      toast.error("تعذّر تحميل الملفات الأخيرة");
      setFiles([]);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const toggleFavorite = async (file: OfficeFile) => {
    const next = file.is_favorite === "yes" ? "no" : "yes";
    setFiles((prev) => prev?.map((f) => (f._id === file._id ? { ...f, is_favorite: next } : f)) ?? null);
    try {
      await updateFile(file._id, { is_favorite: next });
    } catch (err) {
      console.error("[Home] favorite toggle failed:", err);
      toast.error("تعذّر تحديث المفضلة");
      void load();
    }
  };

  const trash = async (file: OfficeFile) => {
    setFiles((prev) => prev?.filter((f) => f._id !== file._id) ?? null);
    try {
      await updateFile(file._id, { is_trashed: "yes" });
      toast.success("تم النقل إلى سلة المحذوفات");
    } catch (err) {
      console.error("[Home] trash failed:", err);
      toast.error("تعذّر نقل الملف");
      void load();
    }
  };

  const share = async (file: OfficeFile) => {
    try {
      const how = await shareUrl(file.title, fileHref(file));
      toast.success(how === "copied" ? "تم نسخ الرابط" : "تمت المشاركة");
    } catch (err) {
      console.error("[Home] share failed:", err);
      toast.error("تعذّرت المشاركة");
    }
  };

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-5xl flex-col px-4 pt-4">
      {/* ---- top bar ---- */}
      <header className="flex items-center justify-between gap-2">
        <div className="text-right">
          <OfficeWordmark />
        </div>
        <div className="flex items-center gap-2">
          <Link
            href="/files"
            aria-label="بحث"
            className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-card transition-colors hover:bg-accent"
          >
            <Search className="h-4.5 w-4.5" />
          </Link>
          <ThemeToggle />
        </div>
      </header>

      {/* ---- hero ---- */}
      <section className="eva-rise pt-8 pb-6">
        <p className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1 text-xs text-muted-foreground">
          <Sparkles className="h-3.5 w-3.5" />
          حزمة مكتبية متكاملة للهاتف واللوحي
        </p>
        <h1 className="mt-4 font-display text-[2rem] font-semibold leading-[1.25] tracking-tight sm:text-5xl">
          اكتب، احسب، واقرأ
          <span className="block text-muted-foreground">داخل منظومة واحدة.</span>
        </h1>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">
          ثلاثة تطبيقات — EVA للمستندات والاختبارات، PDF للقراءة والإدارة، وGILOX للجداول
          والحسابات — بواجهة سريعة مصممة للمس.
        </p>

        <div className="mt-5 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setNewOpen(true)}
            className="inline-flex items-center gap-2 rounded-xl bg-foreground px-4 py-2.5 text-sm font-medium text-background transition-transform active:scale-[.98]"
          >
            <Plus className="h-4 w-4" />
            إنشاء ملف جديد
          </button>
          <Link
            href="/files"
            className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5 text-sm font-medium transition-colors hover:bg-accent"
          >
            <FolderOpen className="h-4 w-4" />
            إدارة الملفات
          </Link>
        </div>
      </section>

      {/* ---- the three apps ---- */}
      <section className="grid gap-3 sm:grid-cols-3">
        {APPS.map(({ app, blurb }, i) => {
          const meta = APP_META[app];
          return (
            <Link
              key={app}
              href={meta.href}
              className="eva-rise group relative overflow-hidden rounded-3xl border border-border bg-card p-5 transition-all hover:-translate-y-0.5 hover:shadow-[0_18px_45px_-24px_rgba(16,18,35,.6)]"
              style={{ animationDelay: `${80 + i * 70}ms` }}
            >
              <span
                aria-hidden
                className="pointer-events-none absolute -left-10 -top-10 h-32 w-32 rounded-full opacity-[.16] blur-2xl transition-opacity group-hover:opacity-30"
                style={{ background: meta.color }}
              />
              <span
                className="relative flex h-12 w-12 items-center justify-center rounded-2xl"
                style={{
                  background: `color-mix(in oklab, ${meta.color} 14%, transparent)`,
                  color: meta.color,
                }}
              >
                <AppMark app={app} className="h-7 w-7" />
              </span>
              <h2 className="relative mt-4 font-display text-xl font-semibold tracking-tight">
                {meta.name}
              </h2>
              <p className="relative text-sm font-medium" style={{ color: meta.color }}>
                {meta.tagline}
              </p>
              <p className="relative mt-2 text-xs leading-relaxed text-muted-foreground">{blurb}</p>
              <span className="relative mt-3 inline-flex items-center gap-1 text-xs font-medium text-muted-foreground transition-colors group-hover:text-foreground">
                افتح التطبيق
                <ArrowLeft className="h-3.5 w-3.5" />
              </span>
            </Link>
          );
        })}
      </section>

      <Button asChild variant="outline" className="mt-4 h-auto justify-start gap-4 whitespace-normal px-5 py-4">
        <Link href="/dictionary">
          <BookOpen className="size-6 shrink-0 text-gilox" />
          <span className="min-w-0 flex-1 text-right"><span className="block font-display text-lg font-semibold">مُعجمي — القاموس</span><span className="mt-1 block text-sm text-muted-foreground">29,899 كلمة · عربي / English</span></span>
          <ArrowLeft className="shrink-0 text-muted-foreground" />
        </Link>
      </Button>

      {/* ---- quick shortcuts ---- */}
      <section className="mt-6 grid grid-cols-3 gap-2">
        <Link
          href="/files?view=favorites"
          className="flex flex-col items-center gap-1.5 rounded-2xl border border-border bg-card px-3 py-4 text-xs font-medium transition-colors hover:bg-accent"
        >
          <Star className="h-5 w-5 text-amber-500" />
          المفضلة
        </Link>
        <Link
          href="/files"
          className="flex flex-col items-center gap-1.5 rounded-2xl border border-border bg-card px-3 py-4 text-xs font-medium transition-colors hover:bg-accent"
        >
          <FolderOpen className="h-5 w-5 text-primary" />
          كل الملفات
        </Link>
        <Link
          href="/files?view=trash"
          className="flex flex-col items-center gap-1.5 rounded-2xl border border-border bg-card px-3 py-4 text-xs font-medium transition-colors hover:bg-accent"
        >
          <Trash2 className="h-5 w-5 text-muted-foreground" />
          سلة المحذوفات
        </Link>
      </section>

      {/* ---- recent files ---- */}
      <section className="mt-8 flex-1">
        <div className="mb-3 flex items-end justify-between">
          <h2 className="font-display text-lg font-semibold tracking-tight">الملفات الأخيرة</h2>
          <Link href="/files" className="text-xs text-muted-foreground hover:text-foreground">
            عرض الكل
          </Link>
        </div>

        {files === null ? (
          <div className="space-y-2">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-[68px] rounded-2xl" />
            ))}
          </div>
        ) : files.length === 0 ? (
          <div className="rounded-3xl border border-dashed border-border p-8 text-center">
            <p className="font-medium">لا توجد ملفات بعد</p>
            <p className="mt-1 text-sm text-muted-foreground">
              ابدأ بإنشاء مستند، اختبار، أو جدول بيانات.
            </p>
            <button
              type="button"
              onClick={() => setNewOpen(true)}
              className="mt-4 inline-flex items-center gap-2 rounded-xl bg-foreground px-4 py-2 text-sm font-medium text-background"
            >
              <Plus className="h-4 w-4" />
              ملف جديد
            </button>
          </div>
        ) : (
          <div className="grid gap-2 sm:grid-cols-2">
            {files.map((file) => (
              <FileCard
                key={file._id}
                file={file}
                onToggleFavorite={toggleFavorite}
                onTrash={trash}
                onShare={share}
              />
            ))}
          </div>
        )}
      </section>

      <button
        type="button"
        onClick={() => setNewOpen(true)}
        aria-label="ملف جديد"
        className="no-print fixed bottom-20 left-4 z-40 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-foreground text-background shadow-[0_14px_35px_-12px_rgba(16,18,35,.7)] transition-transform active:scale-95 md:bottom-8"
      >
        <Plus className="h-6 w-6" />
      </button>

      <NewFileDialog open={newOpen} onOpenChange={(o) => { setNewOpen(o); if (!o) void load(); }} />
      <BottomNav />
    </div>
  );
}

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "EVA Office — مستنداتي" },
      { name: "description", content: "أنشئ مستنداتك وجداولك واقرأ ملفات PDF في EVA Office." },
      { property: "og:title", content: "EVA Office — مستنداتي" },
      { property: "og:description", content: "أنشئ مستنداتك وجداولك واقرأ ملفات PDF في EVA Office." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Home,
});
