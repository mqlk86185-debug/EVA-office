import { saveBlob } from "@/lib/office/client";
import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { ChevronRight, Copy, Download, FileDown, Loader2, Printer, Star, Trash2, Type } from "lucide-react";
import { Link } from "@/components/office/Link";
import { useParams, useRouter } from "@/lib/office/nav";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/office/ThemeToggle";
import { getFile, updateFile } from "@/lib/office/client";
import { downloadPdfNow } from "@/lib/office/quick-export";
import { DEFAULT_PAGE_SETUP, safeJson, type OfficeFile } from "@/lib/office/types";

interface NoteContent {
  text: string;
  font_size: number;
}

const DEFAULT_NOTE: NoteContent = { text: "", font_size: 17 };

function NoteEditorPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const noteId = params.id;

  const [file, setFile] = useState<OfficeFile | null>(null);
  const [title, setTitle] = useState("");
  const [note, setNote] = useState<NoteContent>(DEFAULT_NOTE);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await getFile(noteId);
        if (cancelled) return;
        setFile(data);
        setTitle(data.title);
        setNote(safeJson<NoteContent>(data.content, DEFAULT_NOTE));
        void updateFile(noteId, { last_opened_at: new Date().toISOString() }).catch(() => {});
      } catch (err) {
        console.error("[NOVEL] open failed:", err);
        toast.error("تعذّر فتح المذكرة");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [noteId]);

  const persist = useCallback(
    (nextTitle: string, nextNote: NoteContent) => {
      if (timer.current) clearTimeout(timer.current);
      setSaving(true);
      timer.current = setTimeout(() => {
        void updateFile(noteId, { title: nextTitle || "بدون عنوان", content: JSON.stringify(nextNote) })
          .catch((err) => {
            console.error("[NOVEL] save failed:", err);
            toast.error("تعذّر الحفظ");
          })
          .finally(() => setSaving(false));
      }, 600);
    },
    [noteId],
  );

  const onText = (text: string) => {
    const next = { ...note, text };
    setNote(next);
    persist(title, next);
  };

  const onTitle = (value: string) => {
    setTitle(value);
    persist(value, note);
  };

  const changeFontSize = (delta: number) => {
    const next = { ...note, font_size: Math.min(28, Math.max(13, note.font_size + delta)) };
    setNote(next);
    persist(title, next);
  };

  const stats = useMemo(() => {
    const words = note.text.trim() ? note.text.trim().split(/\s+/).length : 0;
    return { words, chars: note.text.length };
  }, [note.text]);

  const copyAll = async () => {
    try {
      await navigator.clipboard.writeText(note.text);
      toast.success("تم نسخ النص");
    } catch (err) {
      console.error("[NOVEL] copy failed:", err);
      toast.error("تعذّر النسخ");
    }
  };

  const escapeHtml = (s: string) =>
    s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

  /** ينزّل المذكرة كملف PDF حقيقي على الجهاز مباشرةً. */
  const downloadPdf = async () => {
    if (exporting) return;
    setExporting(true);
    const toastId = toast.loading("جارٍ تجهيز ملف PDF…");
    try {
      const body = (note.text || "")
        .split(/\n/)
        .map((line) =>
          line.trim()
            ? `<p style="font-size:${note.font_size}px;line-height:2;margin:0 0 6px">${escapeHtml(line)}</p>`
            : `<p style="margin:0 0 6px"><br></p>`,
        )
        .join("");
      const html =
        `<h1 style="font-size:22px;margin:0 0 4px">${escapeHtml(title || "بدون عنوان")}</h1>` +
        `<p style="color:#6b7280;font-size:12px;margin:0 0 14px">${new Date().toLocaleDateString("ar")} · ${stats.words} كلمة</p>` +
        body;
      const pages = await downloadPdfNow(noteId, html, DEFAULT_PAGE_SETUP, title || "مذكرة");
      toast.success(`تم تنزيل ملف PDF (${pages} صفحة)`, { id: toastId });
    } catch (err) {
      console.error("[NOVEL] pdf download failed:", err);
      toast.error("تعذّر تنزيل ملف PDF", { id: toastId, description: (err as Error).message });
    } finally {
      setExporting(false);
    }
  };

  const downloadTxt = () => {
    const blob = new Blob([`${title}\n\n${note.text}`], { type: "text/plain;charset=utf-8" });
    void saveBlob(blob, `${title || "مذكرة"}.txt`);
  };

  const toggleFavorite = async () => {
    if (!file) return;
    const next = file.is_favorite === "yes" ? "no" : "yes";
    setFile({ ...file, is_favorite: next });
    try {
      await updateFile(noteId, { is_favorite: next });
    } catch (err) {
      console.error("[NOVEL] favorite failed:", err);
    }
  };

  const trash = async () => {
    try {
      await updateFile(noteId, { is_trashed: "yes" });
      toast.success("تم النقل إلى سلة المحذوفات");
      router.push("/novel");
    } catch (err) {
      console.error("[NOVEL] trash failed:", err);
      toast.error("تعذّر الحذف");
    }
  };

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-3xl flex-col px-4 pt-4">
      <header className="no-print flex items-center gap-2">
        <Link
          href="/novel"
          aria-label="رجوع"
          className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
        >
          <ChevronRight className="h-5 w-5" />
        </Link>
        <Input
          value={title}
          onChange={(e) => onTitle(e.target.value)}
          placeholder="عنوان المذكرة"
          className="h-10 flex-1 border-none bg-transparent px-1 text-base font-medium shadow-none focus-visible:ring-0"
        />
        <button
          type="button"
          onClick={toggleFavorite}
          aria-label="مفضلة"
          className="inline-flex h-10 w-10 items-center justify-center rounded-xl hover:bg-accent"
        >
          <Star className={`h-4.5 w-4.5 ${file?.is_favorite === "yes" ? "fill-amber-400 text-amber-500" : "text-muted-foreground"}`} />
        </button>
        <ThemeToggle />
      </header>

      <div className="no-print mt-2 flex flex-wrap items-center gap-2">
        <Button variant="outline" size="sm" onClick={() => void copyAll()}>
          <Copy className="ml-1.5 h-4 w-4" /> نسخ
        </Button>
        <Button variant="outline" size="sm" onClick={downloadTxt}>
          <Download className="ml-1.5 h-4 w-4" /> تنزيل نصي
        </Button>
        <Button variant="outline" size="sm" onClick={() => void downloadPdf()} disabled={exporting}>
          {exporting ? (
            <Loader2 className="ml-1.5 h-4 w-4 animate-spin" />
          ) : (
            <FileDown className="ml-1.5 h-4 w-4" />
          )}
          تحميل PDF
        </Button>
        <Button variant="outline" size="sm" onClick={() => void downloadPdf()}>
          <Printer className="ml-1.5 h-4 w-4" /> طباعة
        </Button>
        <div className="flex items-center gap-1 rounded-xl border border-border px-1.5 py-1">
          <button type="button" aria-label="تصغير الخط" className="px-2 text-sm" onClick={() => changeFontSize(-1)}>
            −
          </button>
          <Type className="h-4 w-4 text-muted-foreground" />
          <button type="button" aria-label="تكبير الخط" className="px-2 text-sm" onClick={() => changeFontSize(1)}>
            +
          </button>
        </div>
        <Button variant="ghost" size="sm" className="text-destructive" onClick={() => void trash()}>
          <Trash2 className="ml-1.5 h-4 w-4" /> حذف
        </Button>
        <span className="ms-auto text-xs text-muted-foreground">
          {saving ? (
            <span className="inline-flex items-center gap-1">
              <Loader2 className="h-3 w-3 animate-spin" /> جارٍ الحفظ
            </span>
          ) : (
            `${stats.words} كلمة · ${stats.chars} حرفًا`
          )}
        </span>
      </div>

      <textarea
        value={note.text}
        onChange={(e) => onText(e.target.value)}
        disabled={loading}
        dir="auto"
        placeholder="اكتب هنا… يتم الحفظ تلقائيًا على جهازك."
        style={{ fontSize: `${note.font_size}px` }}
        className="mt-3 min-h-[65vh] w-full flex-1 resize-none rounded-3xl border border-border bg-card p-5 leading-[2] outline-none transition-colors focus:border-foreground/25"
      />

      <div className="h-6" />
    </div>
  );
}

export const Route = createFileRoute("/novel/$id")({

  head: () => ({
    meta: [
      { title: "محرر المذكرة — EVA Office" },
      { name: "description", content: "اكتب مذكرتك واحفظ نصوصك في NOVEL." },
      { property: "og:title", content: "محرر المذكرة — EVA Office" },
      { property: "og:description", content: "اكتب مذكرتك واحفظ نصوصك في NOVEL." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: NoteEditorPage,
});
