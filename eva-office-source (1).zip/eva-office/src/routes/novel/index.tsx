import { createFileRoute } from "@tanstack/react-router";
import { AppLibrary } from "@/components/office/AppLibrary";

function NovelLibraryPage() {
  return (
    <AppLibrary
      app="novel"
      description="مفكرة سريعة وحافظة نصوص: دوّن أفكارك، احفظ المقاطع المهمة، ابحث فيها لاحقًا وانسخها بضغطة واحدة."
      createOptions={[{ label: "مذكرة جديدة", doc_type: "note", title: "مذكرة جديدة" }]}
    />
  );
}

export const Route = createFileRoute("/novel/")({

  head: () => ({
    meta: [
      { title: "مفكرة NOVEL — EVA Office" },
      { name: "description", content: "دوّن ملاحظاتك ونظم النصوص المحفوظة في NOVEL." },
      { property: "og:title", content: "مفكرة NOVEL — EVA Office" },
      { property: "og:description", content: "دوّن ملاحظاتك ونظم النصوص المحفوظة في NOVEL." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: NovelLibraryPage,
});
