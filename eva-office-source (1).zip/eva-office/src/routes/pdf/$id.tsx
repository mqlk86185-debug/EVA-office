import { useToolbarsHidden } from "@/lib/office/toolbars-hidden";
import { ToolbarsToggleButton } from "@/components/office/ToolbarsToggleButton";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronRight, ChevronLeft, Download, FileText, Grid2X2, Loader2, Minus, Plus, Search, X } from "lucide-react";
import { toast } from "sonner";
import { Link } from "@/components/office/Link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PageManager } from "@/components/office/pdf/PageManager";
import { createFile, downloadStoredPdf, getFile, updateFile } from "@/lib/office/client";
import { fetchPdfBytes, loadPdfjs } from "@/lib/office/pdfjs";
import type { OfficeFile } from "@/lib/office/types";
import { useDocumentZoom } from "@/hooks/use-document-zoom";
import { DocumentViewControls } from "@/components/office/DocumentViewControls";
import type { PDFDocumentProxy } from "pdfjs-dist";

function PdfPage() {
  const { id } = Route.useParams();
  const [file, setFile] = useState<OfficeFile | null>(null);
  const [document, setDocument] = useState<PDFDocumentProxy | null>(null);
  const [page, setPage] = useState(1);
  const [pageWidth, setPageWidth] = useState(612);
  const tools = useToolbarsHidden();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [managerOpen, setManagerOpen] = useState(false);
  const [thumbsOpen, setThumbsOpen] = useState(false);
  const [thumbnails, setThumbnails] = useState<string[]>([]);
  const [searchOpen, setSearchOpen] = useState(false);
  const [term, setTerm] = useState("");
  const [results, setResults] = useState<number[]>([]);
  const [searching, setSearching] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { viewportRef: scrollRef, zoom, minimum, maximum, changeZoom, resetZoom } = useDocumentZoom(pageWidth, 48, !loading && !error);
  const dragRef = useRef<{ x: number; y: number; left: number; top: number } | null>(null);
  const displayedPage = useRef(0);
  const [dragging, setDragging] = useState(false);
  const renderId = useRef(0);
  const [revision, setRevision] = useState(0);
  const [converting, setConverting] = useState(false);
  const navigate = useNavigate();
  const convertToEva = async () => {
    if (!file?.pdf_file?.url) return;
    setConverting(true);
    try {
      const { pdfBytesToDocument, importedPayload } = await import("@/lib/office/import-document");
      const doc = await pdfBytesToDocument(await fetchPdfBytes(file.pdf_file.url), file.title);
      const created = await createFile(importedPayload(doc));
      toast.success("تم التحويل إلى EVA — النص قابل للتحرير");
      void navigate({ to: "/eva/$id", params: { id: created._id } });
    } catch (err) {
      toast.error("تعذّر التحويل", { description: (err as Error).message });
    } finally { setConverting(false); }
  };

  useEffect(() => {
    let cancelled = false;
    let loaded: PDFDocumentProxy | null = null;
    setLoading(true);
    setError("");
    setDocument(null);
    setThumbnails([]);
    (async () => {
      try {
        const found = await getFile(id);
        if (!found.pdf_file?.url) throw new Error("لم يُعثر على محتوى ملف PDF");
        const [pdfjs, bytes] = await Promise.all([loadPdfjs(), fetchPdfBytes(found.pdf_file.url)]);
        loaded = await pdfjs.getDocument({ data: bytes }).promise;
        if (cancelled) { await loaded.destroy(); return; }
        setFile(found);
        setDocument(loaded);
        setPage(Math.min(Math.max(found.last_page_read ?? 1, 1), loaded.numPages));
        void updateFile(id, { last_opened_at: new Date().toISOString(), page_count: loaded.numPages });
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : "تعذّر فتح الملف");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; if (loaded) void loaded.destroy(); };
  }, [id, revision]);

  useEffect(() => {
    if (!document) return;
    let cancelled = false;
    const current = ++renderId.current;
    let task: ReturnType<Awaited<ReturnType<PDFDocumentProxy["getPage"]>>["render"]> | null = null;
    (async () => {
      try {
        const pdfPage = await document.getPage(page);
        if (cancelled) return;
        const canvas = canvasRef.current;
        const context = canvas?.getContext("2d");
        if (!canvas || !context) return;
        setPageWidth(pdfPage.getViewport({ scale: 1 }).width);
        const displayViewport = pdfPage.getViewport({ scale: zoom });
        // Supersample even on low-density displays, while bounding canvas memory.
        const density = Math.min(Math.max(2, window.devicePixelRatio || 1), 3,
          Math.sqrt(16_000_000 / (displayViewport.width * displayViewport.height)));
        const viewport = pdfPage.getViewport({ scale: zoom * density });
        // Never clear or resize the visible canvas while PDF.js is still drawing.
        const buffer = window.document.createElement("canvas");
        buffer.width = Math.ceil(viewport.width);
        buffer.height = Math.ceil(viewport.height);
        const bufferContext = buffer.getContext("2d");
        if (!bufferContext) return;
        task = pdfPage.render({ canvasContext: bufferContext, viewport });
        await task.promise;
        if (cancelled || current !== renderId.current) return;
        const scroller = scrollRef.current;
        const previousWidth = canvas.clientWidth;
        const previousHeight = canvas.clientHeight;
        const samePage = displayedPage.current === page;
        const centerX = scroller && previousWidth ? (scroller.scrollLeft + scroller.clientWidth / 2 - canvas.offsetLeft) / previousWidth : 0.5;
        const centerY = scroller && previousHeight ? (scroller.scrollTop + scroller.clientHeight / 2 - canvas.offsetTop) / previousHeight : 0;
        canvas.width = buffer.width;
        canvas.height = buffer.height;
        canvas.style.width = `${displayViewport.width}px`;
        canvas.style.height = `${displayViewport.height}px`;
        context.drawImage(buffer, 0, 0);
        if (scroller) {
          scroller.scrollLeft = samePage ? canvas.offsetLeft + centerX * displayViewport.width - scroller.clientWidth / 2 : Math.max(0, canvas.offsetLeft + displayViewport.width - scroller.clientWidth);
          scroller.scrollTop = samePage ? canvas.offsetTop + centerY * displayViewport.height - scroller.clientHeight / 2 : 0;
        }
        displayedPage.current = page;
        void updateFile(id, { last_page_read: page });
      } catch (err) {
        if (!cancelled && (err as Error).name !== "RenderingCancelledException") toast.error("تعذّر عرض الصفحة");
      }
    })();
    return () => { cancelled = true; task?.cancel(); };
  }, [document, page, zoom, id]);

  useEffect(() => {
    if (!document || (!thumbsOpen && !managerOpen)) return;
    let cancelled = false;
    (async () => {
      const previews: string[] = [];
      for (let i = 1; i <= document.numPages; i++) {
        try {
          const pdfPage = await document.getPage(i);
          const viewport = pdfPage.getViewport({ scale: 0.25 });
          const canvas = window.document.createElement("canvas");
          canvas.width = Math.ceil(viewport.width);
          canvas.height = Math.ceil(viewport.height);
          const context = canvas.getContext("2d");
          if (!context || cancelled) break;
          await pdfPage.render({ canvasContext: context, viewport }).promise;
          previews.push(canvas.toDataURL());
          if (!cancelled) setThumbnails([...previews]);
        } catch { break; }
      }
    })();
    return () => { cancelled = true; };
  }, [document, thumbsOpen, managerOpen]);

  const search = useCallback(async () => {
    if (!document || !term.trim()) { setResults([]); return; }
    setSearching(true);
    try {
      const matches: number[] = [];
      for (let i = 1; i <= document.numPages; i++) {
        const content = await (await document.getPage(i)).getTextContent();
        const text = content.items.map((item) => "str" in item ? item.str : "").join(" ").toLocaleLowerCase();
        if (text.includes(term.trim().toLocaleLowerCase())) matches.push(i);
      }
      setResults(matches);
      if (matches[0] !== undefined) setPage(matches[0]);
    } catch { toast.error("تعذّر البحث في الملف"); }
    finally { setSearching(false); }
  }, [document, term]);

  return (
    <div className="flex h-dvh min-h-0 flex-col overflow-hidden bg-background" dir="rtl">
      <header className="z-30 shrink-0 border-b border-border bg-background/95 backdrop-blur-xl">
        <div className="mx-auto grid max-w-6xl grid-cols-[minmax(0,1fr)_auto] items-center gap-2 px-3 py-2">
          <div className="flex min-w-0 items-center gap-2"><Link href="/pdf" aria-label="العودة إلى الملفات" className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md hover:bg-accent"><ChevronRight className="h-5 w-5" /></Link>
          <div className="min-w-0 flex-1"><h1 className="truncate text-sm font-semibold">{file?.title ?? "قارئ PDF"}</h1><p className="text-xs text-muted-foreground">{document ? `${document.numPages} صفحة` : "EVA Office PDF"}</p></div></div>
          <div className="flex shrink-0 items-center">
          {!tools.hidden && <>
          <Button variant="ghost" size="icon" title="بحث" aria-label="بحث" onClick={() => setSearchOpen(!searchOpen)}><Search /></Button>
          <Button variant="ghost" size="icon" title="الصفحات" aria-label="الصفحات" onClick={() => setThumbsOpen(!thumbsOpen)}><Grid2X2 /></Button>
          <Button variant="ghost" size="sm" title="تحويل إلى EVA" aria-label="تحويل إلى EVA" disabled={!file || converting} onClick={() => void convertToEva()}>{converting ? <Loader2 className="animate-spin" /> : <FileText />}<span className="hidden sm:inline">تحويل إلى EVA</span></Button>
          <Button variant="ghost" size="icon" title="تنزيل" aria-label="تنزيل" disabled={!file} onClick={() => { if (file) void downloadStoredPdf(file._id, file.title).catch(() => toast.error("تعذّر تنزيل الملف")); }}><Download /></Button>
          </>}
          <ToolbarsToggleButton hidden={tools.hidden} onToggle={tools.toggle} />
          </div>
        </div>
        {searchOpen && !tools.hidden && <form className="mx-auto flex max-w-6xl items-center gap-2 px-3 pb-2" onSubmit={(e) => { e.preventDefault(); void search(); }}><Input value={term} onChange={e => setTerm(e.target.value)} placeholder="ابحث في النص" aria-label="ابحث في النص" className="flex-1" /><Button type="submit" disabled={searching}>{searching ? <Loader2 className="animate-spin" /> : <Search />} بحث</Button><span className="text-xs text-muted-foreground">{results.length ? `${results.length} صفحة` : ""}</span><Button type="button" variant="ghost" size="icon" aria-label="إغلاق البحث" onClick={() => setSearchOpen(false)}><X /></Button></form>}
      </header>
      {loading ? <div className="flex flex-1 items-center justify-center gap-2 text-muted-foreground"><Loader2 className="animate-spin" /> جارٍ فتح الملف…</div> : error ? <div className="mx-auto my-20 space-y-4 text-center"><p className="text-destructive">{error}</p><Button onClick={() => setRevision(v => v + 1)}>إعادة المحاولة</Button></div> : (
        <div className="flex min-h-0 w-full min-w-0 flex-1 overflow-hidden">
          {thumbsOpen && <aside className="w-28 shrink-0 space-y-3 overflow-y-auto border-l border-border bg-card p-2 sm:w-40" aria-label="مصغرات الصفحات">{thumbnails.map((src, index) => <Button key={index} variant={page === index + 1 ? "secondary" : "ghost"} className="h-auto w-full flex-col gap-1 p-1" onClick={() => setPage(index + 1)}><img src={src} alt={`صفحة ${index + 1}`} className="max-h-36 max-w-full object-contain" /><span>{index + 1}</span></Button>)}</aside>}
          <main id="pdf-document" ref={scrollRef} dir="ltr" tabIndex={0} aria-label="عرض صفحة PDF" className={`relative min-h-0 min-w-0 flex-1 touch-pan-x touch-pan-y overflow-auto overscroll-contain bg-muted/50 outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring ${dragging ? "cursor-grabbing select-none" : "cursor-grab"}`}
            onPointerDown={e => {
              if (e.pointerType !== "mouse" || e.button !== 0) return;
              const target = e.currentTarget;
              dragRef.current = { x: e.clientX, y: e.clientY, left: target.scrollLeft, top: target.scrollTop };
              target.setPointerCapture(e.pointerId);
              target.focus({ preventScroll: true });
              setDragging(true);
              e.preventDefault();
            }}
            onPointerMove={e => {
              const drag = dragRef.current;
              if (!drag) return;
              e.currentTarget.scrollLeft = drag.left - (e.clientX - drag.x);
              e.currentTarget.scrollTop = drag.top - (e.clientY - drag.y);
            }}
            onPointerUp={e => {
              dragRef.current = null;
              setDragging(false);
              if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
            }}
            onPointerCancel={() => { dragRef.current = null; setDragging(false); }}
            onLostPointerCapture={() => { dragRef.current = null; setDragging(false); }}>
            <div className="relative grid min-h-full w-max min-w-full place-items-center px-3 py-5 sm:px-6">
              <canvas ref={canvasRef} aria-label={`صفحة ${page} من الملف`} className="block max-w-none shrink-0 bg-paper shadow-lg" />
            </div>
          </main>
        </div>
      )}
      {document && !tools.hidden && <footer className="z-20 flex shrink-0 flex-wrap items-center justify-center gap-2 border-t border-border bg-background px-2 py-2">
        <Button variant="ghost" size="icon" aria-label="الصفحة السابقة" disabled={page <= 1} onClick={() => setPage(p => p - 1)}><ChevronRight /></Button>
        <Input className="h-9 w-14 text-center" type="number" min={1} max={document.numPages} aria-label="رقم الصفحة" value={page} onChange={e => { const n = Number(e.target.value); if (n >= 1 && n <= document.numPages) setPage(n); }} />
        <span className="text-xs text-muted-foreground">من {document.numPages}</span>
        <Button variant="ghost" size="icon" aria-label="الصفحة التالية" disabled={page >= document.numPages} onClick={() => setPage(p => p + 1)}><ChevronLeft /></Button>
        <span className="mx-1 h-5 border-r border-border" />
        <DocumentViewControls zoom={zoom} minimum={minimum} maximum={maximum} changeZoom={changeZoom} resetZoom={resetZoom} />
        <Button variant="outline" size="sm" onClick={() => setManagerOpen(true)}>إدارة الصفحات</Button>
      </footer>}
      {file && document && <PageManager open={managerOpen} onOpenChange={setManagerOpen} file={file} thumbnails={thumbnails} pageCount={document.numPages} onSaved={() => setRevision(v => v + 1)} />}
    </div>
  );
}

export const Route = createFileRoute("/pdf/$id")({
  head: () => ({ meta: [
    { title: "قارئ PDF — EVA Office" },
    { name: "description", content: "اقرأ ملفات PDF وابحث فيها وأدر صفحاتها في EVA Office." },
    { property: "og:title", content: "قارئ PDF — EVA Office" },
    { property: "og:description", content: "اقرأ ملفات PDF وابحث فيها وأدر صفحاتها في EVA Office." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: PdfPage,
});