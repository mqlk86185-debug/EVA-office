import { createFileRoute } from "@tanstack/react-router";
import { AppLibrary } from "@/components/office/AppLibrary";

function PdfLibraryPage() {
  return (
    <AppLibrary
      app="pdf"
      description="قارئ ومدير ملفات PDF سريع: تنقّل ومصغّرات وبحث داخل الملف، تظليل وملاحظات ورسم، وإدارة كاملة للصفحات (حذف، استخراج، ترتيب، تدوير، دمج وتقسيم)."
      createOptions={[]}
      allowUpload
    />
  );
}

export const Route = createFileRoute("/pdf/")({
  head: () => ({
    meta: [
      { title: "ملفات PDF — EVA Office" },
      { name: "description", content: "استعرض ملفات PDF واقرأها ونظمها في EVA Office." },
      { property: "og:title", content: "ملفات PDF — EVA Office" },
      { property: "og:description", content: "استعرض ملفات PDF واقرأها ونظمها في EVA Office." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PdfLibraryPage,
});
