import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Link } from "@/components/office/Link";
import { BottomNav } from "@/components/office/BottomNav";

const SECTIONS: { title: string; body: string[] }[] = [
  {
    title: "ما الذي نجمعه",
    body: [
      "ملفاتك ومستنداتك داخل EVA Office تُحفظ على جهازك فقط ولا تُرفع إلى أي خادم.",
      "في المحادثة المفتوحة نحفظ: نص الرسالة، الاسم المستعار الذي تختاره، وقت الإرسال، ومعرّف عشوائي للجهاز.",
    ],
  },
  {
    title: "معرّف الجهاز",
    body: [
      "المعرّف العشوائي يُنشأ داخل متصفحك ويُستخدم فقط لحساب عدد رسائلك المتبقية والسماح لك بحذف رسائلك.",
      "لا يرتبط باسمك ولا ببريدك ولا برقم هاتفك، ويمكنك إزالته بمسح بيانات الموقع من المتصفح.",
    ],
  },
  {
    title: "ما الذي لا نجمعه",
    body: [
      "لا نطلب تسجيل دخول ولا بريدًا إلكترونيًا ولا رقم هاتف.",
      "لا نبيع بياناتك ولا نشاركها مع معلنين.",
    ],
  },
  {
    title: "الرسائل العامة",
    body: [
      "كل ما تكتبه في المحادثة المفتوحة يظهر لجميع الزوار، فلا تكتب معلومات شخصية أو حساسة.",
      "يمكنك حذف رسائلك في أي وقت من زر الحذف بجانب الرسالة.",
    ],
  },
  {
    title: "حذف بياناتك",
    body: [
      "لحذف مستنداتك: احذفها من داخل التطبيق أو امسح بيانات الموقع.",
      "لحذف رسائلك: استخدم زر الحذف بجانب كل رسالة أرسلتها.",
    ],
  },
];

function PrivacyPage() {
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-3xl flex-col px-4 pt-4">
      <header className="flex items-center gap-2">
        <Link
          href="/"
          aria-label="رجوع"
          className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-card hover:bg-accent"
        >
          <ArrowRight className="h-4.5 w-4.5" />
        </Link>
        <div>
          <h1 className="font-display text-lg font-semibold tracking-tight">سياسة الخصوصية</h1>
          <p className="text-xs text-muted-foreground">كيف نتعامل مع بياناتك داخل EVA Office</p>
        </div>
      </header>

      <div className="mt-4 space-y-3 pb-28">
        {SECTIONS.map((section) => (
          <section key={section.title} className="rounded-2xl border border-border bg-card p-4">
            <h2 className="font-display text-base font-semibold">{section.title}</h2>
            <ul className="mt-2 space-y-1.5">
              {section.body.map((line) => (
                <li key={line} className="text-sm leading-relaxed text-muted-foreground">
                  {line}
                </li>
              ))}
            </ul>
          </section>
        ))}
        <p className="px-1 text-xs text-muted-foreground">
          اطّلع أيضًا على{" "}
          <Link href="/terms" className="underline">
            شروط الاستخدام
          </Link>
          .
        </p>
      </div>

      <BottomNav />
    </div>
  );
}

export const Route = createFileRoute("/privacy")({

  head: () => ({
    meta: [
      { title: "سياسة الخصوصية — EVA Office" },
      { name: "description", content: "تعرف على خصوصية بياناتك وملفاتك في EVA Office." },
      { property: "og:title", content: "سياسة الخصوصية — EVA Office" },
      { property: "og:description", content: "تعرف على خصوصية بياناتك وملفاتك في EVA Office." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PrivacyPage,
});
