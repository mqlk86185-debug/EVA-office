import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Link } from "@/components/office/Link";
import { ChevronRight, Moon, Sun, Info, FileText, Table2, BookOpen, Github } from "lucide-react";
import { BottomNav } from "@/components/office/BottomNav";
import { OfficeWordmark } from "@/components/office/AppMark";
import { getOfficeTheme, setOfficeTheme } from "@/components/office/ThemeBoot";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { APP_META } from "@/lib/office/types";

function SettingsPage() {
  const [dark, setDark] = useState(false);

  useEffect(() => {
    setDark(getOfficeTheme() === "dark");
  }, []);

  const toggle = (value: boolean) => {
    setDark(value);
    setOfficeTheme(value ? "dark" : "light");
  };

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-2xl flex-col px-4 pt-4">
      <header className="flex items-center gap-2">
        <Link
          href="/"
          aria-label="رجوع"
          className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-muted-foreground hover:bg-accent hover:text-foreground"
        >
          <ChevronRight className="h-5 w-5" />
        </Link>
        <h1 className="flex-1 font-display text-lg font-semibold tracking-tight">الإعدادات</h1>
      </header>

      <section className="mt-6 rounded-2xl border border-border bg-card p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary">
              {dark ? <Moon className="h-4.5 w-4.5" /> : <Sun className="h-4.5 w-4.5" />}
            </span>
            <div>
              <Label htmlFor="theme">الوضع الليلي</Label>
              <p className="text-xs text-muted-foreground">مريح للقراءة الطويلة والعمل مساءً</p>
            </div>
          </div>
          <Switch id="theme" checked={dark} onCheckedChange={toggle} />
        </div>
      </section>

      <section className="mt-4 space-y-2">
        <h2 className="px-1 font-display text-sm font-semibold text-muted-foreground">تطبيقات الحزمة</h2>
        {(["eva", "pdf", "gilox"] as const).map((app) => {
          const meta = APP_META[app];
          const Icon = app === "eva" ? FileText : app === "pdf" ? BookOpen : Table2;
          return (
            <Link
              key={app}
              href={meta.href}
              className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3 transition-colors hover:bg-accent/50"
            >
              <span
                className="flex h-10 w-10 items-center justify-center rounded-xl"
                style={{ background: `color-mix(in oklab, ${meta.color} 14%, transparent)`, color: meta.color }}
              >
                <Icon className="h-5 w-5" />
              </span>
              <span className="flex-1">
                <span className="block font-medium">{meta.name}</span>
                <span className="block text-xs text-muted-foreground">{meta.tagline}</span>
              </span>
              <ChevronRight className="h-4 w-4 rotate-180 text-muted-foreground" />
            </Link>
          );
        })}
      </section>

      <section className="mt-6 rounded-2xl border border-border bg-card p-4">
        <div className="mb-2 flex items-center gap-2">
          <Info className="h-4 w-4 text-muted-foreground" />
          <h2 className="font-display font-medium">عن EVA Office</h2>
        </div>
        <p className="text-sm leading-relaxed text-muted-foreground">
          حزمة مكتبية متكاملة مصممة للهواتف والأجهزة اللوحية: EVA لكتابة المستندات وإنشاء الأسئلة
          والاختبارات، PDF لقراءة وإدارة الملفات، وGILOX للجداول والبيانات والحسابات والرسوم البيانية —
          مع تصدير PDF عالي الجودة يحافظ على التنسيق.
        </p>
        <div className="mt-4">
          <OfficeWordmark />
        </div>
      </section>

      <div className="pb-24" />

      <BottomNav />
    </div>
  );
}

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "الإعدادات — EVA Office" },
      { name: "description", content: "اضبط تفضيلات EVA Office وإعدادات التطبيق." },
      { property: "og:title", content: "الإعدادات — EVA Office" },
      { property: "og:description", content: "اضبط تفضيلات EVA Office وإعدادات التطبيق." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SettingsPage,
});
