import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ChevronRight, Loader2, Pencil, Check, X, LayoutTemplate, Palette, Trash2 } from "lucide-react";
import { StationeryCustomizer } from "@/components/office/StationeryCustomizer";
import { StationeryPreview } from "@/components/office/StationeryPreview";
import { loadCustom, saveCustom } from "@/lib/office/templates/stationery-custom";
import { Link } from "@/components/office/Link";
import { useRouter } from "@/lib/office/nav";
import { BottomNav } from "@/components/office/BottomNav";
import { ThemeToggle } from "@/components/office/ThemeToggle";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { createFile } from "@/lib/office/client";
import { fileHref } from "@/lib/office/types";
import { GOLD_STATIONERY } from "@/lib/office/templates/gold";
import { STATIONERY, stationeryPayload, type StationerySpec } from "@/lib/office/templates/stationery";

const NAMES_KEY = "eva-stationery-names";

export const Route = createFileRoute("/templates")({
  ssr: false,
  head: () => ({ meta: [
    { title: "قوالب احترافية — EVA Office" },
    { name: "description", content: "قوالب قرطاسية احترافية وذهبية فاخرة خالية من النصوص، جاهزة للتحرير وإعادة التسمية." },
    { property: "og:title", content: "قوالب احترافية — EVA Office" },
    { property: "og:description", content: "قوالب قرطاسية احترافية فارغة جاهزة للتحرير." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: TemplatesPage,
});

function TemplatesPage() {
  const router = useRouter();
  const [names, setNames] = useState<Record<string, string>>({});
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState<string | null>(null);

  const [custom, setCustom] = useState<StationerySpec[]>([]);
  const [customizing, setCustomizing] = useState<StationerySpec | null>(null);
  useEffect(() => {
    setCustom(loadCustom());
    try { setNames(JSON.parse(localStorage.getItem(NAMES_KEY) ?? "{}")); } catch { /* ignore */ }
  }, []);

  const nameOf = (spec: StationerySpec) => names[spec.id] || spec.name;
  const saveName = (id: string) => {
    const value = draft.trim().slice(0, 60);
    const next = { ...names };
    if (value) next[id] = value; else delete next[id];
    setNames(next);
    localStorage.setItem(NAMES_KEY, JSON.stringify(next));
    setEditing(null);
  };
  const open = async (spec: StationerySpec) => {
    setBusy(spec.id);
    try {
      const file = await createFile(stationeryPayload(spec, nameOf(spec)));
      router.push(fileHref(file));
    } catch (err) {
      toast.error("تعذّر فتح القالب", { description: (err as Error).message });
      setBusy(null);
    }
  };

  const saveDesign = (spec: StationerySpec, name: string) => {
    const next = [{ ...spec, id: `custom-${Date.now()}`, name }, ...custom];
    setCustom(next); saveCustom(next); setCustomizing(null);
    toast.success("تم حفظ التصميم");
  };
  const removeDesign = (id: string) => {
    if (!confirm("حذف هذا التصميم؟")) return;
    const next = custom.filter((c) => c.id !== id);
    setCustom(next); saveCustom(next);
    toast.success("تم حذف التصميم");
  };

  const renderCard = (spec: StationerySpec) => (
          <div key={spec.id} className="flex flex-col gap-2">
      <button type="button" disabled={busy !== null} onClick={() => void open(spec)} aria-label={`تحرير ${nameOf(spec)}`}
        className="relative aspect-[210/297] overflow-hidden rounded-md border border-border bg-card shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
        <div dir="rtl" className="pointer-events-none absolute right-0 top-0 origin-top-right bg-card" style={{ width: 794, height: 1123, transform: "scale(var(--s))", ["--s" as string]: "0.2", padding: 30, backgroundColor: "#fff" }}
          ref={(el) => { if (el?.parentElement) el.style.setProperty("--s", String(el.parentElement.clientWidth / 794)); }}
          dangerouslySetInnerHTML={{ __html: spec.html }} />
        {busy === spec.id && <span className="absolute inset-0 flex items-center justify-center bg-background/60"><Loader2 className="animate-spin" /></span>}
      </button>
      {editing === spec.id ? (
        <div className="flex gap-1">
          <Input autoFocus value={draft} maxLength={60} onChange={(e) => setDraft(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") saveName(spec.id); if (e.key === "Escape") setEditing(null); }} className="h-8 text-sm" />
          <Button size="icon" variant="ghost" className="size-8" aria-label="حفظ" onClick={() => saveName(spec.id)}><Check /></Button>
          <Button size="icon" variant="ghost" className="size-8" aria-label="إلغاء" onClick={() => setEditing(null)}><X /></Button>
        </div>
      ) : (
        <div className="flex items-center gap-1">
          <span className="min-w-0 flex-1 truncate text-sm font-medium">{nameOf(spec)}</span>
          <Button size="icon" variant="ghost" className="size-8" aria-label="تعديل الاسم" onClick={() => { setEditing(spec.id); setDraft(nameOf(spec)); }}><Pencil /></Button>
        </div>
      )}
      <Button size="sm" variant="outline" className="w-full" onClick={() => setCustomizing(spec)}><Palette />تخصيص</Button>
    </div>
  );

  return (
    <div dir="rtl" className="mx-auto flex min-h-screen w-full max-w-5xl flex-col px-4 pt-4">
      <header className="flex items-center gap-3 border-b border-border pb-5">
        <Button asChild variant="ghost" size="icon"><Link href="/" aria-label="رجوع"><ChevronRight /></Link></Button>
        <LayoutTemplate className="size-8 shrink-0 text-eva" />
        <div className="min-w-0 flex-1">
          <h1 className="font-display text-2xl font-semibold">قوالب احترافية</h1>
          <p className="mt-1 text-sm text-muted-foreground">{STATIONERY.length + GOLD_STATIONERY.length} قالب فارغ · اضغط للتحرير</p>
        </div>
        <ThemeToggle />
      </header>
      {custom.length > 0 && (
        <section className="border-b border-border py-5" aria-label="تصاميمي المحفوظة">
          <h2 className="mb-3 font-display text-lg font-semibold">تصاميمي المحفوظة ({custom.length})</h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
            {custom.map((spec) => (
              <div key={spec.id} className="flex flex-col gap-2">
                <button type="button" disabled={busy !== null} onClick={() => void open(spec)} aria-label={`تحرير ${spec.name}`} className="relative transition hover:-translate-y-0.5">
                  <StationeryPreview spec={spec} />
                  {busy === spec.id && <span className="absolute inset-0 flex items-center justify-center bg-background/60"><Loader2 className="animate-spin" /></span>}
                </button>
                <div className="flex items-center gap-1">
                  <span className="min-w-0 flex-1 truncate text-sm font-medium">{spec.name}</span>
                  <Button size="icon" variant="ghost" className="size-8" aria-label="تخصيص" onClick={() => setCustomizing(spec)}><Palette /></Button>
                  <Button size="icon" variant="ghost" className="size-8 text-destructive" aria-label={`حذف ${spec.name}`} onClick={() => removeDesign(spec.id)}><Trash2 /></Button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
      <h2 className="pt-5 font-display text-lg font-semibold">القوالب الأساسية</h2>
      <div className="grid flex-1 grid-cols-2 content-start gap-4 py-5 sm:grid-cols-3 lg:grid-cols-5">
        {STATIONERY.map(renderCard)}
      </div>
      <h2 className="border-t border-border pt-5 font-display text-lg font-semibold">قوالب ذهبية فاخرة ({GOLD_STATIONERY.length})</h2>
      <div className="grid content-start gap-4 py-5 grid-cols-2 sm:grid-cols-3 lg:grid-cols-5" aria-label="قوالب ذهبية فاخرة">
        {GOLD_STATIONERY.map(renderCard)}
      </div>
      <StationeryCustomizer spec={customizing} name={customizing ? (custom.some((c) => c.id === customizing.id) ? customizing.name : nameOf(customizing)) : ""} onClose={() => setCustomizing(null)} onSave={saveDesign} />
      <BottomNav />
    </div>
  );
}
