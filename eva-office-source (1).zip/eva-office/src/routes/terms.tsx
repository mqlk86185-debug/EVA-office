import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Link } from "@/components/office/Link";
import { BottomNav } from "@/components/office/BottomNav";

const SECTIONS: { title: string; body: string[] }[] = [
  {
    title: "استخدام التطبيق",
    body: [
      "EVA Office متاح للاستخدام الشخصي والعملي مجانًا وبدون حساب.",
      "أنت مسؤول عن نسخ احتياطي لملفاتك، فهي محفوظة على جهازك وقد تُفقد بمسح بيانات المتصفح.",
    ],
  },
  {
    title: "المحادثة المفتوحة",
    body: [
      "المحادثة عامة ومفتوحة للجميع بدون تسجيل دخول.",
      "لكل مستخدم خمس رسائل فقط، وهذا الحد مطبّق على مستوى الخادم.",
      "يمكنك حذف رسائلك الخاصة في أي وقت.",
    ],
  },
  {
    title: "المحتوى الممنوع",
    body: [
      "يُمنع نشر الإساءة والتهديد والكراهية والمحتوى الجنسي أو غير القانوني.",
      "يُمنع نشر بيانات شخصية لأشخاص آخرين أو روابط ضارة أو إعلانات مزعجة.",
      "قد تُحذف أي رسالة مخالفة، ويجوز منع الجهاز المخالف من المشاركة.",
    ],
  },
  {
    title: "حدود المسؤولية",
    body: [
      "يُقدَّم التطبيق كما هو دون ضمانات، ولا نتحمّل مسؤولية فقدان ملفات أو أضرار ناتجة عن الاستخدام.",
      "آراء المستخدمين في المحادثة تعبّر عن أصحابها فقط.",
    ],
  },
  {
    title: "تغيير الشروط",
    body: ["قد نُحدّث هذه الشروط عند إضافة ميزات جديدة، والاستمرار في الاستخدام يعني الموافقة عليها."],
  },
];

function TermsPage() {
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-3xl flex-col px-4 pt-4">
      <header className="flex items-center gap-2">
        <Link
          href="/"
          aria-label="رجوع"
          className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-card hover:bg-accent"
        >
          <ArrowRight className="h-4.5 w-4.5" />
        </Link>
        <div>
          <h1 className="font-display text-lg font-semibold tracking-tight">شروط الاستخدام</h1>
          <p className="text-xs text-muted-foreground">قواعد بسيطة لاستخدام EVA Office والمحادثة</p>
        </div>
      </header>

      <div className="mt-4 space-y-3 pb-28">
        {SECTIONS.map((section) => (
          <section key={section.title} className="rounded-2xl border border-border bg-card p-4">
            <h2 className="font-display text-base font-semibold">{section.title}</h2>
            <ul className="mt-2 space-y-1.5">
              {section.body.map((line) => (
                <li key={line} className="text-sm leading-relaxed text-muted-foreground">
                  {line}
                </li>
              ))}
            </ul>
          </section>
        ))}
        <p className="px-1 text-xs text-muted-foreground">
          اطّلع أيضًا على{" "}
          <Link href="/privacy" className="underline">
            سياسة الخصوصية
          </Link>
          .
        </p>
      </div>

      <BottomNav />
    </div>
  );
}

export const Route = createFileRoute("/terms")({

  head: () => ({
    meta: [
      { title: "شروط الاستخدام — EVA Office" },
      { name: "description", content: "تعرف على شروط استخدام EVA Office." },
      { property: "og:title", content: "شروط الاستخدام — EVA Office" },
      { property: "og:description", content: "تعرف على شروط استخدام EVA Office." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TermsPage,
});
