import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, Bell } from "lucide-react";
import { Link } from "@/components/office/Link";
import { BottomNav } from "@/components/office/BottomNav";

type Block =
  | { kind: "text"; icon?: string; text: string }
  | { kind: "heading"; icon?: string; text: string }
  | { kind: "list"; items: { icon?: string; text: string }[] }
  | { kind: "divider" }
  | { kind: "signature"; role: string; name: string; note: string }
  | { kind: "closing"; text: string };

const MESSAGE = {
  sender: "الإدارة",
  subtitle: "رسالة إلى المستخدمين",
  title: { icon: "🚀", text: "تحديث جديد — تجربة أفضل لصناعة الأسئلة من الهاتف" },
  blocks: [
    {
      kind: "text",
      text: "نقدّم لكم تجربة جديدة ومبسطة تجعل إنشاء الأسئلة أسهل وأسرع من أي وقت مضى.",
    },
    {
      kind: "text",
      icon: "📱",
      text: "صُمّم التطبيق خصيصًا ليكون مناسبًا للهواتف، بحيث يمكنك إنشاء الأسئلة وإعداد المحتوى مباشرة من هاتفك، دون الحاجة إلى استخدام الحاسوب في المهام الأساسية.",
    },
    { kind: "divider" },
    { kind: "heading", text: "ماذا يمكنك فعلُه؟" },
    {
      kind: "list",
      items: [
        { icon: "📝", text: "إنشاء أسئلة بسهولة وسرعة." },
        { icon: "📚", text: "إعداد أسئلة تعليمية لمختلف المواضيع." },
        { icon: "📱", text: "العمل مباشرة من الهاتف بطريقة مريحة." },
        { icon: "⚡", text: "تقليل الحاجة إلى الحاسوب لإنشاء الأسئلة." },
        { icon: "🎯", text: "واجهة بسيطة تساعدك على التركيز على المحتوى." },
        { text: "الاستفادة من الذكاء الاصطناعي للمساعدة في إنشاء الأسئلة وتنظيمها." },
      ],
    },
    {
      kind: "text",
      text: "هدفنا هو جعل أدوات إنشاء الأسئلة متاحة في يدك أينما كنت، وتحويل الهاتف إلى أداة عملية لإنشاء المحتوى التعليمي بدل الاعتماد على الحاسوب.",
    },
    { kind: "divider" },
    {
      kind: "signature",
      role: "المطوّر والمالك",
      name: "مالك حاتم محمد",
      note: "هذا التطبيق تم تطويره بهدف توفير تجربة سهلة وعملية لإنشاء الأسئلة والمحتوى التعليمي من الهاتف.",
    },
    { kind: "heading", icon: "🔥", text: "القادم أفضل ان شاء الله" },
    {
      kind: "text",
      text: "نواصل تطوير التطبيق وإضافة المزيد من الأدوات والميزات، مع التركيز على السرعة والبساطة وتجربة الاستخدام على الهاتف.",
    },
    {
      kind: "closing",
      text: "شكرًا لاستخدامكم التطبيق ودعمكم للمشروع ❤️",
    },
  ] as Block[],
};

/** Fixed-width column that keeps an emoji aligned as a marker without breaking the text flow. */
function Marker({ icon }: { icon?: string }) {
  return (
    <span aria-hidden="true" className="select-none text-center text-[1.05em] leading-[1.95]">
      {icon ?? ""}
    </span>
  );
}

function Prose({ icon, text }: { icon?: string; text: string }) {
  return (
    <div className="grid grid-cols-[1.5rem_minmax(0,1fr)] gap-x-2 sm:grid-cols-[1.75rem_minmax(0,1fr)] sm:gap-x-3">
      <Marker icon={icon} />
      <p className="text-[1.0625rem] leading-[1.95] text-pretty sm:text-[1.125rem] sm:leading-[1.9]">
        {text}
      </p>
    </div>
  );
}

function SectionHeading({ icon, text }: { icon?: string; text: string }) {
  return (
    <h3 className="flex items-start gap-2.5 sm:gap-3">
      <span aria-hidden="true" className="mt-[0.6rem] h-4 w-1 shrink-0 rounded-full bg-eva" />
      <span className="font-display text-[1.1rem] font-bold text-balance sm:text-xl">
        {icon ? (
          <span aria-hidden="true" className="select-none">
            {icon}{" "}
          </span>
        ) : null}
        {text}
      </span>
    </h3>
  );
}

function Divider() {
  return (
    <div aria-hidden="true" className="flex items-center gap-3 py-1">
      <span className="h-px flex-1 bg-border" />
      <span className="select-none text-[0.65rem] tracking-[0.35em] text-muted-foreground/70">
        •••
      </span>
      <span className="h-px flex-1 bg-border" />
    </div>
  );
}

function BlockView({ block }: { block: Block }) {
  switch (block.kind) {
    case "text":
      return <Prose icon={block.icon} text={block.text} />;
    case "heading":
      return <SectionHeading icon={block.icon} text={block.text} />;
    case "list":
      return (
        <ul className="space-y-3">
          {block.items.map((item) => (
            <li
              key={item.text}
              className="grid grid-cols-[1.5rem_minmax(0,1fr)] gap-x-2 sm:grid-cols-[1.75rem_minmax(0,1fr)] sm:gap-x-3"
            >
              <Marker icon={item.icon} />
              <span className="text-[1.0625rem] leading-[1.9] text-pretty sm:text-[1.125rem] sm:leading-[1.85]">
                {item.text}
              </span>
            </li>
          ))}
        </ul>
      );
    case "divider":
      return <Divider />;
    case "signature":
      return (
        <aside className="rounded-2xl border border-border bg-secondary/60 p-4 sm:p-5">
          <p className="text-xs font-medium text-muted-foreground">{block.role}</p>
          <p className="mt-1 font-display text-lg font-bold sm:text-xl">{block.name}</p>
          <p className="mt-2 text-[0.95rem] leading-[1.85] text-muted-foreground text-pretty sm:text-base sm:leading-[1.8]">
            {block.note}
          </p>
        </aside>
      );
    case "closing":
      return (
        <p className="rounded-2xl border border-border bg-eva-soft/70 px-4 py-3.5 text-center font-display text-base font-semibold leading-[1.8] sm:text-lg">
          {block.text}
        </p>
      );
  }
}

function UpdatesPage() {
  return (
    <div dir="rtl" className="mx-auto flex min-h-screen w-full max-w-2xl flex-col px-4 pt-4 pb-28 sm:px-6">
      <header className="flex items-center gap-2">
        <Link
          href="/"
          aria-label="رجوع"
          className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-border bg-card hover:bg-accent"
        >
          <ArrowRight className="h-4.5 w-4.5" />
        </Link>
        <div className="min-w-0">
          <h1 className="font-display text-lg font-semibold tracking-tight">التحديثات</h1>
          <p className="text-xs text-muted-foreground">رسائل وإعلانات من الإدارة</p>
        </div>
      </header>

      <article className="mt-4 flex-1 overflow-hidden rounded-3xl border border-border bg-card shadow-sm">
        <header className="flex items-center gap-3 border-b border-border bg-muted/40 px-4 py-3.5 sm:px-6">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-eva-soft text-eva">
            <Bell className="h-5 w-5" aria-hidden="true" />
          </span>
          <div className="min-w-0">
            <p className="truncate font-display text-base font-bold">{MESSAGE.sender}</p>
            <p className="truncate text-xs text-muted-foreground">{MESSAGE.subtitle}</p>
          </div>
        </header>

        <div className="px-4 py-5 sm:px-6 sm:py-7">
          <h2 className="font-display text-[1.35rem] font-bold leading-[1.55] text-balance sm:text-2xl sm:leading-[1.45]">
            <span aria-hidden="true" className="select-none">
              {MESSAGE.title.icon}{" "}
            </span>
            {MESSAGE.title.text}
          </h2>

          <div className="mt-5 space-y-5 sm:mt-6 sm:space-y-6">
            {MESSAGE.blocks.map((block, index) => (
              <BlockView key={index} block={block} />
            ))}
          </div>
        </div>
      </article>

      <BottomNav />
    </div>
  );
}

export const Route = createFileRoute("/updates")({
  head: () => ({
    meta: [
      { title: "التحديثات — EVA Office" },
      { name: "description", content: "أخبار وتحديثات EVA Office ورسائل الإدارة." },
      { property: "og:title", content: "التحديثات — EVA Office" },
      { property: "og:description", content: "أخبار وتحديثات EVA Office ورسائل الإدارة." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: UpdatesPage,
});
